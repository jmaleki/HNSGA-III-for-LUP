﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LandUsePlanning.WinForms
{
    public partial class frmHNSGAII : Form
    {
        public frmHNSGAII()
        {
            InitializeComponent();
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {

        }

        private void btn_BrowseData_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD=new FolderBrowserDialog();
            if (FBD.ShowDialog()== DialogResult.OK)
            {
                txt_DataForRun.Text = FBD.SelectedPath+"\\";
                Settings.Default.DataForRun = FBD.SelectedPath + "\\";
            }
        }

        private void frmOptimization_Load(object sender, EventArgs e)
        {

            Settings.Default.HyberCubeCellsCount = Settings.Default.InitialPopulation/Settings.Default.NoOFObj;
            txt_DataForRun.Text = Settings.Default.DataForRun;
            nud_Iterations.Value = Settings.Default.Iteration;
            nud_PopSize.Value = Settings.Default.InitialPopulation;
            nud_CrossPercent.Value = Settings.Default.CrossoverPercent;
            nud_MutPercent.Value = Settings.Default.MutationRate;
            nud_TourSize.Value = Settings.Default.CrossTourSize;
            nud_HypercubeCellCount.Value = Settings.Default.HyberCubeCellsCount;

            nud_HypercubeCellCount.Value = 10;
            Settings.Default.HyberCubeCellsCount = Convert.ToInt32(nud_HypercubeCellCount.Value);
            Settings.Default.Save();


        }

        private void nud_Iterations_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.Iteration = Convert.ToInt32(nud_Iterations.Value);
        }

        private void nud_PopSize_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.InitialPopulation = Convert.ToInt32(nud_PopSize.Value);
            //Settings.Default.HyberCubeCellsCount = Settings.Default.InitialPopulation / Settings.Default.NoOFObj;
            //nud_HypercubeCellCount.Value = Settings.Default.HyberCubeCellsCount;

        }

        private void nud_CrossPercent_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.CrossoverPercent = nud_CrossPercent.Value;
        }

        private void nud_MutPercent_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.MutationRate = nud_MutPercent.Value;
        }

        private void nud_TourSize_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.CrossTourSize = Convert.ToInt32(nud_TourSize.Value);
        }

        private void nud_HypercubeCellCount_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.HyberCubeCellsCount = Convert.ToInt32(nud_HypercubeCellCount.Value);
            Settings.Default.Save();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void rbtn_Standby_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
