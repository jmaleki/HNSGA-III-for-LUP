using ESRI.ArcGIS.Geometry;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Diagnostics;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Geodatabase;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using LandUsePlanning.NSGAOptimization;
using LandUsePlanning.Classes;

namespace LandUsePlanning
{
    public sealed partial class MainForm : Form
    {
        IFeatureClass fc_Parcells;
        IFeatureClass fc_PopBlocks;

        #region class private members
        private IMapControl3 m_mapControl = null;
        private string m_mapDocumentName = string.Empty;
        System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Windows\Media\Alarm05.wav");
        Stopwatch sw;
        #endregion

        #region class constructor
        public MainForm()
        {
            InitializeComponent();
        }
        #endregion

        private void MainForm_Load(object sender, EventArgs e)
        {
            //get the MapControl
            m_mapControl = (IMapControl3)axMapControl1.Object;

            //disable the Save menu (since there is no document yet)
            menuSaveDoc.Enabled = false;
            string FolderPath = Settings.Default.DataForRun;
            FolderPath=FolderPath.Remove(FolderPath.Length - 1);
            string[] s = Directory.GetFiles(FolderPath);
            int a = s.Length;
            OpenFileDialog of = new OpenFileDialog();
            of.Title = "Select Map mxd file";
            of.Filter = "MXD File|*.mxd";
            of.ShowDialog();
            if (of.FileName==null | of.FileName=="")
            {
                MessageBox.Show("Map.mxd not selected");
                return;
            }
            Settings.Default.parcelsBinAdress = of.FileName.Replace(".mxd", ".bin");
            Settings.Default.resultFolder = of.SafeFileName.Replace(".mxd", "");
            Settings.Default.Save();
            m_mapControl.LoadMxFile(of.FileName, Type.Missing, Type.Missing);
            fc_Parcells = (getLayer("parcells") as IFeatureLayer).FeatureClass;
            fc_PopBlocks = (getLayer("Block_Polygons_totalpop") as IFeatureLayer).FeatureClass;

        }

        #region Main Menu event handlers
        private void menuNewDoc_Click(object sender, EventArgs e)
        {
            //execute New Document command

        }

        private void menuOpenDoc_Click(object sender, EventArgs e)
        {
            //execute Open Document command
            ICommand command = new ControlsOpenDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuSaveDoc_Click(object sender, EventArgs e)
        {
            //execute Save Document command
            if (m_mapControl.CheckMxFile(m_mapDocumentName))
            {
                //create a new instance of a MapDocument
                IMapDocument mapDoc = new MapDocumentClass();
                mapDoc.Open(m_mapDocumentName, string.Empty);

                //Make sure that the MapDocument is not readonly
                if (mapDoc.get_IsReadOnly(m_mapDocumentName))
                {
                    MessageBox.Show("Map document is read only!");
                    mapDoc.Close();
                    return;
                }

                //Replace its contents with the current map
                mapDoc.ReplaceContents((IMxdContents)m_mapControl.Map);

                //save the MapDocument in order to persist it
                mapDoc.Save(mapDoc.UsesRelativePaths, false);

                //close the MapDocument
                mapDoc.Close();
            }
        }

        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            //execute SaveAs Document command
            ICommand command = new ControlsSaveAsDocCommandClass();
            command.OnCreate(m_mapControl.Object);
            command.OnClick();
        }

        private void menuExitApp_Click(object sender, EventArgs e)
        {
            //exit the application
            Application.Exit();
        }
        #endregion

        //listen to MapReplaced evant in order to update the statusbar and the Save menu
        private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        {
            //get the current document name from the MapControl
            m_mapDocumentName = m_mapControl.DocumentFilename;

            //if there is no MapDocument, diable the Save menu and clear the statusbar
            if (m_mapDocumentName == string.Empty)
            {
                menuSaveDoc.Enabled = false;
                statusBarXY.Text = string.Empty;
            }
            else
            {
                //enable the Save manu and write the doc name to the statusbar
                menuSaveDoc.Enabled = true;
                statusBarXY.Text = System.IO.Path.GetFileName(m_mapDocumentName);
            }
        }

        private void axMapControl1_OnMouseMove(object sender, IMapControlEvents2_OnMouseMoveEvent e)
        {
            statusBarXY.Text = string.Format("{0}, {1}  {2}", e.mapX.ToString("#######.##"), e.mapY.ToString("#######.##"), axMapControl1.MapUnits.ToString().Substring(4));
        }

        private void axToolbarControl1_OnMouseDown(object sender, IToolbarControlEvents_OnMouseDownEvent e)
        {

        }

        private void optimizationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            






        }
        private void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Alaram();
        }
        private void Alaram()
        {
            sw.Stop();

            try
            {
                player.PlayLooping();
            }
            catch
            { }
            //Timer for Stoping player.
            System.Timers.Timer timer = new System.Timers.Timer();
            try
            {
                
                timer.Interval = 60000;
                timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);

                timer.Start();
            }
            catch
            { }
            //////////////////////////
            if (MessageBox.Show("Elapsed time=" + sw.Elapsed) == DialogResult.OK)
            {
                player.Stop();
            }
            timer.Dispose();
        }
        private void Run_ParametersCamputing(object sender, DoWorkEventArgs e)
        {
        }

        

        
        private void dependancyToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void compactnessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void timer_Elapsed(System.Object source, System.Timers.ElapsedEventArgs e)
        {
            player.Stop();
        }

        

        private void HNSGA2OptiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        private void tOPSISToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
        }



        public ILayer getLayer(string layerName)
        {
            try
            {
                IEnumLayer enumLayer = m_mapControl.Map.get_Layers(null, true);
                ILayer layer = enumLayer.Next();
                while (layer != null)
                {
                    if (layer is IFeatureLayer)
                    {
                        if (layer.Name == layerName)
                        {
                            return layer;
                        }
                    }
                    layer = enumLayer.Next();
                }
                return null;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void fuzzyCriteriaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void diagramParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void nSGAIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WinForms.frmHNSGAII _frmOptimization = new WinForms.frmHNSGAII();
            if (_frmOptimization.ShowDialog() == DialogResult.OK)
            {
                sw = new Stopwatch();
                sw.Start();
                //IFeatureClass fc_Parcells = (getLayer("parcells") as IFeatureLayer).FeatureClass;
                //IFeatureClass fc_PopBlocks = (getLayer("Block_Polygons_totalpop") as IFeatureLayer).FeatureClass;
                for (int runs = 0; runs < _frmOptimization.nud_NoRuns.Value; runs++)
                {
                    NSGAOptimization.C_HNSGA2 c_hnsga2 = new NSGAOptimization.C_HNSGA2(fc_Parcells, fc_PopBlocks);
                    if (_frmOptimization.rbtn_Elite.Checked)
                    {
                        c_hnsga2.RunC_HNSG2();
                    }
                    else if (_frmOptimization.rbtn_NoElite.Checked)
                    {
                        c_hnsga2.RunC_HNSG2_withoutEliteMutation();
                    }
                }
                //List<List<Optimization.Solution>> Front1OfIterations = hnsga2.PopulationOfIterations;

                if (_frmOptimization.rbtn_Alarm.Checked)
                {
                    Alaram();
                }
                else if (_frmOptimization.rbtn_Standby.Checked)
                {
                    Application.SetSuspendState(PowerState.Suspend, true, true);
                }
                else if (_frmOptimization.rbt_Hibernate.Checked)
                {
                    Application.SetSuspendState(PowerState.Hibernate, true, true);
                }
                
            }
        } 

#region "Select Map Features by Attribute Query"

///<summary>Select features in the IActiveView by an attribute query using a SQL syntax in a where clause.</summary>
/// 
///<param name="activeView">An IActiveView interface</param>
///<param name="featureLayer">An IFeatureLayer interface to select upon</param>
///<param name="whereClause">A System.String that is the SQL where clause syntax to select features. Example: "CityName = 'Redlands'"</param>
///  
///<remarks>Providing and empty string "" will return all records.</remarks>
public void SelectMapFeaturesByAttributeQuery(IActiveView activeView, IFeatureLayer featureLayer, System.String whereClause)
{
  if(activeView == null || featureLayer == null || whereClause == null)
  {
    return;
  }
  IFeatureSelection featureSelection = featureLayer as IFeatureSelection; // Dynamic Cast

  // Set up the query
  IQueryFilter queryFilter = new QueryFilterClass();
  queryFilter.WhereClause = whereClause;

  // Invalidate only the selection cache. Flag the original selection
  activeView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);

  // Perform the selection
  featureSelection.SelectFeatures(queryFilter, esriSelectionResultEnum.esriSelectionResultNew, false);

  // Flag the new selection
  activeView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);
}
#endregion

private void restartPCToolStripMenuItem_Click(object sender, EventArgs e)
{
    if (MessageBox.Show("Do You want to restart PC?", "Caution", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
    {
        Process.Start("shutdown", "/r /t 0");
    }
}

private void gAToolStripMenuItem_Click(object sender, EventArgs e)
{
    
}

private void extractResultsToolStripMenuItem_Click(object sender, EventArgs e)
{

}

private void constructMapToolStripMenuItem_Click(object sender, EventArgs e)
{
    //IFeatureClass fc_Parcells = (getLayer("parcells") as IFeatureLayer).FeatureClass;
    WinForms.frmConstructFinalMap _frmConstr = new WinForms.frmConstructFinalMap(fc_Parcells);
    _frmConstr.ShowDialog();
}

private void ovelayCompireToolStripMenuItem_Click(object sender, EventArgs e)
{

}

private void fuzzyTOPSISToolStripMenuItem_Click(object sender, EventArgs e)
{
    
}

private void nSGAIIToolStripMenuItem1_Click(object sender, EventArgs e)
{
    WinForms.frmNSGAIII _frmNSGAIII = new WinForms.frmNSGAIII();
    _frmNSGAIII.ShowDialog();
}

private void nSGAIIToolStripMenuItem2_Click(object sender, EventArgs e)
{
    WinForms.frmNSGAII _frmNSGAII = new WinForms.frmNSGAII();
    _frmNSGAII.ShowDialog();
}

private void spacingMetricToolStripMenuItem_Click(object sender, EventArgs e)
{



}






        private double nearestSolDist(SolutionH sol, List<SolutionH> pf)
        {
            List<SolutionH> pfwithoutSol=new List<SolutionH>(pf);
            pfwithoutSol.Remove(sol);
            double minDist = double.MaxValue;
            foreach(SolutionH s in pfwithoutSol)
            {
                double dist = CalDist(sol, s);
                if (dist < minDist)
                {
                    minDist = dist;
                }
            }
            return minDist;
        }
        private double CalDist(SolutionH s1, SolutionH s2)
        {
            double dist=0;
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                dist += Math.Pow((s1.Fitness[i] - s2.Fitness[i]), 2);
            }
            dist = Math.Sqrt(dist);
            return dist; 
        }

        private void diversityMetricToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


        private void paretoFrontToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.FileName = Settings.Default.DataForRun;
            ofd.Title = "select last solution";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                List<SolutionH> LastPop = BinarySerialization.ReadFromBinaryFile<List<SolutionH>>(ofd.FileName);
                List<SolutionH> Front = LastPop.FindAll(p => p.FrontRank == 0);
                string DataFolderName = ofd.FileName.Replace(ofd.SafeFileName, "");
                TextWriter tw = new StreamWriter(DataFolderName + "\\Front1_OfLastItration.txt");
                foreach (SolutionH solH in Front)
                {
                    foreach (double d in solH.Fitness)
                    {
                        tw.Write(d + ",");
                    }
                    tw.WriteLine();
                }
                tw.Close();
                int fr = 1;
                Front = LastPop.FindAll(p => p.FrontRank == fr);
                while (Front.Count != 0)
                {
                    tw = new StreamWriter(DataFolderName + "\\Front" + (fr + 1) + "_OfLastItration.txt");
                    foreach (SolutionH solH in Front)
                    {
                        foreach (double d in solH.Fitness)
                        {
                            tw.Write(d + ",");
                        }
                        tw.WriteLine();
                    }
                    tw.Close();
                    fr++;
                    Front = LastPop.FindAll(p => p.FrontRank == fr);
                }
                MessageBox.Show("Extracted in Selected path","Succesfull");
            }
        }

        private void fuzzyTOPISOptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void gAForFTOPSISEvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void solOverlayCompareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void shutdownPCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do You want to shutdown PC?", "Caution", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Process.Start("shutdown", "/s");
            }
                    
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*
            // if a log off or shutdown message is received
            if (systemShutdown)
            {
                // allow the application to close and exit fully
                e.Cancel = false;
                Application.Exit();
            }
             */
        }

        private void finalParetoRankingToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void gameBasedNSGAIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void diversityComparisonIndicatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private double[] DCI(List<SolutionH> popHNSGAIII, List<SolutionH> popNSGAII, List<SolutionH> popNSGAIII)
        {
            //Ref: LI, M., YANG, S. & LIU, X. 2014. Diversity comparison of Pareto front approximations in many-objective optimization.
            //1: Construct the grid environment according to Eqs. (2)�(4)
            int div = 10;
            double[] minFits = new double[Settings.Default.NoOFObj];
            double[] maxFits = new double[Settings.Default.NoOFObj];
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                double minH = popHNSGAIII.Select(s => s.Fitness[i]).Min();
                double maxH = popHNSGAIII.Select(s => s.Fitness[i]).Max();

                double minII = popNSGAII.Select(s => s.Fitness[i]).Min();
                double maxII = popNSGAII.Select(s => s.Fitness[i]).Max();

                double minIII = popNSGAIII.Select(s => s.Fitness[i]).Min();
                double maxIII = popNSGAIII.Select(s => s.Fitness[i]).Max();

                minFits[i] = new double[] { minII, minIII, minH }.Min();
                maxFits[i] = new double[] { maxII, maxIII, maxH }.Min();  

            }
            List<SolutionH> Allpop = new List<SolutionH>();
            Allpop.AddRange(popHNSGAIII);
            Allpop.AddRange(popNSGAII);
            Allpop.AddRange(popNSGAIII);

            List<List<SolutionH>> Fronts = RankDominance(Allpop);
            //3: Determine a set of hyperboxes, h1; h2; : : : ; hS, where the nondominated solutions in P1; P2; : : : ; PL are located
            List<int[]> Hyperboxes = new List<int[]>(Fronts[0].Count);
            foreach (SolutionH sol in Fronts[0])
            {
                int [] HB=new int[Settings.Default.NoOFObj];
                for (int i = 0; i < Settings.Default.NoOFObj;i++ )
                {
                    double d = (maxFits[i] - minFits[i]) / div;
                    HB[i] =Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                }
                if (!Hyperboxes.Contains(HB))
                {
                    Hyperboxes.Add(HB);
                }
            }
            //
            List<double> CDH = new List<double>(Hyperboxes.Count);
            List<double> CDII = new List<double>(Hyperboxes.Count);
            List<double> CDIII = new List<double>(Hyperboxes.Count);
            foreach (int[] hb in Hyperboxes)
            {
                //////////////////////////////////////////////////////////////////////////////////
                double MinDist2OfH = double.MaxValue;
                foreach (SolutionH sol in popHNSGAIII)
                {
                    int[] Gp = new int[Settings.Default.NoOFObj];
                    double D2 = 0;
                    for (int i = 0; i < Settings.Default.NoOFObj; i++)
                    {
                        double d = (maxFits[i] - minFits[i]) / div;
                        Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                        D2 = D2 + Math.Pow((hb[i] - Gp[i]),2);
                    }
                    if (D2 < MinDist2OfH)
                    {
                        MinDist2OfH = D2;
                    }
                }
                double CD_H = 0;
                if (MinDist2OfH < Settings.Default.NoOFObj + 1)
                {
                    CD_H=1-(MinDist2OfH/(Settings.Default.NoOFObj + 1));
                }
                else
                {
                    CD_H=0;
                }
                //////////////////////////////////////////////////////////////////////////////////
                double MinDist2OfII = double.MaxValue;
                foreach (SolutionH sol in popNSGAII)
                {
                    int[] Gp = new int[Settings.Default.NoOFObj];
                    double D2 = 0;
                    for (int i = 0; i < Settings.Default.NoOFObj; i++)
                    {
                        double d = (maxFits[i] - minFits[i]) / div;
                        Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                        D2 = D2 + Math.Pow((hb[i] - Gp[i]),2);
                    }
                    if (D2 < MinDist2OfII)
                    {
                        MinDist2OfII = D2;
                    }
                }
                double CD_II = 0;
                if (MinDist2OfII < Settings.Default.NoOFObj + 1)
                {
                    CD_II = 1 - (MinDist2OfII / (Settings.Default.NoOFObj + 1));
                }
                else
                {
                    CD_II=0;
                }
                //////////////////////////////////////////////////////////////////////////////////
                double MinDist2OfIII = double.MaxValue;
                foreach (SolutionH sol in popNSGAIII)
                {
                    int[] Gp = new int[Settings.Default.NoOFObj];
                    double D2 = 0;
                    for (int i = 0; i < Settings.Default.NoOFObj; i++)
                    {
                        double d = (maxFits[i] - minFits[i]) / div;
                        Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                        D2 = D2 + Math.Pow((hb[i] - Gp[i]),2);
                    }
                    if (D2 < MinDist2OfIII)
                    {
                        MinDist2OfIII = D2;
                    }
                }
                double CD_III = 0;
                if (MinDist2OfIII < Settings.Default.NoOFObj + 1)
                {
                    CD_III=1-(MinDist2OfIII/(Settings.Default.NoOFObj + 1));
                }
                else
                {
                    CD_III=0;
                }
                //////////////////////////////////////////////////////////////////////////////////
                CDH.Add(CD_H);
                CDII.Add(CD_II);
                CDIII.Add(CD_III);

            }
            double[] CDI = new double[3];
            CDI[0] = CDH.Average();
            CDI[1] = CDII.Average();
            CDI[2] = CDIII.Average();
            return CDI;


        }

        private List<List<SolutionH>> RankDominance(List<SolutionH> pop)
        {
            int popSize = pop.Count;


            Int16[,] DominateMatix = new Int16[popSize, popSize];

            int k = 0;
            List<List<SolutionH>> F = new List<List<SolutionH>>();
            F.Add(new List<SolutionH>());
            List<List<int>> Froid = new List<List<int>>();
            Froid.Add(new List<int>());
            for (int i = 0; i < popSize; i++)
            {
                SolutionH a = pop[i];

                if (i == popSize - 1)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                    break;
                }

                for (int j = i + 1; j < popSize; j++)
                {
                    SolutionH b = pop[j];

                    if (Dominate(a, b))
                    {
                        DominateMatix[i, j] = 1;
                    }
                    else if (Dominate(b, a))
                    {
                        DominateMatix[j, i] = 1;
                    }
                }
                if (sumColumn(DominateMatix, i) == 0)
                {
                    pop[i].FrontRank = k;
                    F[k].Add(pop[i]);
                    Froid[k].Add(i);
                }
            }
            int FCount = F[k].Count;
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[Froid[k][i], j] = 0;
                }
            }
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                }
            }

            //int[,] qwe=DominateMatix;
            while (true)
            {
                k = k + 1;
                F.Add(new List<SolutionH>());
                Froid.Add(new List<int>());
                for (int i = 0; i < popSize; i++)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                }

                FCount = F[k].Count;

                if (FCount == 0)
                {
                    break;
                }

                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[Froid[k][i], j] = 0;
                    }
                }
                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                    }
                }
            }
            F.RemoveAt(F.Count - 1);
            return F;
        }

        private bool Dominate(SolutionH sol1, SolutionH sol2)
        {
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] > sol2.Fitness[i])
                {
                    return false;
                }
            }
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] < sol2.Fitness[i])
                {
                    return true;
                }
            }
            return false;
        }

        private int sumColumn(Int16[,] DM, int ColIdx)
        {
            int RowCount = DM.GetLength(0);
            int sum = 0;
            for (int i = 0; i < RowCount; i++)
            {
                sum = sum + DM[i, ColIdx];
            }
            return sum;
        }




        private void qualityMetricToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private List<double[]> DCI2(List<SolutionH> popHNSGAIII, List<SolutionH> popNSGAII, List<SolutionH> popNSGAIII)
        {
            //Ref: LI, M., YANG, S. & LIU, X. 2014. Diversity comparison of Pareto front approximations in many-objective optimization.
            //1: Construct the grid environment according to Eqs. (2)�(4)
            int[] Alldiv = new int[]{1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100};
            double[] minFits = new double[Settings.Default.NoOFObj];
            double[] maxFits = new double[Settings.Default.NoOFObj];
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                double minH = popHNSGAIII.Select(s => s.Fitness[i]).Min();
                double maxH = popHNSGAIII.Select(s => s.Fitness[i]).Max();

                double minII = popNSGAII.Select(s => s.Fitness[i]).Min();
                double maxII = popNSGAII.Select(s => s.Fitness[i]).Max();

                double minIII = popNSGAIII.Select(s => s.Fitness[i]).Min();
                double maxIII = popNSGAIII.Select(s => s.Fitness[i]).Max();

                minFits[i] = new double[] { minII, minIII, minH }.Min();
                maxFits[i] = new double[] { maxII, maxIII, maxH }.Min();

            }
            List<SolutionH> Allpop = new List<SolutionH>();
            Allpop.AddRange(popHNSGAIII);
            Allpop.AddRange(popNSGAII);
            Allpop.AddRange(popNSGAIII);

            List<List<SolutionH>> Fronts = RankDominance(Allpop);
            List<double[]> AllDCIs = new List<double[]>();
            foreach (int div in Alldiv)
            {
                //3: Determine a set of hyperboxes, h1; h2; : : : ; hS, where the nondominated solutions in P1; P2; : : : ; PL are located
                List<int[]> Hyperboxes = new List<int[]>(Fronts[0].Count);
                foreach (SolutionH sol in Fronts[0])
                {
                    int[] HB = new int[Settings.Default.NoOFObj];
                    for (int i = 0; i < Settings.Default.NoOFObj; i++)
                    {
                        double d = (maxFits[i] - minFits[i]) / div;
                        HB[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                    }
                    if (!Hyperboxes.Contains(HB))
                    {
                        Hyperboxes.Add(HB);
                    }
                }
                //
                List<double> CDH = new List<double>(Hyperboxes.Count);
                List<double> CDII = new List<double>(Hyperboxes.Count);
                List<double> CDIII = new List<double>(Hyperboxes.Count);


                foreach (int[] hb in Hyperboxes)
                {
                    //////////////////////////////////////////////////////////////////////////////////
                    double MinDist2OfH = double.MaxValue;
                    foreach (SolutionH sol in popHNSGAIII)
                    {
                        int[] Gp = new int[Settings.Default.NoOFObj];
                        double D2 = 0;
                        for (int i = 0; i < Settings.Default.NoOFObj; i++)
                        {
                            double d = (maxFits[i] - minFits[i]) / div;
                            Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                            D2 = D2 + Math.Pow((hb[i] - Gp[i]), 2);
                        }
                        if (D2 < MinDist2OfH)
                        {
                            MinDist2OfH = D2;
                        }
                    }
                    double CD_H = 0;
                    if (MinDist2OfH < Settings.Default.NoOFObj + 1)
                    {
                        CD_H = 1 - (MinDist2OfH / (Settings.Default.NoOFObj + 1));
                    }
                    else
                    {
                        CD_H = 0;
                    }
                    //////////////////////////////////////////////////////////////////////////////////
                    double MinDist2OfII = double.MaxValue;
                    foreach (SolutionH sol in popNSGAII)
                    {
                        int[] Gp = new int[Settings.Default.NoOFObj];
                        double D2 = 0;
                        for (int i = 0; i < Settings.Default.NoOFObj; i++)
                        {
                            double d = (maxFits[i] - minFits[i]) / div;
                            Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                            D2 = D2 + Math.Pow((hb[i] - Gp[i]), 2);
                        }
                        if (D2 < MinDist2OfII)
                        {
                            MinDist2OfII = D2;
                        }
                    }
                    double CD_II = 0;
                    if (MinDist2OfII < Settings.Default.NoOFObj + 1)
                    {
                        CD_II = 1 - (MinDist2OfII / (Settings.Default.NoOFObj + 1));
                    }
                    else
                    {
                        CD_II = 0;
                    }
                    //////////////////////////////////////////////////////////////////////////////////
                    double MinDist2OfIII = double.MaxValue;
                    foreach (SolutionH sol in popNSGAIII)
                    {
                        int[] Gp = new int[Settings.Default.NoOFObj];
                        double D2 = 0;
                        for (int i = 0; i < Settings.Default.NoOFObj; i++)
                        {
                            double d = (maxFits[i] - minFits[i]) / div;
                            Gp[i] = Convert.ToInt32(Math.Floor((sol.Fitness[i] - minFits[i]) / d));
                            D2 = D2 + Math.Pow((hb[i] - Gp[i]), 2);
                        }
                        if (D2 < MinDist2OfIII)
                        {
                            MinDist2OfIII = D2;
                        }
                    }
                    double CD_III = 0;
                    if (MinDist2OfIII < Settings.Default.NoOFObj + 1)
                    {
                        CD_III = 1 - (MinDist2OfIII / (Settings.Default.NoOFObj + 1));
                    }
                    else
                    {
                        CD_III = 0;
                    }
                    //////////////////////////////////////////////////////////////////////////////////
                    CDH.Add(CD_H);
                    CDII.Add(CD_II);
                    CDIII.Add(CD_III);

                }
                double[] CDI = new double[3];
                CDI[0] = CDH.Average();
                CDI[1] = CDII.Average();
                CDI[2] = CDIII.Average();
                AllDCIs.Add(CDI);
            }

            return AllDCIs;


        }

        private void hyperVolumeToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void gameBasedGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void nEByRanksToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exportDataToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exportLUsToMatlabToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void scenario1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void shpToBinToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void allPFToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void compabilityToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}