﻿namespace LandUsePlanning.WinForms
{
    partial class frmHNSGAII
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Run = new System.Windows.Forms.Button();
            this.rbtn_Alarm = new System.Windows.Forms.RadioButton();
            this.rbtn_Standby = new System.Windows.Forms.RadioButton();
            this.rbt_Hibernate = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_TourSize = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nud_PopSize = new System.Windows.Forms.NumericUpDown();
            this.nud_CrossPercent = new System.Windows.Forms.NumericUpDown();
            this.nud_MutPercent = new System.Windows.Forms.NumericUpDown();
            this.nud_Iterations = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nud_HypercubeCellCount = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_DataForRun = new System.Windows.Forms.TextBox();
            this.btn_BrowseData = new System.Windows.Forms.Button();
            this.nud_NoRuns = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbtn_NoElite = new System.Windows.Forms.RadioButton();
            this.rbtn_Elite = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TourSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PopSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CrossPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MutPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Iterations)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_HypercubeCellCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NoRuns)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Run
            // 
            this.btn_Run.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_Run.Location = new System.Drawing.Point(348, 327);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(104, 23);
            this.btn_Run.TabIndex = 0;
            this.btn_Run.Text = "Run HNSGA";
            this.btn_Run.UseVisualStyleBackColor = true;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // rbtn_Alarm
            // 
            this.rbtn_Alarm.AutoSize = true;
            this.rbtn_Alarm.Checked = true;
            this.rbtn_Alarm.Location = new System.Drawing.Point(26, 23);
            this.rbtn_Alarm.Name = "rbtn_Alarm";
            this.rbtn_Alarm.Size = new System.Drawing.Size(74, 17);
            this.rbtn_Alarm.TabIndex = 1;
            this.rbtn_Alarm.TabStop = true;
            this.rbtn_Alarm.Text = "Play Alarm";
            this.rbtn_Alarm.UseVisualStyleBackColor = true;
            // 
            // rbtn_Standby
            // 
            this.rbtn_Standby.AutoSize = true;
            this.rbtn_Standby.Location = new System.Drawing.Point(26, 46);
            this.rbtn_Standby.Name = "rbtn_Standby";
            this.rbtn_Standby.Size = new System.Drawing.Size(101, 17);
            this.rbtn_Standby.TabIndex = 2;
            this.rbtn_Standby.Text = "Standby System";
            this.rbtn_Standby.UseVisualStyleBackColor = true;
            this.rbtn_Standby.CheckedChanged += new System.EventHandler(this.rbtn_Standby_CheckedChanged);
            // 
            // rbt_Hibernate
            // 
            this.rbt_Hibernate.AutoSize = true;
            this.rbt_Hibernate.Location = new System.Drawing.Point(26, 69);
            this.rbt_Hibernate.Name = "rbt_Hibernate";
            this.rbt_Hibernate.Size = new System.Drawing.Size(108, 17);
            this.rbt_Hibernate.TabIndex = 3;
            this.rbt_Hibernate.Text = "Hibernate System";
            this.rbt_Hibernate.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtn_Standby);
            this.groupBox1.Controls.Add(this.rbt_Hibernate);
            this.groupBox1.Controls.Add(this.rbtn_Alarm);
            this.groupBox1.Location = new System.Drawing.Point(21, 290);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(144, 100);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "After the optimization:";
            // 
            // nud_TourSize
            // 
            this.nud_TourSize.Location = new System.Drawing.Point(207, 143);
            this.nud_TourSize.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_TourSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_TourSize.Name = "nud_TourSize";
            this.nud_TourSize.Size = new System.Drawing.Size(49, 20);
            this.nud_TourSize.TabIndex = 27;
            this.nud_TourSize.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_TourSize.ValueChanged += new System.EventHandler(this.nud_TourSize_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "Size of Crossover Tournoment:";
            // 
            // nud_PopSize
            // 
            this.nud_PopSize.Location = new System.Drawing.Point(207, 56);
            this.nud_PopSize.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nud_PopSize.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_PopSize.Name = "nud_PopSize";
            this.nud_PopSize.Size = new System.Drawing.Size(49, 20);
            this.nud_PopSize.TabIndex = 25;
            this.nud_PopSize.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_PopSize.ValueChanged += new System.EventHandler(this.nud_PopSize_ValueChanged);
            // 
            // nud_CrossPercent
            // 
            this.nud_CrossPercent.DecimalPlaces = 2;
            this.nud_CrossPercent.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_CrossPercent.Location = new System.Drawing.Point(207, 85);
            this.nud_CrossPercent.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_CrossPercent.Name = "nud_CrossPercent";
            this.nud_CrossPercent.Size = new System.Drawing.Size(49, 20);
            this.nud_CrossPercent.TabIndex = 24;
            this.nud_CrossPercent.Value = new decimal(new int[] {
            8,
            0,
            0,
            65536});
            this.nud_CrossPercent.ValueChanged += new System.EventHandler(this.nud_CrossPercent_ValueChanged);
            // 
            // nud_MutPercent
            // 
            this.nud_MutPercent.DecimalPlaces = 2;
            this.nud_MutPercent.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MutPercent.Location = new System.Drawing.Point(207, 114);
            this.nud_MutPercent.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_MutPercent.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MutPercent.Name = "nud_MutPercent";
            this.nud_MutPercent.Size = new System.Drawing.Size(49, 20);
            this.nud_MutPercent.TabIndex = 23;
            this.nud_MutPercent.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.nud_MutPercent.ValueChanged += new System.EventHandler(this.nud_MutPercent_ValueChanged);
            // 
            // nud_Iterations
            // 
            this.nud_Iterations.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_Iterations.Location = new System.Drawing.Point(207, 25);
            this.nud_Iterations.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_Iterations.Name = "nud_Iterations";
            this.nud_Iterations.Size = new System.Drawing.Size(49, 20);
            this.nud_Iterations.TabIndex = 22;
            this.nud_Iterations.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_Iterations.ValueChanged += new System.EventHandler(this.nud_Iterations_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(94, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Mutation Percent:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(88, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Crossover Percent:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(102, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Population Size:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Number of Iterations:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nud_HypercubeCellCount);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.nud_TourSize);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nud_PopSize);
            this.groupBox2.Controls.Add(this.nud_CrossPercent);
            this.groupBox2.Controls.Add(this.nud_MutPercent);
            this.groupBox2.Controls.Add(this.nud_Iterations);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(269, 233);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "HNSGA Parameters";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // nud_HypercubeCellCount
            // 
            this.nud_HypercubeCellCount.Location = new System.Drawing.Point(207, 174);
            this.nud_HypercubeCellCount.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_HypercubeCellCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_HypercubeCellCount.Name = "nud_HypercubeCellCount";
            this.nud_HypercubeCellCount.Size = new System.Drawing.Size(49, 20);
            this.nud_HypercubeCellCount.TabIndex = 29;
            this.nud_HypercubeCellCount.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_HypercubeCellCount.ValueChanged += new System.EventHandler(this.nud_HypercubeCellCount_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Hyber Cube Cells Count";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Data Adress:";
            // 
            // txt_DataForRun
            // 
            this.txt_DataForRun.Location = new System.Drawing.Point(109, 23);
            this.txt_DataForRun.Name = "txt_DataForRun";
            this.txt_DataForRun.ReadOnly = true;
            this.txt_DataForRun.Size = new System.Drawing.Size(263, 20);
            this.txt_DataForRun.TabIndex = 30;
            // 
            // btn_BrowseData
            // 
            this.btn_BrowseData.Location = new System.Drawing.Point(387, 21);
            this.btn_BrowseData.Name = "btn_BrowseData";
            this.btn_BrowseData.Size = new System.Drawing.Size(75, 23);
            this.btn_BrowseData.TabIndex = 31;
            this.btn_BrowseData.Text = "Browse";
            this.btn_BrowseData.UseVisualStyleBackColor = true;
            this.btn_BrowseData.Click += new System.EventHandler(this.btn_BrowseData_Click);
            // 
            // nud_NoRuns
            // 
            this.nud_NoRuns.Location = new System.Drawing.Point(403, 290);
            this.nud_NoRuns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_NoRuns.Name = "nud_NoRuns";
            this.nud_NoRuns.Size = new System.Drawing.Size(49, 20);
            this.nud_NoRuns.TabIndex = 31;
            this.nud_NoRuns.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(330, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "No. of Runs:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbtn_NoElite);
            this.groupBox3.Controls.Add(this.rbtn_Elite);
            this.groupBox3.Location = new System.Drawing.Point(290, 204);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(162, 69);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Elite Mutation:";
            // 
            // rbtn_NoElite
            // 
            this.rbtn_NoElite.AutoSize = true;
            this.rbtn_NoElite.Location = new System.Drawing.Point(26, 46);
            this.rbtn_NoElite.Name = "rbtn_NoElite";
            this.rbtn_NoElite.Size = new System.Drawing.Size(129, 17);
            this.rbtn_NoElite.TabIndex = 2;
            this.rbtn_NoElite.Text = "Without Elite Mutation";
            this.rbtn_NoElite.UseVisualStyleBackColor = true;
            // 
            // rbtn_Elite
            // 
            this.rbtn_Elite.AutoSize = true;
            this.rbtn_Elite.Checked = true;
            this.rbtn_Elite.Location = new System.Drawing.Point(26, 23);
            this.rbtn_Elite.Name = "rbtn_Elite";
            this.rbtn_Elite.Size = new System.Drawing.Size(113, 17);
            this.rbtn_Elite.TabIndex = 1;
            this.rbtn_Elite.TabStop = true;
            this.rbtn_Elite.Text = "With Elite mutation";
            this.rbtn_Elite.UseVisualStyleBackColor = true;
            // 
            // frmHNSGAII
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 402);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.nud_NoRuns);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_BrowseData);
            this.Controls.Add(this.txt_DataForRun);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_Run);
            this.Name = "frmHNSGAII";
            this.Text = "HNSGAII Parameters Setting";
            this.Load += new System.EventHandler(this.frmOptimization_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TourSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PopSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CrossPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MutPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Iterations)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_HypercubeCellCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_NoRuns)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Run;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.RadioButton rbtn_Alarm;
        public System.Windows.Forms.RadioButton rbtn_Standby;
        public System.Windows.Forms.RadioButton rbt_Hibernate;
        private System.Windows.Forms.NumericUpDown nud_TourSize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud_PopSize;
        private System.Windows.Forms.NumericUpDown nud_CrossPercent;
        private System.Windows.Forms.NumericUpDown nud_MutPercent;
        private System.Windows.Forms.NumericUpDown nud_Iterations;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown nud_HypercubeCellCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_DataForRun;
        private System.Windows.Forms.Button btn_BrowseData;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.NumericUpDown nud_NoRuns;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.RadioButton rbtn_NoElite;
        public System.Windows.Forms.RadioButton rbtn_Elite;
    }
}