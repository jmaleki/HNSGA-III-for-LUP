﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LandUsePlanning.WinForms
{
    public partial class frmNSGAIII : Form
    {
        public frmNSGAIII()
        {
            InitializeComponent();
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            for (int runs = 0; runs < nud_NoRuns.Value; runs++)
            {
                NSGAOptimization.NSGAIII nsga3 = new NSGAOptimization.NSGAIII();
                nsga3.Run();
            }
        }

        private void nud_HyperplaneDivisions_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.NSGAIIIRefDivisionParts = Convert.ToInt32(nud_HyperplaneDivisions.Value);
            int parts = Settings.Default.NSGAIIIRefDivisionParts;
            int NoOFObj = Settings.Default.NoOFObj;
            int NoOfRefPoints = Convert.ToInt32(Factorial(NoOFObj + parts - 1) / (Factorial(parts) * Factorial(NoOFObj - 1)));
            Settings.Default.InitialPopulation = NoOfRefPoints;
            nud_PopSize.Value = Settings.Default.InitialPopulation;
        }
        private long Factorial(long number)
        {
            if (number <= 1)
                return 1;
            else
                return number * Factorial(number - 1);
        }

        private void frmNSGAIII_Load(object sender, EventArgs e)
        {
            Settings.Default.HyberCubeCellsCount = Settings.Default.InitialPopulation / Settings.Default.NoOFObj;
            txt_DataForRun.Text = Settings.Default.DataForRun;
            nud_Iterations.Value = Settings.Default.Iteration;
            nud_PopSize.Value = Settings.Default.InitialPopulation;
            nud_CrossPercent.Value = Settings.Default.CrossoverPercent;
            nud_MutPercent.Value = Settings.Default.MutationRate;
            nud_TourSize.Value = Settings.Default.CrossTourSize;
            nud_HyperplaneDivisions.Value = Settings.Default.NSGAIIIRefDivisionParts;
        }

        private void nud_Iterations_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.Iteration = Convert.ToInt32(nud_Iterations.Value);
        }

        private void nud_PopSize_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.InitialPopulation = Convert.ToInt32(nud_PopSize.Value);
            
        }

        private void nud_CrossPercent_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.CrossoverPercent = nud_CrossPercent.Value;
        }

        private void nud_MutPercent_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.MutationRate = nud_MutPercent.Value;
        }

        private void nud_TourSize_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.CrossTourSize = Convert.ToInt32(nud_TourSize.Value);
        }
    }
}
