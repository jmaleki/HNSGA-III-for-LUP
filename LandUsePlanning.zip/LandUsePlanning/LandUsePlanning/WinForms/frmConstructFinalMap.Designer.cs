﻿namespace LandUsePlanning.WinForms
{
    partial class frmConstructFinalMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Construct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtResultPath = new System.Windows.Forms.TextBox();
            this.btn_BrowseResultFolder = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCompability = new System.Windows.Forms.TextBox();
            this.txtUBCompability = new System.Windows.Forms.TextBox();
            this.txtUBDependancy = new System.Windows.Forms.TextBox();
            this.txtUBSuitability = new System.Windows.Forms.TextBox();
            this.txtUBCompactness = new System.Windows.Forms.TextBox();
            this.txtUBPercapita = new System.Windows.Forms.TextBox();
            this.txtPercapita = new System.Windows.Forms.TextBox();
            this.txtCompactness = new System.Windows.Forms.TextBox();
            this.txtSuitablity = new System.Windows.Forms.TextBox();
            this.txtDependancy = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtIterNo = new System.Windows.Forms.TextBox();
            this.txtLBPercapita = new System.Windows.Forms.TextBox();
            this.txtLBCompability = new System.Windows.Forms.TextBox();
            this.txtLBCompactness = new System.Windows.Forms.TextBox();
            this.txtLBDependancy = new System.Windows.Forms.TextBox();
            this.txtLBSuitability = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbxPercapita = new System.Windows.Forms.CheckBox();
            this.cbxCompactness = new System.Windows.Forms.CheckBox();
            this.cbxSuitability = new System.Windows.Forms.CheckBox();
            this.cbxDependancey = new System.Windows.Forms.CheckBox();
            this.cbxCompability = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtSelectedCompactness = new System.Windows.Forms.TextBox();
            this.txtSelectedDependancy = new System.Windows.Forms.TextBox();
            this.txtSelectedPercapita = new System.Windows.Forms.TextBox();
            this.txtSelectedCompability = new System.Windows.Forms.TextBox();
            this.txtSelectedSuitablity = new System.Windows.Forms.TextBox();
            this.btnFind = new System.Windows.Forms.Button();
            this.btn_BinToSHP = new System.Windows.Forms.Button();
            this.btnSelectItrBIN = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Construct
            // 
            this.btn_Construct.Enabled = false;
            this.btn_Construct.Location = new System.Drawing.Point(72, 195);
            this.btn_Construct.Name = "btn_Construct";
            this.btn_Construct.Size = new System.Drawing.Size(113, 31);
            this.btn_Construct.TabIndex = 0;
            this.btn_Construct.Text = "Cunstract Map";
            this.btn_Construct.UseVisualStyleBackColor = true;
            this.btn_Construct.Click += new System.EventHandler(this.btn_Construct_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Result Folder Path:";
            // 
            // txtResultPath
            // 
            this.txtResultPath.Location = new System.Drawing.Point(128, 33);
            this.txtResultPath.Name = "txtResultPath";
            this.txtResultPath.ReadOnly = true;
            this.txtResultPath.Size = new System.Drawing.Size(575, 20);
            this.txtResultPath.TabIndex = 2;
            // 
            // btn_BrowseResultFolder
            // 
            this.btn_BrowseResultFolder.Location = new System.Drawing.Point(709, 31);
            this.btn_BrowseResultFolder.Name = "btn_BrowseResultFolder";
            this.btn_BrowseResultFolder.Size = new System.Drawing.Size(75, 23);
            this.btn_BrowseResultFolder.TabIndex = 3;
            this.btn_BrowseResultFolder.Text = "Browse";
            this.btn_BrowseResultFolder.UseVisualStyleBackColor = true;
            this.btn_BrowseResultFolder.Click += new System.EventHandler(this.btn_BrowseResultFolder_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Lower bound";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(190, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Upper bound";
            // 
            // txtCompability
            // 
            this.txtCompability.Location = new System.Drawing.Point(105, 46);
            this.txtCompability.Name = "txtCompability";
            this.txtCompability.Size = new System.Drawing.Size(44, 21);
            this.txtCompability.TabIndex = 9;
            this.txtCompability.Text = "1";
            // 
            // txtUBCompability
            // 
            this.txtUBCompability.Location = new System.Drawing.Point(190, 49);
            this.txtUBCompability.Name = "txtUBCompability";
            this.txtUBCompability.ReadOnly = true;
            this.txtUBCompability.Size = new System.Drawing.Size(70, 20);
            this.txtUBCompability.TabIndex = 11;
            // 
            // txtUBDependancy
            // 
            this.txtUBDependancy.Location = new System.Drawing.Point(190, 75);
            this.txtUBDependancy.Name = "txtUBDependancy";
            this.txtUBDependancy.ReadOnly = true;
            this.txtUBDependancy.Size = new System.Drawing.Size(70, 20);
            this.txtUBDependancy.TabIndex = 12;
            // 
            // txtUBSuitability
            // 
            this.txtUBSuitability.Location = new System.Drawing.Point(190, 101);
            this.txtUBSuitability.Name = "txtUBSuitability";
            this.txtUBSuitability.ReadOnly = true;
            this.txtUBSuitability.Size = new System.Drawing.Size(70, 20);
            this.txtUBSuitability.TabIndex = 13;
            // 
            // txtUBCompactness
            // 
            this.txtUBCompactness.Location = new System.Drawing.Point(190, 127);
            this.txtUBCompactness.Name = "txtUBCompactness";
            this.txtUBCompactness.ReadOnly = true;
            this.txtUBCompactness.Size = new System.Drawing.Size(70, 20);
            this.txtUBCompactness.TabIndex = 14;
            // 
            // txtUBPercapita
            // 
            this.txtUBPercapita.Location = new System.Drawing.Point(190, 153);
            this.txtUBPercapita.Name = "txtUBPercapita";
            this.txtUBPercapita.ReadOnly = true;
            this.txtUBPercapita.Size = new System.Drawing.Size(70, 20);
            this.txtUBPercapita.TabIndex = 15;
            // 
            // txtPercapita
            // 
            this.txtPercapita.Location = new System.Drawing.Point(105, 150);
            this.txtPercapita.Name = "txtPercapita";
            this.txtPercapita.Size = new System.Drawing.Size(44, 21);
            this.txtPercapita.TabIndex = 16;
            this.txtPercapita.Text = "0";
            // 
            // txtCompactness
            // 
            this.txtCompactness.Location = new System.Drawing.Point(105, 124);
            this.txtCompactness.Name = "txtCompactness";
            this.txtCompactness.Size = new System.Drawing.Size(44, 21);
            this.txtCompactness.TabIndex = 17;
            this.txtCompactness.Text = "1";
            // 
            // txtSuitablity
            // 
            this.txtSuitablity.Location = new System.Drawing.Point(105, 98);
            this.txtSuitablity.Name = "txtSuitablity";
            this.txtSuitablity.Size = new System.Drawing.Size(44, 21);
            this.txtSuitablity.TabIndex = 18;
            this.txtSuitablity.Text = "1";
            // 
            // txtDependancy
            // 
            this.txtDependancy.Location = new System.Drawing.Point(105, 72);
            this.txtDependancy.Name = "txtDependancy";
            this.txtDependancy.Size = new System.Drawing.Size(44, 21);
            this.txtDependancy.TabIndex = 19;
            this.txtDependancy.Text = "1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtIterNo);
            this.groupBox1.Controls.Add(this.txtLBPercapita);
            this.groupBox1.Controls.Add(this.txtLBCompability);
            this.groupBox1.Controls.Add(this.txtLBCompactness);
            this.groupBox1.Controls.Add(this.txtLBDependancy);
            this.groupBox1.Controls.Add(this.txtLBSuitability);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtUBPercapita);
            this.groupBox1.Controls.Add(this.txtUBCompability);
            this.groupBox1.Controls.Add(this.txtUBCompactness);
            this.groupBox1.Controls.Add(this.txtUBDependancy);
            this.groupBox1.Controls.Add(this.txtUBSuitability);
            this.groupBox1.Location = new System.Drawing.Point(12, 108);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(285, 251);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Objective Ranges:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(45, 209);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 13);
            this.label16.TabIndex = 31;
            this.label16.Text = "Nubmer of iterations:";
            // 
            // txtIterNo
            // 
            this.txtIterNo.Location = new System.Drawing.Point(155, 206);
            this.txtIterNo.Name = "txtIterNo";
            this.txtIterNo.ReadOnly = true;
            this.txtIterNo.Size = new System.Drawing.Size(62, 20);
            this.txtIterNo.TabIndex = 22;
            // 
            // txtLBPercapita
            // 
            this.txtLBPercapita.Location = new System.Drawing.Point(108, 152);
            this.txtLBPercapita.Name = "txtLBPercapita";
            this.txtLBPercapita.ReadOnly = true;
            this.txtLBPercapita.Size = new System.Drawing.Size(70, 20);
            this.txtLBPercapita.TabIndex = 30;
            // 
            // txtLBCompability
            // 
            this.txtLBCompability.Location = new System.Drawing.Point(108, 48);
            this.txtLBCompability.Name = "txtLBCompability";
            this.txtLBCompability.ReadOnly = true;
            this.txtLBCompability.Size = new System.Drawing.Size(70, 20);
            this.txtLBCompability.TabIndex = 26;
            // 
            // txtLBCompactness
            // 
            this.txtLBCompactness.Location = new System.Drawing.Point(108, 126);
            this.txtLBCompactness.Name = "txtLBCompactness";
            this.txtLBCompactness.ReadOnly = true;
            this.txtLBCompactness.Size = new System.Drawing.Size(70, 20);
            this.txtLBCompactness.TabIndex = 29;
            // 
            // txtLBDependancy
            // 
            this.txtLBDependancy.Location = new System.Drawing.Point(108, 74);
            this.txtLBDependancy.Name = "txtLBDependancy";
            this.txtLBDependancy.ReadOnly = true;
            this.txtLBDependancy.Size = new System.Drawing.Size(70, 20);
            this.txtLBDependancy.TabIndex = 27;
            // 
            // txtLBSuitability
            // 
            this.txtLBSuitability.Location = new System.Drawing.Point(108, 100);
            this.txtLBSuitability.Name = "txtLBSuitability";
            this.txtLBSuitability.ReadOnly = true;
            this.txtLBSuitability.Size = new System.Drawing.Size(70, 20);
            this.txtLBSuitability.TabIndex = 28;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label10.Location = new System.Drawing.Point(23, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Objectives";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "Compability:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "Dependancy:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Suitability:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Compactness:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Per capita:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbxPercapita);
            this.groupBox2.Controls.Add(this.cbxCompactness);
            this.groupBox2.Controls.Add(this.cbxSuitability);
            this.groupBox2.Controls.Add(this.cbxDependancey);
            this.groupBox2.Controls.Add(this.cbxCompability);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtCompactness);
            this.groupBox2.Controls.Add(this.txtDependancy);
            this.groupBox2.Controls.Add(this.txtPercapita);
            this.groupBox2.Controls.Add(this.txtCompability);
            this.groupBox2.Controls.Add(this.txtSuitablity);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupBox2.Location = new System.Drawing.Point(319, 109);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 203);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Find a solution near to:";
            // 
            // cbxPercapita
            // 
            this.cbxPercapita.AutoSize = true;
            this.cbxPercapita.Checked = true;
            this.cbxPercapita.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxPercapita.Location = new System.Drawing.Point(155, 154);
            this.cbxPercapita.Name = "cbxPercapita";
            this.cbxPercapita.Size = new System.Drawing.Size(15, 14);
            this.cbxPercapita.TabIndex = 35;
            this.cbxPercapita.UseVisualStyleBackColor = true;
            this.cbxPercapita.CheckedChanged += new System.EventHandler(this.cbxPercapita_CheckedChanged);
            // 
            // cbxCompactness
            // 
            this.cbxCompactness.AutoSize = true;
            this.cbxCompactness.Checked = true;
            this.cbxCompactness.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxCompactness.Location = new System.Drawing.Point(155, 128);
            this.cbxCompactness.Name = "cbxCompactness";
            this.cbxCompactness.Size = new System.Drawing.Size(15, 14);
            this.cbxCompactness.TabIndex = 34;
            this.cbxCompactness.UseVisualStyleBackColor = true;
            this.cbxCompactness.CheckedChanged += new System.EventHandler(this.cbxCompactness_CheckedChanged);
            // 
            // cbxSuitability
            // 
            this.cbxSuitability.AutoSize = true;
            this.cbxSuitability.Checked = true;
            this.cbxSuitability.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxSuitability.Location = new System.Drawing.Point(155, 102);
            this.cbxSuitability.Name = "cbxSuitability";
            this.cbxSuitability.Size = new System.Drawing.Size(15, 14);
            this.cbxSuitability.TabIndex = 33;
            this.cbxSuitability.UseVisualStyleBackColor = true;
            this.cbxSuitability.CheckedChanged += new System.EventHandler(this.cbxSuitability_CheckedChanged);
            // 
            // cbxDependancey
            // 
            this.cbxDependancey.AutoSize = true;
            this.cbxDependancey.Checked = true;
            this.cbxDependancey.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxDependancey.Location = new System.Drawing.Point(155, 76);
            this.cbxDependancey.Name = "cbxDependancey";
            this.cbxDependancey.Size = new System.Drawing.Size(15, 14);
            this.cbxDependancey.TabIndex = 32;
            this.cbxDependancey.UseVisualStyleBackColor = true;
            this.cbxDependancey.CheckedChanged += new System.EventHandler(this.cbxDependancey_CheckedChanged);
            // 
            // cbxCompability
            // 
            this.cbxCompability.AutoSize = true;
            this.cbxCompability.Checked = true;
            this.cbxCompability.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxCompability.Location = new System.Drawing.Point(155, 50);
            this.cbxCompability.Name = "cbxCompability";
            this.cbxCompability.Size = new System.Drawing.Size(15, 14);
            this.cbxCompability.TabIndex = 30;
            this.cbxCompability.UseVisualStyleBackColor = true;
            this.cbxCompability.CheckedChanged += new System.EventHandler(this.cbxCompability_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 15);
            this.label11.TabIndex = 29;
            this.label11.Text = "Compability:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 15);
            this.label12.TabIndex = 28;
            this.label12.Text = "Dependancy:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 15);
            this.label13.TabIndex = 27;
            this.label13.Text = "Suitability:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 124);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 15);
            this.label14.TabIndex = 26;
            this.label14.Text = "Compactness:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 150);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 15);
            this.label15.TabIndex = 25;
            this.label15.Text = "Per capita:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.btn_Construct);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txtSelectedCompactness);
            this.groupBox3.Controls.Add(this.txtSelectedDependancy);
            this.groupBox3.Controls.Add(this.txtSelectedPercapita);
            this.groupBox3.Controls.Add(this.txtSelectedCompability);
            this.groupBox3.Controls.Add(this.txtSelectedSuitablity);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupBox3.Location = new System.Drawing.Point(610, 109);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 250);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Selected Solution";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 46);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 15);
            this.label18.TabIndex = 29;
            this.label18.Text = "Compability:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 72);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 15);
            this.label19.TabIndex = 28;
            this.label19.Text = "Dependancy:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 98);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 15);
            this.label20.TabIndex = 27;
            this.label20.Text = "Suitability:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 124);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 15);
            this.label21.TabIndex = 26;
            this.label21.Text = "Compactness:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 150);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 15);
            this.label22.TabIndex = 25;
            this.label22.Text = "Per capita:";
            // 
            // txtSelectedCompactness
            // 
            this.txtSelectedCompactness.Location = new System.Drawing.Point(105, 124);
            this.txtSelectedCompactness.Name = "txtSelectedCompactness";
            this.txtSelectedCompactness.ReadOnly = true;
            this.txtSelectedCompactness.Size = new System.Drawing.Size(63, 21);
            this.txtSelectedCompactness.TabIndex = 17;
            // 
            // txtSelectedDependancy
            // 
            this.txtSelectedDependancy.Location = new System.Drawing.Point(105, 72);
            this.txtSelectedDependancy.Name = "txtSelectedDependancy";
            this.txtSelectedDependancy.ReadOnly = true;
            this.txtSelectedDependancy.Size = new System.Drawing.Size(63, 21);
            this.txtSelectedDependancy.TabIndex = 19;
            // 
            // txtSelectedPercapita
            // 
            this.txtSelectedPercapita.Location = new System.Drawing.Point(105, 150);
            this.txtSelectedPercapita.Name = "txtSelectedPercapita";
            this.txtSelectedPercapita.ReadOnly = true;
            this.txtSelectedPercapita.Size = new System.Drawing.Size(63, 21);
            this.txtSelectedPercapita.TabIndex = 16;
            // 
            // txtSelectedCompability
            // 
            this.txtSelectedCompability.Location = new System.Drawing.Point(105, 46);
            this.txtSelectedCompability.Name = "txtSelectedCompability";
            this.txtSelectedCompability.ReadOnly = true;
            this.txtSelectedCompability.Size = new System.Drawing.Size(63, 21);
            this.txtSelectedCompability.TabIndex = 9;
            // 
            // txtSelectedSuitablity
            // 
            this.txtSelectedSuitablity.Location = new System.Drawing.Point(105, 98);
            this.txtSelectedSuitablity.Name = "txtSelectedSuitablity";
            this.txtSelectedSuitablity.ReadOnly = true;
            this.txtSelectedSuitablity.Size = new System.Drawing.Size(63, 21);
            this.txtSelectedSuitablity.TabIndex = 18;
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(525, 212);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 39;
            this.btnFind.Text = "Find =>";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // btn_BinToSHP
            // 
            this.btn_BinToSHP.Location = new System.Drawing.Point(662, 433);
            this.btn_BinToSHP.Name = "btn_BinToSHP";
            this.btn_BinToSHP.Size = new System.Drawing.Size(148, 23);
            this.btn_BinToSHP.TabIndex = 40;
            this.btn_BinToSHP.Text = "Convert Bin to shp Directly";
            this.btn_BinToSHP.UseVisualStyleBackColor = true;
            this.btn_BinToSHP.Click += new System.EventHandler(this.btn_BinToSHP_Click);
            // 
            // btnSelectItrBIN
            // 
            this.btnSelectItrBIN.Location = new System.Drawing.Point(564, 74);
            this.btnSelectItrBIN.Name = "btnSelectItrBIN";
            this.btnSelectItrBIN.Size = new System.Drawing.Size(220, 23);
            this.btnSelectItrBIN.TabIndex = 41;
            this.btnSelectItrBIN.Text = "Select Directly Iteration BIN File";
            this.btnSelectItrBIN.UseVisualStyleBackColor = true;
            this.btnSelectItrBIN.Click += new System.EventHandler(this.btnSelectItrBIN_Click);
            // 
            // frmConstructFinalMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 490);
            this.Controls.Add(this.btnSelectItrBIN);
            this.Controls.Add(this.btn_BinToSHP);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtResultPath);
            this.Controls.Add(this.btn_BrowseResultFolder);
            this.Controls.Add(this.label1);
            this.Name = "frmConstructFinalMap";
            this.Text = "frmConstructFinalMap";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Construct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtResultPath;
        private System.Windows.Forms.Button btn_BrowseResultFolder;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCompability;
        private System.Windows.Forms.TextBox txtUBCompability;
        private System.Windows.Forms.TextBox txtUBDependancy;
        private System.Windows.Forms.TextBox txtUBSuitability;
        private System.Windows.Forms.TextBox txtUBCompactness;
        private System.Windows.Forms.TextBox txtUBPercapita;
        private System.Windows.Forms.TextBox txtPercapita;
        private System.Windows.Forms.TextBox txtCompactness;
        private System.Windows.Forms.TextBox txtSuitablity;
        private System.Windows.Forms.TextBox txtDependancy;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox cbxPercapita;
        private System.Windows.Forms.CheckBox cbxCompactness;
        private System.Windows.Forms.CheckBox cbxSuitability;
        private System.Windows.Forms.CheckBox cbxDependancey;
        private System.Windows.Forms.CheckBox cbxCompability;
        private System.Windows.Forms.TextBox txtLBPercapita;
        private System.Windows.Forms.TextBox txtLBCompability;
        private System.Windows.Forms.TextBox txtLBCompactness;
        private System.Windows.Forms.TextBox txtLBDependancy;
        private System.Windows.Forms.TextBox txtLBSuitability;
        private System.Windows.Forms.TextBox txtIterNo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtSelectedCompactness;
        private System.Windows.Forms.TextBox txtSelectedDependancy;
        private System.Windows.Forms.TextBox txtSelectedPercapita;
        private System.Windows.Forms.TextBox txtSelectedCompability;
        private System.Windows.Forms.TextBox txtSelectedSuitablity;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btn_BinToSHP;
        private System.Windows.Forms.Button btnSelectItrBIN;
    }
}