﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LandUsePlanning.NSGAOptimization;
using LandUsePlanning.Classes;
using ESRI.ArcGIS.Geodatabase;
using System.IO;
using ESRI.ArcGIS.Geometry;

namespace LandUsePlanning.WinForms
{
    public partial class frmConstructFinalMap : Form
    {
        List<SolutionH> Pop = null;
        SolutionH nearestSol = null;
        private IFeatureClass fc_Parcells;

        public frmConstructFinalMap(IFeatureClass fc_Par)
        {
            InitializeComponent();
            fc_Parcells = fc_Par;
        }

        private void cbxCompability_CheckedChanged(object sender, EventArgs e)
        {
            txtCompability.ReadOnly = !cbxCompability.Checked;
        }

        private void cbxDependancey_CheckedChanged(object sender, EventArgs e)
        {
            txtDependancy.ReadOnly = !cbxDependancey.Checked;
        }

        private void cbxSuitability_CheckedChanged(object sender, EventArgs e)
        {
            txtSuitablity.ReadOnly = !cbxSuitability.Checked;
        }

        private void cbxCompactness_CheckedChanged(object sender, EventArgs e)
        {
            txtCompactness.ReadOnly = !cbxCompactness.Checked;
        }

        private void cbxPercapita_CheckedChanged(object sender, EventArgs e)
        {
            txtPercapita.ReadOnly = !cbxPercapita.Checked;
        }
        string txtSelectedItr;
        private void btn_BrowseResultFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            FBD.SelectedPath = Settings.Default.DataForRun;

            if (FBD.ShowDialog() == DialogResult.OK)
            {
                if (!FBD.SelectedPath.Contains(Settings.Default.resultFolder))
                {
                    MessageBox.Show("Selected result is not compatible with " + Settings.Default.resultFolder);
                    return;
                }
                if (FBD.SelectedPath.Contains("NSGA"))
                {
                    var parameters = FBD.SelectedPath.Substring(FBD.SelectedPath.IndexOf("NSGA")).Split(',');
                    txtResultPath.Text = FBD.SelectedPath + "\\";
                    txtIterNo.Text = parameters[1];
                    txtSelectedItr= parameters[1];

                    getObjectiveRanges();
                }
                else
                {
                    MessageBox.Show(FBD.SelectedPath + " is not Correct folder Path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void getObjectiveRanges()
        {
            Pop = BinarySerialization.ReadFromBinaryFile<List<SolutionH>>(txtResultPath.Text + "Iteration_" + txtIterNo.Text + "_Population.bin");
            
            
           
            ///////////////////////////////////////////////////////////////////////
            txtUBCompability.Text = Math.Round(-Pop.Select(s => s.Fitness[0]).Min(), 4).ToString();
            txtLBCompability.Text = Math.Round(-Pop.Select(s => s.Fitness[0]).Max(), 4).ToString();
            ///////////////////////////////////////////////////////////////////////
            txtUBDependancy.Text = Math.Round(-Pop.Select(s => s.Fitness[1]).Min(), 4).ToString();
            txtLBDependancy.Text = Math.Round(-Pop.Select(s => s.Fitness[1]).Max(), 4).ToString();
            ///////////////////////////////////////////////////////////////////////
            txtUBSuitability.Text = Math.Round(-Pop.Select(s => s.Fitness[2]).Min(), 4).ToString();
            txtLBSuitability.Text = Math.Round(-Pop.Select(s => s.Fitness[2]).Max(), 4).ToString();
            ///////////////////////////////////////////////////////////////////////
            txtUBCompactness.Text = Math.Round(-Pop.Select(s => s.Fitness[3]).Min(), 4).ToString();
            txtLBCompactness.Text = Math.Round(-Pop.Select(s => s.Fitness[3]).Max(), 4).ToString();
            ///////////////////////////////////////////////////////////////////////
            txtLBPercapita.Text = Math.Round(Pop.Select(s => s.Fitness[4]).Min(), 4).ToString();
            txtUBPercapita.Text = Math.Round(Pop.Select(s => s.Fitness[4]).Max(), 4).ToString();

        }

        private void FindnearestSol()
        {
            int obj0 = Convert.ToInt32( cbxCompability.Checked);
            int obj1 = Convert.ToInt32( cbxDependancey.Checked);
            int obj2 = Convert.ToInt32(cbxSuitability.Checked);
            int obj3 = Convert.ToInt32(cbxCompactness.Checked);
            int obj4 = Convert.ToInt32(cbxPercapita.Checked);

            double minDist = double.MaxValue;
            
            foreach (SolutionH sol in Pop)
            {
                double D0 = Math.Pow((-sol.Fitness[0] - Convert.ToDouble(txtCompability.Text)), 2);
                double D1 = Math.Pow((-sol.Fitness[1] - Convert.ToDouble(txtDependancy.Text)), 2);
                double D2 = Math.Pow((-sol.Fitness[2] - Convert.ToDouble(txtSuitablity.Text)), 2);
                double D3 = Math.Pow((-sol.Fitness[3] - Convert.ToDouble(txtCompactness.Text)), 2);
                double D4 = Math.Pow((sol.Fitness[4] - Convert.ToDouble(txtPercapita.Text)), 2);

                double Distance = Math.Sqrt(D0 * obj0 + D1 * obj1 + D2 * obj2 + D3 * obj3 + D4 * obj4);
                if (Distance < minDist)
                {
                    minDist = Distance;
                    nearestSol = sol;
                }
            }
            txtSelectedCompability.Text = Math.Round(-nearestSol.Fitness[0],4).ToString();
            txtSelectedDependancy.Text = Math.Round(-nearestSol.Fitness[1],4).ToString();
            txtSelectedSuitablity.Text = Math.Round(-nearestSol.Fitness[2],4).ToString();
            txtSelectedCompactness.Text = Math.Round(-nearestSol.Fitness[3],4).ToString();
            txtSelectedPercapita.Text = Math.Round(nearestSol.Fitness[4],4).ToString();

            
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            FindnearestSol();
            btn_Construct.Enabled = true;
        }

        private void btn_Construct_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            SaveSolutionToShapefile();
            this.Cursor = Cursors.Default;
            MessageBox.Show("Shape File is Created in Selected path.", "Succesful", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
        }

        private void SaveSolutionToShapefile()
        {
            DateTime dt = DateTime.Now;
            string DataFolderName = txtResultPath.Text + "ShapeFiles\\Itr=" + txtSelectedItr + ",Objs=" +
                                    txtSelectedCompability.Text + "," +
                                    txtSelectedDependancy.Text + "," +
                                    txtSelectedSuitablity.Text + "," +
                                    txtSelectedCompactness.Text + "," +
                                    txtSelectedPercapita.Text + "\\" ;
                                
            System.IO.Directory.CreateDirectory(DataFolderName);

            IFeature feature = fc_Parcells.GetFeature(1);
            IFeatureClass fc_new = CreateShapeFile(DataFolderName + "Map", feature.Shape);
            int LUIdx = fc_new.Fields.FindField("LUCode");
            int LU1Idx = fc_new.Fields.FindField("LUCode1");
            int AcceptancesIdx = fc_new.Fields.FindField("Accept");
            IFeatureCursor cursor=fc_Parcells.Search(null, true);
            IFeature parcell;
            bool hasAcceptances = false;
            //if (nearestSol.Game_Acceptances.Count > 0)
            //{ hasAcceptances = true; }
            if (StartEditing((fc_new as IDataset).Workspace))
            {

                while ((parcell = cursor.NextFeature()) != null)
                {
                    IFeature newFeature = fc_new.CreateFeature();
                    newFeature.Shape = parcell.Shape;
                    newFeature.set_Value(LUIdx, nearestSol.Landuses[Convert.ToInt16(parcell.OID)]);
                    newFeature.set_Value(LU1Idx, getLUCode1(nearestSol.Landuses[Convert.ToInt16(parcell.OID)]));
                    if (hasAcceptances)
                    {
                        IList<bool> values = nearestSol.Game_Acceptances[Convert.ToInt16(parcell.OID)].Values;
                        int trues = values.Count(s => s == true);
                        newFeature.set_Value(AcceptancesIdx, Convert.ToInt16(trues));

                    }
                    newFeature.Store();
                }

            out1:
                try
                {

                    StopEditing((fc_new as IDataset).Workspace);
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                    goto out1;

                }
            }
            else
            {
                MessageBox.Show("Error in OptimalityToshp: Editing don't start!!!");
            }
        }
        private void SaveSolutionToShapefile(SolutionH SolH, string path)
        {
            DateTime dt = DateTime.Now;

            System.IO.Directory.CreateDirectory(path);

            IFeature feature = fc_Parcells.GetFeature(1);
            IFeatureClass fc_new = CreateShapeFile(path + "Map", feature.Shape);
            int LUIdx = fc_new.Fields.FindField("LUCode");
            int LU1Idx = fc_new.Fields.FindField("LUCode1");
            int AcceptancesIdx = fc_new.Fields.FindField("Accept");
            int PTAIdx = fc_new.Fields.FindField("PTA");
            int Disatisfied = fc_new.Fields.FindField("disat");
            IFeatureCursor cursor = fc_Parcells.Search(null, true);
            IFeature parcell;
            bool hasAcceptances = false;
            if (SolH.Game_Acceptances.Count > 0)
            { hasAcceptances = true; }
            bool hasPTA = false;
            if (SolH.ParcelsTotalAccepts!=null)
            { hasPTA = true; }
            if (StartEditing((fc_new as IDataset).Workspace))
            {

                while ((parcell = cursor.NextFeature()) != null)
                {
                    IFeature newFeature = fc_new.CreateFeature();
                    newFeature.Shape = parcell.Shape;
                    newFeature.set_Value(LUIdx, SolH.Landuses[Convert.ToInt16(parcell.OID)]);
                    newFeature.set_Value(LU1Idx, getLUCode1(SolH.Landuses[Convert.ToInt16(parcell.OID)]));
                    if (SolH.DissatisfiedOIDs.Contains(Convert.ToInt16(parcell.OID)))
                    {
                        newFeature.set_Value(Disatisfied, 1);
                    }
                    foreach(short DisOID in SolH.DissatisfiedOIDs)
                    if(hasAcceptances)
                    {
                        IList<bool> values = SolH.Game_Acceptances[Convert.ToInt16(parcell.OID)].Values;
                        int trues = values.Count(s => s == true);
                    newFeature.set_Value(AcceptancesIdx, Convert.ToInt16(trues));

                    }
                    if (hasPTA)
                    {
                        newFeature.set_Value(PTAIdx, SolH.ParcelsTotalAccepts[Convert.ToInt16(parcell.OID)]);
                    }
                    newFeature.Store();
                }

            out1:
                try
                {

                    StopEditing((fc_new as IDataset).Workspace);
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                    goto out1;

                }
            }
            else
            {
                MessageBox.Show("Error in OptimalityToshp: Editing don't start!!!");
            }
        }
        private int getLUCode1(short LUCode)
        {
            int LUCode1=100;
            if(LUCode == 0 || LUCode==1 || LUCode==2)
            {
                LUCode1 = 1;
            }
            else if (LUCode == 3 || LUCode == 4 || LUCode == 5)
            {
                LUCode1 = 2;
            }
            else if (LUCode == 6 || LUCode == 7 || LUCode == 8 || LUCode == 9 || LUCode == 10 || LUCode == 11)
            {
                LUCode1 = 3;
            }
            else if (LUCode == 12 || LUCode == 13 || LUCode == 14)
            {
                LUCode1 = 4;
            }
            else if (LUCode == 15 || LUCode == 16 || LUCode == 17)
            {
                LUCode1 = 5;
            }
            else if (LUCode == 18 || LUCode == 19 || LUCode == 20)
            {
                LUCode1 = 6;
            }
            else if (LUCode == 21 || LUCode == 22 || LUCode == 23)
            {
                LUCode1 = 7;
            }
            else if (LUCode == 24 || LUCode == 25 || LUCode == 26)
            {
                LUCode1 = 8;
            }
            else if (LUCode == 27 || LUCode == 28 || LUCode == 29)
            {
                LUCode1 = 9;
            }
            else if (LUCode == 30 || LUCode == 31 || LUCode == 32 || LUCode == 33)
            {
                LUCode1 = 10;
            }
            else if (LUCode == 34 || LUCode == 35 || LUCode == 36)
            {
                LUCode1 = 11;
            }
            else if (LUCode == 37)
            {
                LUCode1 = 0;
            }
            return LUCode1;
        }


        



        private IFeatureClass CreateShapeFile(string shpFilepath, IGeometry geom)
        {
        out2:
            try
            {
                System.IO.FileInfo fi = new FileInfo(shpFilepath);
                var wsf = Activator.CreateInstance(Type.GetTypeFromProgID("esriDataSourcesFile.ShapefileWorkspaceFactory")) as IWorkspaceFactory;
                var fws = wsf.OpenFromFile(fi.DirectoryName, 0) as IFeatureWorkspace;
                IFieldsEdit flds = new FieldsClass();
                flds.AddField(MakeField("ObjectID", esriFieldType.esriFieldTypeOID, 0));
                IGeometryDefEdit geomDef = new GeometryDefClass();
                geomDef.GeometryType_2 = geom.GeometryType;
                geomDef.SpatialReference_2 = geom.SpatialReference;
                var shpField = MakeField("Shape", esriFieldType.esriFieldTypeGeometry, 0) as IFieldEdit;
                shpField.GeometryDef_2 = geomDef;
                flds.AddField(shpField);
                flds.AddField(MakeField("LUCode", esriFieldType.esriFieldTypeString, 16));
                flds.AddField(MakeField("LUCode1", esriFieldType.esriFieldTypeInteger, 16));
                flds.AddField(MakeField("Accept", esriFieldType.esriFieldTypeInteger, 16));
                flds.AddField(MakeField("PTA", esriFieldType.esriFieldTypeInteger, 16));
                flds.AddField(MakeField("disat", esriFieldType.esriFieldTypeInteger, 16));
                string fcName = fi.Name;
                if (fcName.ToUpper().EndsWith(".SHP"))
                    fcName = fcName.Substring(0, fcName.LastIndexOf("."));

                var fc = fws.CreateFeatureClass(fcName, flds, null, null, esriFeatureType.esriFTSimple, "Shape", "");

                return fc;
            }
            catch (Exception x)
            {
                //MessageBox.Show("Error CreateShapeFile Method: " + x.Message);
                //return null;
                goto out2;
            }
        }

        private IField MakeField(string name, esriFieldType fType, int length)
        {
            IFieldEdit fld = new FieldClass();
            fld.Name_2 = name;
            fld.Type_2 = fType;
            if (length > 0 && fType == esriFieldType.esriFieldTypeString)
                fld.Length_2 = length;
            return fld;
        }



        private static bool StartEditing(IWorkspace workspace)
        {
            try
            {
                if (workspace == null)
                    MessageBox.Show("error in workspace");

                IWorkspaceEdit pWorkSpcEdit = (IWorkspaceEdit)workspace;

                if (!pWorkSpcEdit.IsBeingEdited())
                {
                    pWorkSpcEdit.StartEditing(false);
                    pWorkSpcEdit.StartEditOperation();
                }
                else
                {
                    pWorkSpcEdit.StartEditOperation();
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("startEditing: " + ex.Message);
                return false;
            }
        }

        private static bool StopEditing(IWorkspace workspace)
        {
            try
            {
                if (workspace == null)
                    MessageBox.Show("error in workspace");

                IWorkspaceEdit pWorkSpcEdit = (IWorkspaceEdit)workspace;
                if (pWorkSpcEdit.IsBeingEdited())
                {
                    pWorkSpcEdit.StopEditOperation();
                    pWorkSpcEdit.StopEditing(true);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("startEditing: " + ex.Message);
                return false;
            }
        }

        private void btn_BinToSHP_Click(object sender, EventArgs e)
        {
            
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Binarry File|*.bin";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                SolutionH SolH = BinarySerialization.ReadFromBinaryFile<SolutionH>(ofd.FileName);
                string path = ofd.FileName.Replace(".bin","\\");

                SaveSolutionToShapefile(SolH,path);

                MessageBox.Show("Shape File is Created in Selected path.", "Succesful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSelectItrBIN_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Binarry File|*.bin";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                
                if (ofd.FileName.Contains("Iteration"))
                {
                    string path = ofd.FileName.Replace(ofd.SafeFileName, "");
                    var parameters = ofd.FileName.Substring(ofd.FileName.IndexOf("Iteration")).Split('_');
                    txtResultPath.Text = path;
                    txtIterNo.Text = parameters[1];
                    txtSelectedItr = parameters[1];

                    getObjectiveRanges();

                }
                else
                {
                    MessageBox.Show(ofd.FileName + " is not Correct folder Path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
        }

        private void txtSelectedItr_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
