﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LandUsePlanning.NSGAOptimization;
using LandUsePlanning.Classes;
using System.IO;
using MathLib;

namespace LandUsePlanning.NSGAOptimization
{
    class NSGAIII
    {
        List<Parcel> parcels = null;
        List<LandUse> LUClassList = new List<LandUse>();
        static Random rand = new Random(Guid.NewGuid().GetHashCode());
        double[,] MinMaxLUCode1Areas;
        private MathLib.Matrix EffectRadiuses;
        private MathLib.Matrix Compatibilities;
        private MathLib.Matrix Dependancies;
        public NSGAIII()
        {
            parcels = Classes.BinarySerialization.ReadFromBinaryFile<List<Parcel>>(Settings.Default.parcelsBinAdress);
            Settings.Default.NoOFParcels = parcels.Count;
 
            MinMaxLUCode1Areas = GetDataFromTXT(Settings.Default.DataForRun + "PerCapitaAreas.txt");

            var Dep = GetDataFromTXT(Settings.Default.DataForRun + "Dependancies_Full.txt");
            var CMP = GetDataFromTXT(Settings.Default.DataForRun + "Compabilities_Full.txt");
            var ER = GetDataFromTXT(Settings.Default.DataForRun + "Effect Radius.txt");

            EffectRadiuses = new Matrix(ER);
            Compatibilities = new Matrix(CMP);
            Dependancies = new Matrix(Dep);
            setLUList();
        }

        public void Run()
        {
            #region Results Folder Creation
            DateTime dt = DateTime.Now;
            string DataFolderName = Settings.Default.DataForRun + "Results\\" + Settings.Default.resultFolder + "\\" +
                "NSGAIII," + Settings.Default.Iteration.ToString() +
                                "," + Settings.Default.InitialPopulation.ToString() +
                                "," + Settings.Default.CrossoverPercent.ToString() +
                                "," + Settings.Default.MutationRate.ToString() +
                                "," + Settings.Default.CrossTourSize.ToString() +
                                "," + Settings.Default.NSGAIIIRefDivisionParts.ToString() +
                                "," + dt.Year.ToString() +
                                "," + dt.Month.ToString() +
                                "," + dt.Day.ToString() +
                                "," + dt.Hour.ToString() +
                                "," + dt.Minute.ToString();
            if (!System.IO.Directory.Exists(DataFolderName))
            {
                System.IO.Directory.CreateDirectory(DataFolderName);
            }
            else
            {
                DataFolderName += "(2)";
                System.IO.Directory.CreateDirectory(DataFolderName);
            }
            #endregion
            List<double[]> Refpoints = GetRefPoints();
            int PopSize = Settings.Default.InitialPopulation;
            List<SolutionH> PRC = InitilalizePops(PopSize);
            List<SolutionH> Population = new List<SolutionH>(PopSize);
            Population.AddRange(PRC);
            List<List<SolutionH>> Fronts = RankDominance(Population);
            int Itr = Settings.Default.Iteration;
            //---------------------------------------------------------------------
            Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + 0 + "_Population.bin", Population, false);
            for (int i = 0; i < Itr; i++)
            {
                List<SolutionH> Crossover_Population = Crossover3(Population);
                //--------------------------------------------------------
                List<SolutionH> Mutation_Population = MutationConstraintBased(Population, i);
                //--------------------------------------------------------
                Population.AddRange(Crossover_Population);
                Population.AddRange(Mutation_Population);
                //-----------------------------------------------------------------------------
                List<SolutionH> TopMu_Population = TopSolutionMutationConstraitBased(Population);
                Population.AddRange(TopMu_Population);
                //IdentifyElites(Population);
                //----------------------------------------------------------------------------
                Fronts = RankDominance(Population);

                List<SolutionH> Selected_Pop = new List<SolutionH>(Population.Count);
                List<SolutionH> Front_Last;
                List<SolutionH> PopNext = new List<SolutionH>(PopSize);
                int LastFrontIdx = 0;
                for (int idx = 0; idx < Fronts.Count; idx++)
                {
                    Selected_Pop.AddRange(Fronts[idx]);
                    if (Selected_Pop.Count >= PopSize)
                    {
                        LastFrontIdx = idx;
                        break;
                    }
                }
                if (Selected_Pop.Count == PopSize)
                {
                    Population = new List<SolutionH>(Selected_Pop);
                    break;
                }
                else
                {
                    for (int idx2 = 0; idx2 < LastFrontIdx; idx2++)
                    {
                        PopNext.AddRange(Fronts[idx2]);
                    }
                    Front_Last = new List<SolutionH>(Fronts[LastFrontIdx]);
                    //Points to be chosen from Flast:
                    int K = PopSize - PopNext.Count;

                    List<SolutionH> NPopNext = Normalize(PopNext);
                    List<SolutionH> NFront_Last = Normalize(Front_Last);
                    List<SolutionH> ANNextPop = Niching(Refpoints, NPopNext, NFront_Last, K);

                    Population = new List<SolutionH>(ANNextPop);
                    Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + (i + 1) + "_Population.bin", Population, false);
                }

            }
        }

        private List<SolutionH> InitilalizePops(int popsize)
        {
            List<SolutionH> Pop = new List<SolutionH>(popsize);
            for (int i = 0; i < popsize; i++)
            {
                SolutionH solh = InitializePopswihoutpercapitaconstraint();
                Pop.Add(solh);
            }
            return Pop;

        }
        private SolutionH InitializePopswihoutpercapitaconstraint()
        {
            List<int> AcceptableLUsCounts = new List<int>(Settings.Default.NoOFParcels);
        FirstLine:
            SortedList<short, short> newLU = new SortedList<short, short>(Settings.Default.NoOFParcels);
            double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
            //List<Parcel> newParcels = parcels.OrderByDescending(a => a.).ThenByDescending(a=>a.AccessType).ToList<Parcel>();
            List<Parcel> newParcels = parcels.OrderBy(a => Guid.NewGuid()).ToList<Parcel>();
            List<Parcel> UnassignedParcels = new List<Parcel>();
            foreach (Parcel p in newParcels)
            {
                if (p.Area <= 0)
                {
                    p.Area = -p.Area;
                }
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                //AcceptableLUsCounts.Add(AcceptableLUs.Count);
                short r = 0;
                int LUCode1 = 0;
                if (AcceptableLUs.Count != 0)
                {
                    r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                    LUCode1 = AcceptableLUs[r].LUCode1;
                }
                bool isParcelLUAsigned = false;
                while (!isParcelLUAsigned && AcceptableLUs.Count != 0)
                {
                    if (LUCode1 == 1)
                    {
                        if (p.Area <= 300)
                        {
                            LUCode1Area[LUCode1] += p.Area * 1.6;
                        }
                        else if (p.Area > 300 & p.Area <= 450)
                        {
                            LUCode1Area[LUCode1] += p.Area * 1.8;
                        }
                        else if (p.Area > 450 & p.Area <= 550)
                        {
                            LUCode1Area[LUCode1] += p.Area * 2;
                        }
                        else
                        {
                            LUCode1Area[LUCode1] += p.Area * 2.2;
                        }
                        newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                        isParcelLUAsigned = true;

                    }
                    else
                    {
                        LUCode1Area[LUCode1] += p.Area;
                        newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                        isParcelLUAsigned = true;
                    }
                }
                if (!isParcelLUAsigned)
                {
                    UnassignedParcels.Add(p);
                }
            }

            foreach (Parcel p in UnassignedParcels)
            {
                //Assigning reminging parcels
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                List<LandUse> SelectableLUs = new List<LandUse>();
                foreach (LandUse LU in AcceptableLUs)
                {
                    if (MinMaxLUCode1Areas[LU.LUCode1, 1] - LUCode1Area[LU.LUCode1] > p.Area)
                    {
                        SelectableLUs.Add(LU);
                    }
                }
                if (SelectableLUs.Count != 0)
                {
                    int r = rand.Next(SelectableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), SelectableLUs[r].LUNo);
                }
                else if (AcceptableLUs.Count != 0)
                {
                    int r = rand.Next(AcceptableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                }
                else
                {
                    newLU.Add(Convert.ToInt16(p.OID), Convert.ToInt16(rand.Next(36)));
                }

            }
            if (newLU.Count < Settings.Default.NoOFParcels)
            {
                //goto FirstLine;
            }
            SolutionH SolH = new SolutionH(newLU);
            CalculateFitness(SolH);
            //MessageBox.Show(AcceptableLUsCounts.Average().ToString());
            return SolH;
        }
        public void CalculateFitness(SolutionH SolH)
        {
            double[] Compability_Result = new double[Settings.Default.NoOFParcels + 1];
            double[] Dependancy_Result = new double[Settings.Default.NoOFParcels + 1];
            double[] Compactness_Result = new double[Settings.Default.NoOFParcels + 1];
            double[] Suitability_Result = new double[Settings.Default.NoOFParcels + 1];
            double[] NumOfNeigbors_Result = new double[Settings.Default.NoOFParcels + 1];
            double CMPLU1LU2;
            double DepLU1LU2;
            SortedList<short, short> LUs = SolH.Landuses;
            foreach (Parcel parcel in parcels)
            {
                int parcel_LUCode = LUs[Convert.ToInt16(parcel.OID)];
                int effectRadius = Convert.ToInt32(EffectRadiuses.val[parcel_LUCode, 0]);
                double FeatureCompability = 0;
                double FeatureDependancy = 0;
                double FeatureCompactness = 0;
                int NumOfNeighbors = 0;
                IList<short> neighs = parcel.NeigberHood[parcel_LUCode];
                foreach (short neighOID in neighs)
                {
                    double min_distOfPN = parcel.minDistOfneighber[neighOID];

                    double Alfa = Math.Abs(effectRadius - min_distOfPN) / effectRadius;

                    int neighfeature_LUCode = LUs[neighOID];
                    CMPLU1LU2 = Compatibilities.val[parcel_LUCode, neighfeature_LUCode];
                    DepLU1LU2 = Dependancies.val[parcel_LUCode, neighfeature_LUCode];
                    FeatureCompability = FeatureCompability + Alfa * CMPLU1LU2;
                    FeatureDependancy = FeatureDependancy + Alfa * DepLU1LU2;

                    if (parcel_LUCode == neighfeature_LUCode)
                    {
                        FeatureCompactness++;
                    }
                    NumOfNeighbors++;
                }
                Compability_Result[parcel.OID] = FeatureCompability / NumOfNeighbors;
                Dependancy_Result[parcel.OID] = FeatureDependancy / NumOfNeighbors;
                Compactness_Result[parcel.OID] = FeatureCompactness / NumOfNeighbors;
                Suitability_Result[parcel.OID] = parcel.suitability[parcel_LUCode];
                NumOfNeigbors_Result[parcel.OID] = NumOfNeighbors;

            }
            double[] Objectives = new double[Settings.Default.NoOFObj];
            Objectives[0] = -(Compability_Result.Sum() / Compability_Result.Length + Compability_Result.Min());
            Objectives[1] = -(Dependancy_Result.Sum() / Dependancy_Result.Length + Dependancy_Result.Min());
            Objectives[2] = -(Suitability_Result.Sum() / Suitability_Result.Length + Suitability_Result.Min());
            Objectives[3] = -(Compactness_Result.Sum() / Compactness_Result.Length);
            Objectives[4] = CalculateConstraintViolationForLUCode1AreaV2(SolH);
            SolH.Fitness = Objectives;
           
        }
        public double[] CalculateFitness(int OID, SolutionH SolH, short pLU, short obj)
        {
            double CMPLU1LU2;
            double DepLU1LU2;
            Parcel parcel = parcels.Find(p => p.OID == OID);
            SortedList<short, short> LUs = SolH.Landuses;
            int effectRadius = Convert.ToInt32(EffectRadiuses.val[pLU, 0]);
            double FeatureCompability = 0;
            double FeatureDependancy = 0;
            double FeatureCompactness = 0;
            int NumOfNeighbors = 0;
            IList<short> neighs = parcel.NeigberHood[pLU];
            foreach (short neighOID in neighs)
            {
                double min_distOfPN = parcel.minDistOfneighber[neighOID];

                double Alfa = Math.Abs(effectRadius - min_distOfPN) / effectRadius;

                int neighfeature_LUCode = LUs[neighOID];
                CMPLU1LU2 = Compatibilities.val[pLU, neighfeature_LUCode];
                DepLU1LU2 = Dependancies.val[pLU, neighfeature_LUCode];
                FeatureCompability = FeatureCompability + Alfa * CMPLU1LU2;
                FeatureDependancy = FeatureDependancy + Alfa * DepLU1LU2;

                if (pLU == neighfeature_LUCode)
                {
                    FeatureCompactness++;
                }
                NumOfNeighbors++;
            }
            double[] Objectives = new double[Settings.Default.NoOFObj];
            Objectives[0] = -FeatureCompability / NumOfNeighbors;
            Objectives[1] = -FeatureDependancy / NumOfNeighbors;
            Objectives[2] = -parcel.suitability[pLU];
            Objectives[3] = -FeatureCompactness / NumOfNeighbors;
            SortedList<short, short> nLUs = new SortedList<short, short>(LUs);
            nLUs[Convert.ToInt16(OID)] = pLU;
            if (obj == 4)
            {
                Objectives[4] = CalculateCV(Convert.ToInt16(OID), SolH, pLU);
            }
            else
            {
                Objectives[4] = double.MaxValue;
            }
            return Objectives;
        }


        private int SelectFromPopulation(List<SolutionH> pop)
        {
            Random R = new Random();
            int BestPopID;
            BestPopID = R.Next(0, pop.Count);
            if (pop[BestPopID].isElite)
            {
                return BestPopID;
            }
            for (int i = 0; i < Settings.Default.CrossTourSize; i++)
            {
                int ID = R.Next(0, pop.Count);
                if (pop[ID].isElite)
                {
                    return ID;
                }
                if (pop[ID].FrontRank == pop[BestPopID].FrontRank)
                {
                    if (pop[ID].HNSGAneighborCount < pop[BestPopID].HNSGAneighborCount)
                    {
                        BestPopID = ID;
                    }
                }
                else
                {
                    if (pop[ID].FrontRank < pop[BestPopID].FrontRank)
                    {
                        BestPopID = ID;
                    }
                }

            }
            return BestPopID;
        }


        private List<SolutionH> Crossover3(List<SolutionH> pop)
        {

            int NoOfpar = Settings.Default.NoOFParcels;
            int CrossPopCount = Convert.ToInt32(pop.Count * Settings.Default.CrossoverPercent);
            List<SolutionH> Cross_pop = new List<SolutionH>(CrossPopCount);

            for (int i = 0; i < CrossPopCount; i = i + 2)
            {
                List<SolutionH> popForCross = new List<SolutionH>(pop);

                int p1 = SelectFromPopulation(popForCross);
                SolutionH par1 = popForCross[p1];

                popForCross.Remove(par1);

                int p2 = SelectFromPopulation(popForCross);
                SolutionH par2 = popForCross[p2];

                SortedList<short, short> ch1LU = new SortedList<short, short>(NoOfpar);
                SortedList<short, short> ch2LU = new SortedList<short, short>(NoOfpar);
                int NoOfSections = rand.Next(1, 100);
                for (int i2 = 0; i2 < NoOfSections; i2++)
                {
                    bool NotValid = true;
                    int SecSize = rand.Next((i2 * NoOfpar / NoOfSections) + 1, NoOfpar * (i2 + 2) / NoOfSections);
                    if (SecSize > NoOfpar)
                    {
                        SecSize = NoOfpar;
                        NotValid = false;
                    }
                    //This "while" checks that crossover occur from a place that at least 4 consecutive landuses are the same.
                    /*
                    while (NotValid)
                    {
                        NotValid = false;
                        for (int t = SecSize; t < SecSize + 1; t++)
                        {
                            if (pop[par1].Landuses[Convert.ToInt16(t)] != pop[par1].Landuses[Convert.ToInt16(t + 1)])
                            {
                                NotValid = true;
                                SecSize = rand.Next(2,NoOfpar * (i2 + 2) / NoOfSections);
                                if (SecSize > NoOfpar)
                                {
                                    SecSize = NoOfpar;
                                    NotValid = false;
                                }
                                break;
                            }
                        }
                    }
                     * */
                    ///////////////////////////////////////////////////////////////////////////////////////////////////////
                    short childSize = Convert.ToInt16(ch1LU.Count);
                    bool parSelector = Convert.ToBoolean(Math.IEEERemainder(i2, 2));
                    for (short j = childSize; j < SecSize; j++)
                    {
                        if (parSelector)
                        {
                            ch1LU.Add(j, par1.Landuses[j]);
                            ch2LU.Add(j, par2.Landuses[j]);
                        }
                        else
                        {
                            ch1LU.Add(j, par2.Landuses[j]);
                            ch2LU.Add(j, par1.Landuses[j]);
                        }

                    }

                }
                short childSize2 = Convert.ToInt16(ch1LU.Count);
                bool parSelector2 = Convert.ToBoolean(Math.IEEERemainder(NoOfSections, 2));
                for (short j = childSize2; j < NoOfpar; j++)
                {
                    if (parSelector2)
                    {
                        ch1LU.Add(j, par1.Landuses[j]);
                        ch2LU.Add(j, par2.Landuses[j]);
                    }
                    else
                    {
                        ch1LU.Add(j, par2.Landuses[j]);
                        ch2LU.Add(j, par1.Landuses[j]);
                    }

                }
                SolutionH Sol_ch1 = new SolutionH(ch1LU);
                SolutionH Sol_ch2 = new SolutionH(ch2LU);

                //SaveLandusesToNewShapefile(par1.Landuses);
                //SaveLandusesToNewShapefile(par2.Landuses);

                //SaveLandusesToNewShapefile(ch1LU);
                //SaveLandusesToNewShapefile(ch2LU);

                CalculateFitness(Sol_ch1);
                //Sol_ch1.ConstraintViolation = CalculateConstraintViolation(ch1LU);
                CalculateFitness(Sol_ch2);
                //Sol_ch2.ConstraintViolation = CalculateConstraintViolation(ch2LU);

                Cross_pop.Add(Sol_ch1);
                Cross_pop.Add(Sol_ch2);
            }

            return Cross_pop;
        }


        private List<SolutionH> MutationConstraintBased(List<SolutionH> pop, int itr)
        {
            List<SolutionH> Mutpop = new List<SolutionH>();
            int MutCount = Convert.ToInt32(Settings.Default.InitialPopulation * Settings.Default.MutationRate);
            for (int i = 0; i < MutCount; i++)
            {

                int SolForMuID = rand.Next(0, pop.Count - 1);
                SolutionH SolForMu = pop[SolForMuID];
                SortedList<short, short> MuLU = new SortedList<short, short>(pop[SolForMuID].Landuses);

                int noOfparelsToMut = Convert.ToInt32(0.2 * Settings.Default.NoOFParcels);
                List<short> parcelsToMut = getRandomParcellsToMutation(noOfparelsToMut);
                foreach (short par in parcelsToMut)
                {
                    Parcel p = parcels.Find(pa => pa.OID == par);
                    List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                    LandUse oldLU = LUClassList.Find(l => l.LUNo == MuLU[par]);
                    while (AcceptableLUs.Count != 0)
                    {
                        int RandLU = rand.Next(AcceptableLUs.Count - 1);
                        //if (PercapitaAreaCheck(SolForMu, p, oldLU, AcceptableLUs[RandLU]))
                        //{
                        MuLU[par] = AcceptableLUs[RandLU].LUNo;
                        break;
                        //}
                        //else
                        //{
                        //   AcceptableLUs.Remove(AcceptableLUs[RandLU]);
                        //}
                    }
                }
                SolutionH Mu_Sol = new SolutionH(MuLU);
                CalculateFitness(Mu_Sol);
                //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                Mutpop.Add(Mu_Sol);
            }
            return Mutpop;
        }
        private List<SolutionH> TopSolutionMutationConstraitBased(List<SolutionH> pop)
        {
            List<SolutionH> Mutpop = new List<SolutionH>();

            SortedList<short, List<SolutionH>> TopSols = Top_Solutions(pop, 0.1);
            int NoOfPar = Settings.Default.NoOFParcels;
            short NoOfSelectedparcels = Convert.ToInt16(Settings.Default.NoOFParcels * 0.1);
            foreach (KeyValuePair<short, List<SolutionH>> ObjTopSolH in TopSols)
            {
                short obj = ObjTopSolH.Key;
                foreach (SolutionH TopSolH in ObjTopSolH.Value)
                {
                    SortedList<short, short> EliteMuLU = new SortedList<short, short>(TopSolH.Landuses);
                    //Selecting 10 percent of parcels randomly--------------------------------
                    List<short> SelectedParcels = new List<short>(NoOfSelectedparcels);
                    for (short i = 0; i < NoOfSelectedparcels; i++)
                    {
                        short R = Convert.ToInt16(rand.Next(1, NoOfPar));
                        if (!SelectedParcels.Contains(R))
                        {
                            SelectedParcels.Add(R);
                        }
                    }
                    //-------------------------------------------------------------------------
                    foreach (short par in SelectedParcels)
                    {
                        short bestLU = EliteMuLU[par];
                        double minFit = double.MaxValue;
                        Parcel p = parcels.Find(pa => pa.OID == par);
                        List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                        LandUse oldLU = LUClassList.Find(l => l.LUNo == EliteMuLU[par]);
                        foreach (LandUse LU in AcceptableLUs)
                        {
                            //if (PercapitaAreaCheck(TopSolH, p, oldLU, LU))
                            //{
                            double[] Fits = CalculateFitness(par, TopSolH, LU.LUNo, obj);

                            if (Fits[obj] < minFit)
                            {
                                minFit = Fits[obj];
                                bestLU = LU.LUNo;
                            }
                            //}
                        }
                        EliteMuLU[par] = bestLU;
                    }
                    SolutionH EliteMu_Sol = new SolutionH(EliteMuLU);
                    CalculateFitness(EliteMu_Sol);
                    //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                    Mutpop.Add(EliteMu_Sol);
                }
            }

            return Mutpop;
        }
        private List<SolutionH> Niching(List<double[]> refPoints, List<SolutionH> NNextPop, List<SolutionH> NLastFront, int K)
        {
            //List<SolutionH> KNextPop = new List<SolutionH>(K);
            //////////////////////////////////////////////////////////////////////////////////////////
            List<SolutionH> ANNextPop = Associate(refPoints, NNextPop);
            NNextPop = null;
            SortedList<int, int> NextPopNicheCount = NicheCount(refPoints, ANNextPop);
            /////////////////////////////////////////////////////////////////////////////////////////
            List<SolutionH> ANLastFront = Associate(refPoints, NLastFront);
            NLastFront = null;
            SortedList<int, int> LastFrontNicheCount = NicheCount(refPoints, ANLastFront);
            ////////////////////////////////////////////////////////////////////////////////////////
            int k = 1;
            while (k <= K)
            {
                int minCount = NextPopNicheCount.Values.Min();
                int minCountID = NextPopNicheCount.IndexOfValue(minCount);
                int minCountKey = NextPopNicheCount.Keys[minCountID];

                if (LastFrontNicheCount[minCountKey] != 0)
                {
                    List<SolutionH> AllMinCountIdMembers = ANLastFront.FindAll(s => s.NSGAIIINearRefPointID == minCountKey);
                    SolutionH nearestMember = AllMinCountIdMembers[0];
                    if (NextPopNicheCount[minCountKey] == 0)
                    {
                        foreach (SolutionH s3 in AllMinCountIdMembers)
                        {
                            if (s3.NSGAIIIDistFromNearRefPoint < nearestMember.NSGAIIIDistFromNearRefPoint)
                            {
                                nearestMember = s3;
                            }
                        }
                    }
                    else
                    {
                        int R = rand.Next(0, AllMinCountIdMembers.Count - 1);
                        nearestMember = AllMinCountIdMembers[R];
                    }
                    ANNextPop.Add(nearestMember);
                    k++;
                    ANLastFront.Remove(nearestMember);
                    NextPopNicheCount[minCountKey] += 1;
                    LastFrontNicheCount[minCountKey] -= 1;
                }
                else
                {
                    // Incorrect must be corrected!!!!!!!!!
                    NextPopNicheCount.Remove(minCountKey);
                    LastFrontNicheCount.Remove(minCountKey);
                }
            }
            return ANNextPop;
        }
        private List<SolutionH> Associate(List<double[]> RefPoints, List<SolutionH> normalpop)
        {
            List<SolutionH> AssociatedNormalPop;
            if (normalpop == null || normalpop.Count == 0)
            {
                AssociatedNormalPop = new List<SolutionH>();
                return AssociatedNormalPop;
            }
            AssociatedNormalPop = new List<SolutionH>(normalpop);
            normalpop = null;
            int RefPCount = RefPoints.Count;
            double minDist = double.MaxValue;
            foreach (SolutionH S in AssociatedNormalPop)
            {
                int minRP = 0;
                for (int i = 0; i < RefPCount; i++)
                {
                    double Dist = PerpendicularDistance(RefPoints[i], S.NormalFitness);
                    if (Dist < minDist)
                    {
                        minRP = i;
                        minDist = Dist;
                    }
                }
                S.NSGAIIINearRefPointID = minRP;
                S.NSGAIIIDistFromNearRefPoint = minDist;
            }
            return AssociatedNormalPop;
        }
        private SortedList<int, int> NicheCount(List<double[]> refPoints, List<SolutionH> ANPop)
        {
            int RefPCount = refPoints.Count;
            SortedList<int, int> NicheCount = new SortedList<int, int>();
            //if (ANPop == null || ANPop.Count == 0)
            //{
            //    return NicheCount;
            //}

            for (int i = 0; i < RefPCount; i++)
            {
                //must be checked
                NicheCount.Add(i,ANPop.FindAll(s => s.NSGAIIINearRefPointID == i).Count);

            }
            return NicheCount;
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        /*
        private void FindExtremePoints(List<SolutionH> Selected_Pop)
        {
            List<SolutionH> ExtrimePoints = new List<SolutionH>();
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                double MinDistToAxis = double.MaxValue;
                SolutionH ExtrimePoint=null;
                foreach (SolutionH sol in Selected_Pop)
                {
                    
                    double distToAxis=0;
                    for (int j = 0; j < Settings.Default.NoOFObj; j++)
                    {
                        if (i == j)
                        {
                            continue;
                        }
                        distToAxis += Math.Pow((sol.Fitness[j] - minFitness[j])/(maxFitness[j]-minFitness[j]), 2);
                    }
                    if (distToAxis < MinDistToAxis)
                    {
                        MinDistToAxis = distToAxis;
                        ExtrimePoint = sol;
                    }
                }


                //ASF_Of_All_List(Selected_Pop, i);
                //double Min_ASF = Selected_Pop.Select(s => s.ASF).ToList<double>().Min();
                //SolutionH extremePoint = Selected_Pop.Find(s=>s.ASF==Min_ASF);
                if (!ExtrimePoints.Contains(ExtrimePoint))
                {
                    ExtrimePoints.Add(ExtrimePoint);
                }
                else
                {
                    MessageBox.Show("Error!: duplicate extreme point is found");
                }
            }
        }
        private void ASF_Of_All_List(List<SolutionH> pop, int obj)
        {
            foreach (SolutionH Sol in pop)
            {
                double Max_Val = -double.MaxValue;
                for (int i = 0; i < Settings.Default.NoOFObj; i++)
                {
                    double f = Sol.Fitness[i] - minFitness[i];
                    double Value;
                    if (i == obj)
                    {
                        Value = f / 1;
                    }
                    else
                    {
                        Value = f / 0.000001;
                    }
                    Max_Val = Math.Max(Max_Val, Value);
                }
                Sol.ASF = Max_Val;
            }
        }

        */

        private double PerpendicularDistance(double[] direction, double[] point)
        {
            double numerator = 0;
            double denominator = 0;
            int NoOFObj = Settings.Default.NoOFObj;
            for (int i = 0; i < NoOFObj; i += 1)
            {
                numerator += direction[i] * point[i];
                denominator += square(direction[i]);
            }
            double k = numerator / denominator;

            double d = 0;
            for (int i = 0; i < NoOFObj; i += 1)
            {
                d += square(k * direction[i] - point[i]);
            }
            return Math.Sqrt(d);
        }
        private double square(double n)
        {
            return n * n;
        }
        
        private List<SolutionH> Normalize(List<SolutionH> pop)
        {
            int NoOFObj = Settings.Default.NoOFObj;

            List<SolutionH> Normalpop;
            if (pop.Count == 0)
            {
                Normalpop = new List<SolutionH>();
                return Normalpop;
            }
            Normalpop = new List<SolutionH>(pop);
            pop = null;
            List<double[]> Obj = Normalpop.Select(s => s.Fitness).ToList();
            double[] MaxFitness = new double[NoOFObj];
            double[] MinFitness = new double[NoOFObj];
            for (int i = 0; i < NoOFObj; i++)
            {
                MaxFitness[i] = Obj.Select(o => o[i]).Max();
                MinFitness[i] = Obj.Select(o => o[i]).Min();
            }

            foreach (SolutionH S in Normalpop)
            {
                double[] NormalFitness = new double[NoOFObj];
                for (int i = 0; i < NoOFObj; i++)
                {
                    NormalFitness[i] = (S.Fitness[i] - MinFitness[i]) / (MaxFitness[i] - MinFitness[i]);

                }
                S.NormalFitness = NormalFitness;
            }
            return Normalpop;

        }

        private void IdentifyElites(List<SolutionH> pop)
        {
            int NoOfObj = Settings.Default.NoOFObj;
            IList<SolutionH> OldElites = pop.FindAll(p => p.isElite == true);
            foreach (SolutionH s in OldElites)
            {
                s.isElite = false;
                s.EliteObjectives.Clear();
            }
            for (short i = 0; i < NoOfObj; i++)
            {
                double minObj = pop.Select(p => p.Fitness[i]).ToList<double>().Min();
                SolutionH Elite = pop.Find(p => Math.Abs(p.Fitness[i] - minObj) < 0.00001);
                Elite.isElite = true;
                Elite.EliteObjectives.Add(i);
            }
        }
        private double CalculateCV(short OID, SolutionH Elite, short nLU)
        {
            double CV = 0;

            double A = parcels.Find(p => p.OID == OID).Area;
            List<double> LUC1A = new List<double>(Elite.LUCode1Area.ToList<double>());
            double[] LUCode1Area = LUC1A.ToArray();
            LUCode1Area[Elite.LUCode1[OID]] -= A;
            LUCode1Area[getLUCode1(nLU)] += A;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            for (int LUCode1 = 0; LUCode1 < NoOfLUCode1; LUCode1++)
            {
                if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0] < 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0]) / (MinMaxLUCode1Areas[LUCode1, 0]));
                }
                else if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1] > 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1]) / (MinMaxLUCode1Areas[LUCode1, 1]));
                }
            }
            return CV;
        }
        private List<List<SolutionH>> RankDominance(List<SolutionH> pop)
        {
            int popSize = pop.Count;


            Int16[,] DominateMatix = new Int16[popSize, popSize];

            int k = 0;
            List<List<SolutionH>> F = new List<List<SolutionH>>();
            F.Add(new List<SolutionH>());
            List<List<int>> Froid = new List<List<int>>();
            Froid.Add(new List<int>());
            for (int i = 0; i < popSize; i++)
            {
                SolutionH a = pop[i];

                if (i == popSize - 1)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                    break;
                }

                for (int j = i + 1; j < popSize; j++)
                {
                    SolutionH b = pop[j];

                    if (Dominate(a, b))
                    {
                        DominateMatix[i, j] = 1;
                    }
                    else if (Dominate(b, a))
                    {
                        DominateMatix[j, i] = 1;
                    }
                }
                if (sumColumn(DominateMatix, i) == 0)
                {
                    pop[i].FrontRank = k;
                    F[k].Add(pop[i]);
                    Froid[k].Add(i);
                }
            }
            int FCount = F[k].Count;
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[Froid[k][i], j] = 0;
                }
            }
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                }
            }

            //int[,] qwe=DominateMatix;
            while (true)
            {
                k = k + 1;
                F.Add(new List<SolutionH>());
                Froid.Add(new List<int>());
                for (int i = 0; i < popSize; i++)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                }

                FCount = F[k].Count;

                if (FCount == 0)
                {
                    break;
                }

                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[Froid[k][i], j] = 0;
                    }
                }
                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                    }
                }
            }
            F.RemoveAt(F.Count - 1);
            return F;
        }

        private bool Dominate(SolutionH sol1, SolutionH sol2)
        {
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] > sol2.Fitness[i])
                {
                    return false;
                }
            }
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] < sol2.Fitness[i])
                {
                    return true;
                }
            }
            return false;
        }

        private int sumColumn(Int16[,] DM, int ColIdx)
        {
            int RowCount = DM.GetLength(0);
            int sum = 0;
            for (int i = 0; i < RowCount; i++)
            {
                sum = sum + DM[i, ColIdx];
            }
            return sum;
        }

        private List<short> getRandomParcellsToMutation(int noOfpar)
        {
            List<short> RandPar = new List<short>(noOfpar);
            Random r = new Random();
            short Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1) + 1);
            RandPar.Add(Rand);
            Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1) + 1);
            while (RandPar.Count != noOfpar)
            {
                Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1) + 1);
                if (!RandPar.Contains(Rand))
                {
                    RandPar.Add(Rand);
                    continue;
                }
            }
            return RandPar;
        }

        private SortedList<short, List<SolutionH>> Top_Solutions(List<SolutionH> pop, double percent)
        {
            int psize = Settings.Default.InitialPopulation;
            int TopsizeperObj = Convert.ToInt32(percent * psize);
            SortedList<short, List<SolutionH>> Top_sols = new SortedList<short, List<SolutionH>>(Settings.Default.NoOFObj);
            for (short obj = 0; obj < Settings.Default.NoOFObj; obj++)
            {
                List<SolutionH> TopSolsPerObj = new List<SolutionH>(TopsizeperObj * Settings.Default.NoOFObj);
                List<SolutionH> sortedpop = pop.OrderBy(s => s.Fitness[obj]).ToList<SolutionH>();
                for (int i = 0; i < TopsizeperObj; i++)
                {
                    TopSolsPerObj.Add(sortedpop[i]);
                }
                Top_sols.Add(obj, TopSolsPerObj);
            }
            return Top_sols;
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private double[,] GetDataFromTXT(string txtPath)
        {
            String input = File.ReadAllText(txtPath);
            int i = 0, j = 0;
            var Rows = input.Split('\n');
            var Cols = Rows[1].Trim().Split('	');
            double[,] result = new double[Rows.Length, Cols.Length];
            foreach (string row in Rows)
            {
                j = 0;
                string[] cols = row.Trim().Split('	');
                foreach (string val in cols)
                {
                    result[i, j] = double.Parse(val.Trim());
                    j++;
                }
                i++;
            }
            return result;
        }
        private SolutionH InitializePopsConstriantsBasedPriatizing()
        {
        FirstLine:
            SortedList<short, short> newLU = new SortedList<short, short>(Settings.Default.NoOFParcels);
            double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
            //List<Parcel> newParcels = parcels.OrderByDescending(a => a.).ThenByDescending(a=>a.AccessType).ToList<Parcel>();
            List<Parcel> newParcels = parcels.OrderBy(a => Guid.NewGuid()).ToList<Parcel>();
            List<Parcel> UnassignedParcels = new List<Parcel>();
            foreach (Parcel p in newParcels)
            {
                if (p.Area <= 0)
                {
                    p.Area = -p.Area;
                }
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                short r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                int LUCode1 = AcceptableLUs[r].LUCode1;
                bool isParcelLUAsigned = false;
                while (!isParcelLUAsigned && AcceptableLUs.Count != 0)
                {
                    //if (MinMaxLUCode1Areas[LUCode1, 1] - LUCode1Area[LUCode1] > p.Area)
                    //{
                        if (LUCode1 == 1)
                        {
                            if (p.Area <= 300)
                            {
                                LUCode1Area[LUCode1] += p.Area * 1.6;
                            }
                            else if (p.Area > 300 & p.Area <= 450)
                            {
                                LUCode1Area[LUCode1] += p.Area * 1.8;
                            }
                            else if (p.Area > 450 & p.Area <= 550)
                            {
                                LUCode1Area[LUCode1] += p.Area * 2;
                            }
                            else
                            {
                                LUCode1Area[LUCode1] += p.Area * 2.2;
                            }
                            newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                            isParcelLUAsigned = true;

                        }
                        else
                        {
                            LUCode1Area[LUCode1] += p.Area;
                            newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                            isParcelLUAsigned = true;
                        }
                    //}
                    //else
                    //{
                     //   AcceptableLUs.Remove(AcceptableLUs[r]);
                      //  if (AcceptableLUs.Count != 0)
                     //   {
                      //      r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                     //       LUCode1 = AcceptableLUs[r].LUCode1;
                      //  }
                   // }
                }
                if (!isParcelLUAsigned)
                {
                    UnassignedParcels.Add(p);
                }
            }

            foreach (Parcel p in UnassignedParcels)
            {
                //Assigning reminging parcels
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                List<LandUse> SelectableLUs = new List<LandUse>();
                foreach (LandUse LU in AcceptableLUs)
                {
                    if (MinMaxLUCode1Areas[LU.LUCode1, 1] - LUCode1Area[LU.LUCode1] > p.Area)
                    {
                        SelectableLUs.Add(LU);
                    }
                }
                if (SelectableLUs.Count != 0)
                {
                    int r = rand.Next(SelectableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), SelectableLUs[r].LUNo);
                }

            }
            if (newLU.Count < Settings.Default.NoOFParcels)
            {
                goto FirstLine;
            }
            SolutionH SolH = new SolutionH(newLU);
            CalculateFitness(SolH);
            return SolH;
        }
        private double CalculateConstraintViolationForLUCode1AreaV2(SolutionH solH)
        {

            double[] LUCode1Area = CalculateLUCode1Areas(solH);


            SortedList<short, short> LUCodes1 = solH.LUCode1;
            double CV = 0;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            for (int LUCode1 = 0; LUCode1 < NoOfLUCode1; LUCode1++)
            {
                if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0] < 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0]) / (MinMaxLUCode1Areas[LUCode1, 0]));
                }
                else if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1] > 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1]) / (MinMaxLUCode1Areas[LUCode1, 1]));
                }
            }

            solH.LUCode1Area = LUCode1Area;
            return (CV);
        }
        private double[] CalculateLUCode1Areas(SolutionH solH)
        {

            SortedList<short, short> LUCode1 = solH.LUCode1;
            double CV = 0;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            double[] LUCode1Area = new double[NoOfLUCode1];
            for (int LUC1 = 0; LUC1 < NoOfLUCode1; LUC1++)
            {

                var LUparcels = LUCode1.Where(pLU => pLU.Value == LUC1);
                if (LUC1 == 1)
                {
                    foreach (KeyValuePair<short, short> par in LUparcels)
                    {
                        Parcel par2 = parcels.Find(p => p.OID == par.Key);
                        if (par2.Area < 300)
                        {
                            LUCode1Area[LUC1] += par2.Area * 1.6;
                        }
                        else if (par2.Area > 300 & par2.Area <= 450)
                        {
                            LUCode1Area[LUC1] += par2.Area * 1.8;
                        }
                        else if (par2.Area > 450 & par2.Area <= 550)
                        {
                            LUCode1Area[LUC1] += par2.Area * 2;
                        }
                        else if (par2.Area > 550)
                        {
                            LUCode1Area[LUC1] += par2.Area * 2.2;
                        }
                    }
                }
                else
                {
                    foreach (KeyValuePair<short, short> par in LUparcels)
                    {
                        Parcel par2 = parcels.Find(p => p.OID == par.Key);
                        LUCode1Area[LUC1] += par2.Area;
                    }
                }
            }
            return LUCode1Area;
        }
        private void setLUList()
        {
            List<LandUse> LUs = new List<LandUse>();

            List<short> AS = new List<short>(new short[] { 1, 2, 3, 4, 5, 6 });
            LandUse LU = new LandUse(37, 0, 0, double.MaxValue, AS);
            //LUs.Add(LU);
            // maskooni//////////////////////////////////////////////
            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(0, 1, 40, 650, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(1, 1, 40, 650, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(2, 1, 40, 650, AS);
            LUs.Add(LU);
            //Tejari/////////////////////////////////////////////////
            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(3, 2, 0, 50, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(4, 2, 0, 1000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5, 6 });
            LU = new LandUse(5, 2, 0, 20000, AS);
            LUs.Add(LU);
            //Amouzeshi//////////////////////////////////////////////
            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(6, 3, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(7, 3, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(8, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3, 4, 5 });
            LU = new LandUse(9, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3, 4, 5 });
            LU = new LandUse(10, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(11, 3, 1000, 50000, AS);
            LUs.Add(LU);
            //Mazhabi///////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(12, 4, 100, 500, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(13, 4, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(14, 4, 200, 5000, AS);
            LUs.Add(LU);
            //Behdashti////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(15, 5, 100, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(16, 5, 100, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(17, 5, 500, 50000, AS);
            LUs.Add(LU);
            //Edari////////////////////////////////////////////////////
            AS = new List<short>(new short[] { });
            LU = new LandUse(18, 6, 0, 5000, AS);
            //LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(19, 6, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(20, 6, 0, 5000, AS);
            LUs.Add(LU);
            //Farhangi//////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(21, 7, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(22, 7, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(23, 7, 0, 5000, AS);
            LUs.Add(LU);
            //Varzeshi/////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(24, 8, 500, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(25, 8, 500, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(26, 8, 500, 50000, AS);
            LUs.Add(LU);
            //Tasisat Shahri////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(27, 9, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(28, 9, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5, 6 });
            LU = new LandUse(29, 9, 0, 5000, AS);
            LUs.Add(LU);
            //Sanati//////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(30, 10, 500, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(31, 10, 500, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(32, 10, 1000, 5000, AS);
            LUs.Add(LU);
            //Park//////////////////////////////////////////////////////
            AS = new List<short>(new short[] { 1, 2 });
            LU = new LandUse(34, 11, 400, 10000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(35, 11, 400, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(36, 11, 500, 50000, AS);
            LUs.Add(LU);

            LUClassList = LUs;
        }
        private List<double[]> GetRefPoints()
        {
            List<double[]> refs=null;
            int parts = Settings.Default.NSGAIIIRefDivisionParts;
            int NoOFObj = Settings.Default.NoOFObj;
            if (NoOFObj == 3)
            {
                //refs = ReferencePoints3(parts);
            }
            else if (NoOFObj == 4)
            {
                //refs = ReferencePoints4(parts);
            }
            else if (NoOFObj == 5)
            {
                refs = ReferencePoints5(parts);
            }
            else if (NoOFObj == 6)
            {
                //refs = ReferencePoints6(parts);
            }
            else
            {
                MessageBox.Show("Number Of objectives not supported in NSGAIII refpoint producing.");
                return null;
            }
            return refs;

        }
        private double[][] ReferencePoints3(int parts)
        {
            int NoOFObj = Settings.Default.NoOFObj;
            int NoOfRefPoints = Convert.ToInt32(Factorial(NoOFObj + parts - 1) / (Factorial(parts) * Factorial(NoOFObj - 1)));
            double[][] RefPoints = new double[NoOfRefPoints][];
            double delta = 1 / (double)parts;

            int itr = 0;
            for (double B1 = 0; B1 <= 1; B1 = B1 + delta)
            {
                for (double B2 = 0; B2 <= 1 - B1; B2 = B2 + delta)
                {
                    RefPoints[itr] = new double[NoOFObj];
                    RefPoints[itr][0] = B1;
                    RefPoints[itr][1] = B2;
                    RefPoints[itr][2] = 1 - (B1 + B2);
                    itr++;
                }
            }
            return RefPoints;
        }
        private double[][] ReferencePoints4(int parts)
        {
            int NoOFObj = Settings.Default.NoOFObj;
            int NoOfRefPoints = Convert.ToInt32( Factorial(NoOFObj + parts - 1) / (Factorial(parts) * Factorial(NoOFObj - 1)));
            double[][] RefPoints = new double[NoOfRefPoints][];
            double delta = 1 / (double)parts;

            int itr = 0;
            for (double B1 = 0; B1 <= 1; B1 = B1 + delta)
            {
                for (double B2 = 0; B2 <= 1 - B1; B2 = B2 + delta)
                {
                    for (double B3 = 0; B3 <= 1 - (B1 + B2); B3 = B3 + delta)
                    {
                        RefPoints[itr] = new double[NoOFObj];
                        RefPoints[itr][0] = B1;
                        RefPoints[itr][1] = B2;
                        RefPoints[itr][2] = B3;
                        RefPoints[itr][3] = 1 - (B1 + B2 + B3);
                        itr++;
                    }
                }
            }
            return RefPoints;
        }
        private List<double[]> ReferencePoints5(int parts)
        {
            List<double[]> RefPoints = new List<double[]>();
            double delta = 1 / (double)parts;
            for (double B1 = 0; B1 <= 1; B1 = B1 + delta)
            {
                for (double B2 = 0; B2 <= 1 - B1; B2 = B2 + delta)
                {
                    for (double B3 = 0; B3 <= 1 - (B1 + B2); B3 = B3 + delta)
                    {
                        for (double B4 = 0; B4 <= 1 - (B1 + B2 + B3); B4 = B4 + delta)
                        {
                            double[] RP = new double[Settings.Default.NoOFObj];
                            RP[0] = B1;
                            RP[1] = B2;
                            RP[2] = B3;
                            RP[3] = B4;
                            RP[4] = 1 - (B1 + B2 + B3 + B4);
                            RefPoints.Add(RP);
                        }
                    }
                }
            }
            return RefPoints;
        }
        private double[][] ReferencePoints6(int parts)
        {
            int NoOFObj = Settings.Default.NoOFObj;
            int NoOfRefPoints = Convert.ToInt32(Factorial(NoOFObj + parts - 1) / (Factorial(parts) * Factorial(NoOFObj - 1)));
            double[][] RefPoints = new double[NoOfRefPoints][];
            double delta = 1 / (double)parts;

            int itr = 0;
            for (double B1 = 0; B1 <= 1; B1 = B1 + delta)
            {
                for (double B2 = 0; B2 <= 1 - B1; B2 = B2 + delta)
                {
                    for (double B3 = 0; B3 <= 1 - (B1 + B2); B3 = B3 + delta)
                    {
                        for (double B4 = 0; B4 <= 1 - (B1 + B2 + B3); B4 = B4 + delta)
                        {
                            for (double B5 = 0; B5 <= 1 - (B1 + B2 + B3 + B4); B5 = B5 + delta)
                            {
                                RefPoints[itr] = new double[NoOFObj];
                                RefPoints[itr][0] = B1;
                                RefPoints[itr][1] = B2;
                                RefPoints[itr][2] = B3;
                                RefPoints[itr][3] = B4;
                                RefPoints[itr][4] = B5;
                                RefPoints[itr][5] = 1 - (B1 + B2 + B3 + B4 + B5);
                                itr++;
                            }
                        }
                    }
                }
            }
            return RefPoints;
        }

        private long Factorial(long number)
        {
            if (number <= 1)
                return 1;
            else
                return number * Factorial(number - 1);
        }

        private int getLUCode1(short LUCode)
        {
            int LUCode1 = 100;
            if (LUCode == 0 || LUCode == 1 || LUCode == 2)
            {
                LUCode1 = 1;
            }
            else if (LUCode == 3 || LUCode == 4 || LUCode == 5)
            {
                LUCode1 = 2;
            }
            else if (LUCode == 6 || LUCode == 7 || LUCode == 8 || LUCode == 9 || LUCode == 10 || LUCode == 11)
            {
                LUCode1 = 3;
            }
            else if (LUCode == 12 || LUCode == 13 || LUCode == 14)
            {
                LUCode1 = 4;
            }
            else if (LUCode == 15 || LUCode == 16 || LUCode == 17)
            {
                LUCode1 = 5;
            }
            else if (LUCode == 18 || LUCode == 19 || LUCode == 20)
            {
                LUCode1 = 6;
            }
            else if (LUCode == 21 || LUCode == 22 || LUCode == 23)
            {
                LUCode1 = 7;
            }
            else if (LUCode == 24 || LUCode == 25 || LUCode == 26)
            {
                LUCode1 = 8;
            }
            else if (LUCode == 27 || LUCode == 28 || LUCode == 29)
            {
                LUCode1 = 9;
            }
            else if (LUCode == 30 || LUCode == 31 || LUCode == 32 || LUCode == 33)
            {
                LUCode1 = 10;
            }
            else if (LUCode == 34 || LUCode == 35 || LUCode == 36)
            {
                LUCode1 = 11;
            }
            else if (LUCode == 37)
            {
                LUCode1 = 0;
            }
            return LUCode1;
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
