﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;
using System.IO;
using LandUsePlanning.Classes;

namespace LandUsePlanning.NSGAOptimization
{
    [Serializable]
    public class SolutionH
    {
        public double Dissatisfied=0;
        public double NSGAIICrowdingDist;
        public double[] LUArea = new double[Settings.Default.NoOfLUs];
        public double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
        public bool isElite=false;
        public List<short> EliteObjectives=new List<short>();
        public int FrontRank;
        public double[] Fitness = new double[Settings.Default.NoOFObj];
        public double[] NormalFitness;
        public double FitnessGA;
        //public int[] FitnessRank=new int[5];
        public short[] HNSGACubeIndex = new short[Settings.Default.NoOFObj];
        public int HNSGAneighborCount = 0;
        public double ConstraintViolation;
        public int NSGAIIINearRefPointID;
        public double NSGAIIIDistFromNearRefPoint;
        public SortedList<short, short> Landuses = new SortedList<short, short>(Settings.Default.NoOFParcels);
        public SortedList<short, short> LUCode1 = new SortedList<short, short>(Settings.Default.NoOfLUCode1);
        public double ASF;
        public SortedList<short, SortedList<short, bool>> Game_Acceptances = new SortedList<short, SortedList<short, bool>>(Settings.Default.NoOFParcels);
        public int TotalLUAcceptance = 0;
        public int NumberOfNashInLUs = 0;
        public SortedList<short, int> ParcelsTotalAccepts;
        public List<short> DissatisfiedOIDs = new List<short>();
        public SolutionH(SortedList<short, short> LUs)
        {
            Landuses = LUs;
            foreach (KeyValuePair<short, short> kvp in Landuses)
            {
                LUCode1.Add(kvp.Key,getLUCode1(kvp.Value));
            }
        }

        
        private short getLUCode1(short LUCode)
        {
            short LUCode1 = 100;
            if (LUCode == 0 || LUCode == 1 || LUCode == 2)
            {
                LUCode1 = 1;
            }
            else if (LUCode == 3 || LUCode == 4 || LUCode == 5)
            {
                LUCode1 = 2;
            }
            else if (LUCode == 6 || LUCode == 7 || LUCode == 8 || LUCode == 9 || LUCode == 10 || LUCode == 11)
            {
                LUCode1 = 3;
            }
            else if (LUCode == 12 || LUCode == 13 || LUCode == 14)
            {
                LUCode1 = 4;
            }
            else if (LUCode == 15 || LUCode == 16 || LUCode == 17)
            {
                LUCode1 = 5;
            }
            else if (LUCode == 18 || LUCode == 19 || LUCode == 20)
            {
                LUCode1 = 6;
            }
            else if (LUCode == 21 || LUCode == 22 || LUCode == 23)
            {
                LUCode1 = 7;
            }
            else if (LUCode == 24 || LUCode == 25 || LUCode == 26)
            {
                LUCode1 = 8;
            }
            else if (LUCode == 27 || LUCode == 28 || LUCode == 29)
            {
                LUCode1 = 9;
            }
            else if (LUCode == 30 || LUCode == 31 || LUCode == 32 || LUCode == 33)
            {
                LUCode1 = 10;
            }
            else if (LUCode == 34 || LUCode == 35 || LUCode == 36)
            {
                LUCode1 = 11;
            }
            else if (LUCode == 37)
            {
                LUCode1 = 0;
            }
            return LUCode1;
        }


        /*
        public IFeatureClass GetFeatureClass()
        {
            System.IO.FileInfo fi = new FileInfo(FeatureClassPath);
            var wsf = Activator.CreateInstance(Type.GetTypeFromProgID("esriDataSourcesFile.ShapefileWorkspaceFactory")) as IWorkspaceFactory;
            var fws = wsf.OpenFromFile(fi.DirectoryName, 0) as IFeatureWorkspace;
            IFeatureClass fc = fws.OpenFeatureClass(FeatureClassPath);
            return fc;
        }
         */
    }
}
