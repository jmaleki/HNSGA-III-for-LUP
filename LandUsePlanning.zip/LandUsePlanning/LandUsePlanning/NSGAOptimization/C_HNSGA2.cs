﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Geodatabase;
using System.Windows.Forms;
using System.IO;
using ESRI.ArcGIS.Geometry;
using System.Diagnostics;
using LandUsePlanning.Classes;
using MathLib;
using System.Runtime.InteropServices;

namespace LandUsePlanning.NSGAOptimization
{
    class C_HNSGA2
    {
        private MathLib.Matrix EffectRadiuses;
        private MathLib.Matrix Compatibilities;
        private MathLib.Matrix Dependancies;
        private IFeatureClass fc_Parcells;
        private IFeatureClass fc_PopBlocks;
        double[,] PerCap;
        double[,] MinMaxLUCode1Areas;
        List<Parcel> parcels = null;
        //public List<List<Solution>> PopulationOfIterations;
        double[] LURequiredAreas;

        public C_HNSGA2(IFeatureClass fc_Par, IFeatureClass fc_Pop)
        {
            var Dep = GetDataFromTXT(Settings.Default.DataForRun + "Dependancies_Full.txt");
            var CMP = GetDataFromTXT(Settings.Default.DataForRun + "Compabilities_Full.txt");
            var ER = GetDataFromTXT(Settings.Default.DataForRun + "Effect Radius.txt");

            //checking matrix dimensions:
            if (Dep.GetLength(0) != Dep.GetLength(1))
            {
                MessageBox.Show("Error1:Dependancies matrix dimension");
            }
            if (CMP.GetLength(0) != CMP.GetLength(1))
            {
                MessageBox.Show("Error2:Compabilities matrix dimension");
            }
            if (Dep.GetLength(0) != CMP.GetLength(0))
            {
                MessageBox.Show("Error3:Dependancies & Compabilities matrix dimension");
            }
            if (ER.GetLength(0) != CMP.GetLength(0))
            {
                MessageBox.Show("Error4:Compabilities & Effect Radius matrix dimension");
            }
            EffectRadiuses = new Matrix(ER);
            Compatibilities = new Matrix(CMP);
            Dependancies = new Matrix(Dep);

            MinMaxLUCode1Areas = GetDataFromTXT(Settings.Default.DataForRun + "PerCapitaAreas.txt");
            PerCap = GetDataFromTXT(Settings.Default.DataForRun + "PerCapita.txt");
            fc_Parcells = fc_Par;
            fc_PopBlocks = fc_Pop;
            //PopulationOfIterations = new List<List<Solution>>(Settings.Default.Iteration);
            LURequiredAreas = CalculateRequiredAreas();

            parcels = Classes.BinarySerialization.ReadFromBinaryFile<List<Parcel>>(Settings.Default.parcelsBinAdress);
            Settings.Default.NoOFParcels = parcels.Count;

            Settings.Default.NoOFParcels = parcels.Count;
            Settings.Default.Save();
            SetStreetTypeLanduses();
            setLUList();
        }

        public void RunC_HNSG2()
        {
            //InitializePopsConstriantsBasedPriatizing();
            //InitializePopsConstriantsBased(1);
            //CalArea();
            DateTime dt = DateTime.Now;
            string DataFolderName = Settings.Default.DataForRun + "Results\\" + Settings.Default.resultFolder + "\\" +
                "HNSGA," + Settings.Default.Iteration.ToString() +
                                "," + Settings.Default.InitialPopulation.ToString() +
                                "," + Settings.Default.CrossoverPercent.ToString() +
                                "," + Settings.Default.MutationRate.ToString() +
                                "," + Settings.Default.CrossTourSize.ToString() +
                                "," + Settings.Default.HyberCubeCellsCount.ToString() +
                                "," + dt.Year.ToString() +
                                "," + dt.Month.ToString() +
                                "," + dt.Day.ToString() +
                                "," + dt.Hour.ToString() +
                                "," + dt.Minute.ToString();
            if (!System.IO.Directory.Exists(DataFolderName))
            {
                System.IO.Directory.CreateDirectory(DataFolderName);
            }
            else
            {
                DataFolderName += "(2)";
                System.IO.Directory.CreateDirectory(DataFolderName);
            }

            //Parameters.FindandSaveNeigbers2();
            //Parameters.AddminDistOfNeighsToParcels(parss as List<Parcel>);
            //Parameters.generateParcelsForInitialPops();
            //---------------------------------------------------------------------
            int PopSize = Settings.Default.InitialPopulation;
            //List<Solution> PRd = InitializePopulationRandomly(PopSize);
            //List<Solution> PRk = InitializePopulationBasedOnRanks(Convert.ToInt32(PopSize*0.5));
            //List<Solution> PC = InitializePopulationFromCurrentLU(PopSize);
            List<SolutionH> PRC = InitilalizePops(PopSize);
            List<SolutionH> Population = new List<SolutionH>(PopSize);
            //Population.AddRange(PRd);
            //Population.AddRange(PRk);
            //Population.AddRange(PC);
            Population.AddRange(PRC);
            //---------------------------------------------------------------------
            Population = NeigberMemberCountInHCube(Population);
            //---------------------------------------------------------------------
            List<List<SolutionH>> Fronts = RankDominance(Population);
            //----------------------------------------------------------------------
            int Itr = Settings.Default.Iteration;
            //---------------------------------------------------------------------
            Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + 0 + "_Population.bin", Population, false);
            for (int i = 0; i < Itr; i++)
            {

                List<SolutionH> Crossover_Population = Crossover3(Population);
                //--------------------------------------------------------
                List<SolutionH> Mutation_Population = MutationConstraintBased(Population, i);
                //--------------------------------------------------------
                Population.AddRange(Crossover_Population);
                Population.AddRange(Mutation_Population);
                //--------------------------------------------------------
                //IdentifyElites(Population);
                //List<Solution> EliteMu_Population = EliteMutationConstraitBased(Population);
                //Population.AddRange(EliteMu_Population);
                //------------------------------------------------------------

                //--------------------------------------------------------
                List<SolutionH> TopMu_Population = TopSolutionMutationConstraitBased(Population);
                Population.AddRange(TopMu_Population);
                IdentifyElites(Population);
                Population = NeigberMemberCountInHCube(Population);
                Fronts = RankDominance(Population);

                //List<Solution> sortedPop= Population.OrderBy(s => s.FrontRank).ThenByDescending(s => s.HNSGAneighborCount).ToList<Solution>();
                //-----------------------------------------------------------
                List<SolutionH> Selected_Pop = new List<SolutionH>(Population.Count);
                List<SolutionH> Front_Last;
                List<SolutionH> PopNext = new List<SolutionH>(PopSize);
                int LastFrontIdx = 0;
                for (int idx = 0; idx < Fronts.Count; idx++)
                {
                    Selected_Pop.AddRange(Fronts[idx]);
                    if (Selected_Pop.Count >= PopSize)
                    {
                        LastFrontIdx = idx;
                        break;
                    }
                }
                if (Selected_Pop.Count == PopSize)
                {
                    Population = new List<SolutionH>(Selected_Pop);
                    break;
                }
                else
                {
                    for (int idx2 = 0; idx2 < LastFrontIdx; idx2++)
                    {
                        PopNext.AddRange(Fronts[idx2]);
                    }
                    //Last front to be included:
                    Front_Last = new List<SolutionH>(Fronts[LastFrontIdx]);
                    //Points to be chosen from Flast:
                    int K = PopSize - PopNext.Count;

                    List<SolutionH> SelectedFromLastFront = HypercubeSelection(Front_Last, K);
                    PopNext.AddRange(SelectedFromLastFront);
                    Population = new List<SolutionH>(PopNext);
                }


                //--------------------------------------------------------
                Population = NeigberMemberCountInHCube(Population);
                Fronts = RankDominance(Population);



                //PopulationOfIterations.Add(new List<Solution>(Population));

                //double igd = ComputeIGD(Fronts[0]);
                //IGD.Add(igd);

                //double gamma = ComputeGama(Fronts[0]);
                //Gamma.Add(gamma);

                //ElapsedTimePerItr.Add(sw.Elapsed.TotalSeconds);
                Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + (i + 1) + "_Population.bin", Population, false);
            }
            //Classes.BinarySerialization.WriteToBinaryFile<List<List<Solution>>>(DataFolderName + "\\Front1OfIterations.bin", PopulationOfIterations, false);
        }
        public void RunC_HNSG2_withoutEliteMutation()
        {
            //InitializePopsConstriantsBasedPriatizing();
            //InitializePopsConstriantsBased(1);
            //CalArea();
            DateTime dt = DateTime.Now;
            string DataFolderName = Settings.Default.DataForRun + "Results\\" + Settings.Default.resultFolder + "\\" +
                "HNSGAWithoutElite," + Settings.Default.Iteration.ToString() +
                                "," + Settings.Default.InitialPopulation.ToString() +
                                "," + Settings.Default.CrossoverPercent.ToString() +
                                "," + Settings.Default.MutationRate.ToString() +
                                "," + Settings.Default.CrossTourSize.ToString() +
                                "," + Settings.Default.HyberCubeCellsCount.ToString() +
                                "," + dt.Year.ToString() +
                                "," + dt.Month.ToString() +
                                "," + dt.Day.ToString() +
                                "," + dt.Hour.ToString() +
                                "," + dt.Minute.ToString();
            if (!System.IO.Directory.Exists(DataFolderName))
            {
                System.IO.Directory.CreateDirectory(DataFolderName);
            }
            else
            {
                DataFolderName += "(2)";
                System.IO.Directory.CreateDirectory(DataFolderName);
            }

            //Parameters.FindandSaveNeigbers2();
            //Parameters.AddminDistOfNeighsToParcels(parss as List<Parcel>);
            //Parameters.generateParcelsForInitialPops();
            //---------------------------------------------------------------------
            int PopSize = Settings.Default.InitialPopulation;
            //List<Solution> PRd = InitializePopulationRandomly(PopSize);
            //List<Solution> PRk = InitializePopulationBasedOnRanks(Convert.ToInt32(PopSize*0.5));
            //List<Solution> PC = InitializePopulationFromCurrentLU(PopSize);
            List<SolutionH> PRC = InitilalizePops(PopSize);
            List<SolutionH> Population = new List<SolutionH>(PopSize);
            //Population.AddRange(PRd);
            //Population.AddRange(PRk);
            //Population.AddRange(PC);
            Population.AddRange(PRC);
            //---------------------------------------------------------------------
            Population = NeigberMemberCountInHCube(Population);
            //---------------------------------------------------------------------
            List<List<SolutionH>> Fronts = RankDominance(Population);
            //----------------------------------------------------------------------
            int Itr = Settings.Default.Iteration;
            //---------------------------------------------------------------------
            Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + 0 + "_Population.bin", Population, false);
            for (int i = 0; i < Itr; i++)
            {

                List<SolutionH> Crossover_Population = Crossover3(Population);
                //--------------------------------------------------------
                List<SolutionH> Mutation_Population = MutationConstraintBased(Population, i);
                //--------------------------------------------------------
                Population.AddRange(Crossover_Population);
                Population.AddRange(Mutation_Population);
                //--------------------------------------------------------
                //IdentifyElites(Population);
                //List<Solution> EliteMu_Population = EliteMutationConstraitBased(Population);
                //Population.AddRange(EliteMu_Population);
                //------------------------------------------------------------

                //--------------------------------------------------------
                //List<SolutionH> TopMu_Population = TopSolutionMutationConstraitBased(Population);
                //Population.AddRange(TopMu_Population);
                //IdentifyElites(Population);
                Population = NeigberMemberCountInHCube(Population);
                Fronts = RankDominance(Population);

                //List<Solution> sortedPop= Population.OrderBy(s => s.FrontRank).ThenByDescending(s => s.HNSGAneighborCount).ToList<Solution>();
                //-----------------------------------------------------------
                List<SolutionH> Selected_Pop = new List<SolutionH>(Population.Count);
                List<SolutionH> Front_Last;
                List<SolutionH> PopNext = new List<SolutionH>(PopSize);
                int LastFrontIdx = 0;
                for (int idx = 0; idx < Fronts.Count; idx++)
                {
                    Selected_Pop.AddRange(Fronts[idx]);
                    if (Selected_Pop.Count >= PopSize)
                    {
                        LastFrontIdx = idx;
                        break;
                    }
                }
                if (Selected_Pop.Count == PopSize)
                {
                    Population = new List<SolutionH>(Selected_Pop);
                    break;
                }
                else
                {
                    for (int idx2 = 0; idx2 < LastFrontIdx; idx2++)
                    {
                        PopNext.AddRange(Fronts[idx2]);
                    }
                    //Last front to be included:
                    Front_Last = new List<SolutionH>(Fronts[LastFrontIdx]);
                    //Points to be chosen from Flast:
                    int K = PopSize - PopNext.Count;

                    List<SolutionH> SelectedFromLastFront = HypercubeSelection(Front_Last, K);
                    PopNext.AddRange(SelectedFromLastFront);
                    Population = new List<SolutionH>(PopNext);
                }


                //--------------------------------------------------------
                Population = NeigberMemberCountInHCube(Population);
                Fronts = RankDominance(Population);



                //PopulationOfIterations.Add(new List<Solution>(Population));

                //double igd = ComputeIGD(Fronts[0]);
                //IGD.Add(igd);

                //double gamma = ComputeGama(Fronts[0]);
                //Gamma.Add(gamma);

                //ElapsedTimePerItr.Add(sw.Elapsed.TotalSeconds);
                Classes.BinarySerialization.WriteToBinaryFile<List<SolutionH>>(DataFolderName + "\\Iteration_" + (i + 1) + "_Population.bin", Population, false);
            }
            //Classes.BinarySerialization.WriteToBinaryFile<List<List<Solution>>>(DataFolderName + "\\Front1OfIterations.bin", PopulationOfIterations, false);
        }
        public void CalculateFitness(SolutionH SolH)
        {
            double[] Compability_Result = new double[Settings.Default.NoOFParcels];
            double[] Dependancy_Result = new double[Settings.Default.NoOFParcels];
            double[] Compactness_Result = new double[Settings.Default.NoOFParcels];
            double[] Suitability_Result = new double[Settings.Default.NoOFParcels];
            double[] NumOfNeigbors_Result = new double[Settings.Default.NoOFParcels];
            double CMPLU1LU2;
            double DepLU1LU2;
            SortedList<short, short> LUs = SolH.Landuses;
            foreach (Parcel parcel in parcels)
            {
                int parcel_LUCode = LUs[Convert.ToInt16(parcel.OID)];
                int effectRadius = Convert.ToInt32(EffectRadiuses.val[parcel_LUCode, 0]);
                double FeatureCompability = 0;
                double FeatureDependancy = 0;
                double FeatureCompactness = 0;
                int NumOfNeighbors = 0;
                IList<short> neighs = parcel.NeigberHood[parcel_LUCode];
                foreach (short neighOID in neighs)
                {
                    double min_distOfPN = parcel.minDistOfneighber[neighOID];

                    double Alfa = Math.Abs(effectRadius - min_distOfPN) / effectRadius;

                    int neighfeature_LUCode = LUs[neighOID];
                    CMPLU1LU2 = Compatibilities.val[parcel_LUCode, neighfeature_LUCode];
                    DepLU1LU2 = Dependancies.val[parcel_LUCode, neighfeature_LUCode];
                    FeatureCompability = FeatureCompability + Alfa * CMPLU1LU2;
                    FeatureDependancy = FeatureDependancy + Alfa * DepLU1LU2;

                    if (parcel_LUCode == neighfeature_LUCode)
                    {
                        FeatureCompactness++;
                    }
                    NumOfNeighbors++;
                }
                Compability_Result[parcel.OID] = FeatureCompability / NumOfNeighbors;
                Dependancy_Result[parcel.OID] = FeatureDependancy / NumOfNeighbors;
                Compactness_Result[parcel.OID] = FeatureCompactness / NumOfNeighbors;
                Suitability_Result[parcel.OID] = parcel.suitability[parcel_LUCode];
                NumOfNeigbors_Result[parcel.OID] = NumOfNeighbors;

            }
            double[] Objectives = new double[Settings.Default.NoOFObj];
            Objectives[0] = -(Compability_Result.Sum() / Compability_Result.Length + Compability_Result.Min());
            Objectives[1] = -(Dependancy_Result.Sum() / Dependancy_Result.Length + Dependancy_Result.Min());
            Objectives[2] = -(Suitability_Result.Sum() / Suitability_Result.Length + Suitability_Result.Min());
            Objectives[3] = -(Compactness_Result.Sum() / Compactness_Result.Length);
            Objectives[4] = CalculateConstraintViolationForLUCode1AreaV2(SolH);
            SolH.Fitness = Objectives;
        }

        private void IdentifyElites(List<SolutionH> pop)
        {
            int NoOfObj = Settings.Default.NoOFObj;
            IList<SolutionH> OldElites = pop.FindAll(p => p.isElite == true);
            foreach (SolutionH s in OldElites)
            {
                s.isElite = false;
                s.EliteObjectives.Clear();
            }
            for (short i = 0; i < NoOfObj; i++)
            {
                double minObj = pop.Select(p => p.Fitness[i]).ToList<double>().Min();
                SolutionH Elite = pop.Find(p => Math.Abs(p.Fitness[i] - minObj) < 0.00001);
                Elite.isElite = true;
                Elite.EliteObjectives.Add(i);
            }
        }

        private double CalculateCV(short OID, SolutionH Elite, short nLU)
        {
            double CV = 0;

            double A = parcels.Find(p => p.OID == OID).Area;
            List<double> LUC1A = new List<double>(Elite.LUCode1Area.ToList<double>());
            double[] LUCode1Area = LUC1A.ToArray();
            LUCode1Area[Elite.LUCode1[OID]] -= A;
            LUCode1Area[getLUCode1(nLU)] += A;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            for (int LUCode1 = 0; LUCode1 < NoOfLUCode1; LUCode1++)
            {
                if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0] < 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0]) / (MinMaxLUCode1Areas[LUCode1, 0]));
                }
                else if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1] > 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1]) / (MinMaxLUCode1Areas[LUCode1, 1]));
                }
            }
            return CV;
        }


        private double CalculateConstraintViolation(SolutionH solH)
        {
            SortedList<short, short> Landuses = solH.Landuses;
            double CV = 0;
            int NoOfLUs = Settings.Default.NoOfLUs;
            double[] LUArea = new double[NoOfLUs];
            for (int LU = 0; LU < NoOfLUs; LU++)
            {

                var LUparcels = Landuses.Where(pLU => pLU.Value == LU);
                foreach (KeyValuePair<short, short> par in LUparcels)
                {
                    Parcel par2 = parcels.Find(p => p.OID == par.Key);
                    LUArea[LU] += par2.Area;
                }
                CV += Math.Abs((LUArea[LU] - LURequiredAreas[LU]) / (LUArea[LU] + LURequiredAreas[LU]));
            }
            solH.LUArea = LUArea;
            return (CV / Settings.Default.NoOfLUs);
        }

        private double CalculateConstraintViolationForLUCode1Area(SolutionH solH)
        {

            double[] LUCode1Area = CalculateLUCode1Areas(solH);


            SortedList<short, short> LUCodes1 = solH.LUCode1;
            double CV = 0;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            for (int LUCode1 = 0; LUCode1 < NoOfLUCode1; LUCode1++)
            {
                if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0] < 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0]) / (LUCode1Area[LUCode1] + MinMaxLUCode1Areas[LUCode1, 0]));
                }
                else if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1] > 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1]) / (LUCode1Area[LUCode1] + MinMaxLUCode1Areas[LUCode1, 1]));
                }
            }

            solH.LUCode1Area = LUCode1Area;
            return (CV / NoOfLUCode1);
        }
        private double CalculateConstraintViolationForLUCode1AreaV2(SolutionH solH)
        {

            double[] LUCode1Area = CalculateLUCode1Areas(solH);


            SortedList<short, short> LUCodes1 = solH.LUCode1;
            double CV = 0;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            for (int LUCode1 = 0; LUCode1 < NoOfLUCode1; LUCode1++)
            {
                if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0] < 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 0]) / (MinMaxLUCode1Areas[LUCode1, 0]));
                }
                else if (LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1] > 0)
                {
                    CV += Math.Abs((LUCode1Area[LUCode1] - MinMaxLUCode1Areas[LUCode1, 1]) / (MinMaxLUCode1Areas[LUCode1, 1]));
                }
            }

            solH.LUCode1Area = LUCode1Area;
            return (CV);
        }
        private void CalPercapita(SolutionH solH)
        {
            foreach (KeyValuePair<short, short> kvp in solH.Landuses)
            {
                int LUCode1 = getLUCode1(kvp.Value);

            }
        }

        private List<SolutionH> Crossover2(List<SolutionH> pop)
        {
            int NoOfpar = Settings.Default.NoOFParcels;
            int CrossPopCount = Convert.ToInt32(pop.Count * Settings.Default.CrossoverPercent);
            List<SolutionH> Cross_pop = new List<SolutionH>(CrossPopCount);
            for (int i = 0; i < CrossPopCount; i = i + 2)
            {
                int par1 = SelectFromPopulation(pop);
                int par2 = SelectFromPopulation(pop);

                SortedList<short, short> ch1LU = new SortedList<short, short>(NoOfpar);
                SortedList<short, short> ch2LU = new SortedList<short, short>(NoOfpar);

                for (short j = 1; j < NoOfpar; j++)
                {
                    int R = rand.Next(2);
                    if (R == 0)
                    {
                        ch1LU[j] = pop[par1].Landuses[j];
                        ch2LU[j] = pop[par2].Landuses[j];
                    }
                    else
                    {
                        ch1LU[j] = pop[par2].Landuses[j];
                        ch2LU[j] = pop[par1].Landuses[j];
                    }

                }
                SolutionH Sol_ch1 = new SolutionH(ch1LU);
                SolutionH Sol_ch2 = new SolutionH(ch2LU);

                CalculateFitness(Sol_ch1);
                //Sol_ch1.ConstraintViolation = CalculateConstraintViolation(ch1LU);
                CalculateFitness(Sol_ch2);
                //Sol_ch2.ConstraintViolation = CalculateConstraintViolation(ch2LU);

                Cross_pop.Add(Sol_ch1);
                Cross_pop.Add(Sol_ch2);
            }
            return Cross_pop;
        }

        private List<SolutionH> Crossover3(List<SolutionH> pop)
        {

            int NoOfpar = Settings.Default.NoOFParcels;
            int CrossPopCount = Convert.ToInt32(pop.Count * Settings.Default.CrossoverPercent);
            List<SolutionH> Cross_pop = new List<SolutionH>(CrossPopCount);

            for (int i = 0; i < CrossPopCount; i = i + 2)
            {
                List<SolutionH> popForCross = new List<SolutionH>(pop);

                int p1 = SelectFromPopulation(popForCross);
                SolutionH par1 = popForCross[p1];

                popForCross.Remove(par1);

                int p2 = SelectFromPopulation(popForCross);
                SolutionH par2 = popForCross[p2];

                SortedList<short, short> ch1LU = new SortedList<short, short>(NoOfpar);
                SortedList<short, short> ch2LU = new SortedList<short, short>(NoOfpar);
                int NoOfSections = rand.Next(1, 100);
                for (int i2 = 0; i2 < NoOfSections; i2++)
                {
                    bool NotValid = true;
                    int SecSize = rand.Next((i2 * NoOfpar / NoOfSections) + 1, NoOfpar * (i2 + 2) / NoOfSections);
                    if (SecSize > NoOfpar)
                    {
                        SecSize = NoOfpar;
                        NotValid = false;
                    }
                    //This "while" checks that crossover occur from a place that at least 4 consecutive landuses are the same.
                    /*
                    while (NotValid)
                    {
                        NotValid = false;
                        for (int t = SecSize; t < SecSize + 1; t++)
                        {
                            if (pop[par1].Landuses[Convert.ToInt16(t)] != pop[par1].Landuses[Convert.ToInt16(t + 1)])
                            {
                                NotValid = true;
                                SecSize = rand.Next(2,NoOfpar * (i2 + 2) / NoOfSections);
                                if (SecSize > NoOfpar)
                                {
                                    SecSize = NoOfpar;
                                    NotValid = false;
                                }
                                break;
                            }
                        }
                    }
                     * */
                    ///////////////////////////////////////////////////////////////////////////////////////////////////////
                    short childSize = Convert.ToInt16(ch1LU.Count);
                    bool parSelector = Convert.ToBoolean(Math.IEEERemainder(i2, 2));
                    for (short j = childSize; j < SecSize ; j++)
                    {
                        if (parSelector)
                        {
                            ch1LU.Add(j, par1.Landuses[j]);
                            ch2LU.Add(j, par2.Landuses[j]);
                        }
                        else
                        {
                            ch1LU.Add(j, par2.Landuses[j]);
                            ch2LU.Add(j, par1.Landuses[j]);
                        }

                    }

                }
                short childSize2 = Convert.ToInt16(ch1LU.Count);
                bool parSelector2 = Convert.ToBoolean(Math.IEEERemainder(NoOfSections, 2));
                for (short j = childSize2; j < NoOfpar; j++)
                {
                    if (parSelector2)
                    {
                        ch1LU.Add(j, par1.Landuses[j]);
                        ch2LU.Add(j, par2.Landuses[j]);
                    }
                    else
                    {
                        ch1LU.Add(j, par2.Landuses[j]);
                        ch2LU.Add(j, par1.Landuses[j]);
                    }

                }
                SolutionH Sol_ch1 = new SolutionH(ch1LU);
                SolutionH Sol_ch2 = new SolutionH(ch2LU);

                //SaveLandusesToNewShapefile(par1.Landuses);
                //SaveLandusesToNewShapefile(par2.Landuses);

                //SaveLandusesToNewShapefile(ch1LU);
                //SaveLandusesToNewShapefile(ch2LU);

                CalculateFitness(Sol_ch1);
                //Sol_ch1.ConstraintViolation = CalculateConstraintViolation(ch1LU);
                CalculateFitness(Sol_ch2);
                //Sol_ch2.ConstraintViolation = CalculateConstraintViolation(ch2LU);

                Cross_pop.Add(Sol_ch1);
                Cross_pop.Add(Sol_ch2);
            }

            return Cross_pop;
        }

        private List<SolutionH> Crossover4(List<SolutionH> pop)
        {
            int NoOfpar = Settings.Default.NoOFParcels;
            int CrossPopCount = Convert.ToInt32(pop.Count * Settings.Default.CrossoverPercent);
            List<SolutionH> Cross_pop = new List<SolutionH>(CrossPopCount);

            for (int i = 0; i < CrossPopCount; i = i + 2)
            {
                int par1 = SelectFromPopulation(pop);
                int par2 = SelectFromPopulation(pop);

                SortedList<short, short> ch1LU = new SortedList<short, short>(NoOfpar);
                SortedList<short, short> ch2LU = new SortedList<short, short>(NoOfpar);
                int NoOfSections = 3;
                int SecSize = 0;
                for (int i2 = 0; i2 < NoOfSections; i2++)
                {

                    if (i2 == 2)
                    {
                        SecSize = NoOfpar;
                    }
                    else
                    {
                        SecSize = rand.Next(SecSize + 1, NoOfpar * (i2 + 2) / NoOfSections);
                    }

                    short childSize = Convert.ToInt16(ch1LU.Count + 1);
                    bool parSelector = Convert.ToBoolean(Math.IEEERemainder(i2, 2));
                    for (short j = childSize; j < SecSize + 1; j++)
                    {
                        if (parSelector)
                        {
                            ch1LU.Add(j, pop[par1].Landuses[j]);
                            ch2LU.Add(j, pop[par2].Landuses[j]);
                        }
                        else
                        {
                            ch1LU.Add(j, pop[par2].Landuses[j]);
                            ch2LU.Add(j, pop[par1].Landuses[j]);
                        }

                    }

                }
                SolutionH Sol_ch1 = new SolutionH(ch1LU);
                SolutionH Sol_ch2 = new SolutionH(ch2LU);

                CalculateFitness(Sol_ch1);
                CalculateFitness(Sol_ch2);

                Cross_pop.Add(Sol_ch1);
                Cross_pop.Add(Sol_ch2);



            }

            return Cross_pop;
        }

        private void CorrectCrossover(List<SolutionH> CrossPop)
        {
            foreach (SolutionH SolH in CrossPop)
            {
            }
        }

        private List<SolutionH> Crossover(List<SolutionH> pop)
        {
            int NoOfpar = Settings.Default.NoOFParcels;
            int CrossPopCount = Convert.ToInt32(pop.Count * Settings.Default.CrossoverPercent);
            List<SolutionH> Cross_pop = new List<SolutionH>(CrossPopCount);
            for (int i = 0; i < CrossPopCount; i = i + 2)
            {
                int par1 = SelectFromPopulation(pop);
                int par2 = SelectFromPopulation(pop);
                short R1 = Convert.ToInt16(rand.Next(NoOfpar * 1 / 3 - 200, NoOfpar * 1 / 3 + 200));
                short R2 = Convert.ToInt16(rand.Next(NoOfpar * 2 / 3 - 200, NoOfpar * 2 / 3 + 200));

                SortedList<short, short> ch1LU = new SortedList<short, short>(Settings.Default.NoOFParcels);
                SortedList<short, short> ch2LU = new SortedList<short, short>(Settings.Default.NoOFParcels);
                for (short j = 0; j < R1; j++)
                {
                    ch1LU[j] = pop[par1].Landuses[j];
                    ch2LU[j] = pop[par2].Landuses[j];
                }
                for (short j = R1; j < R2; j++)
                {
                    ch1LU[j] = pop[par2].Landuses[j];
                    ch2LU[j] = pop[par1].Landuses[j];
                }
                for (short j = R2; j < Settings.Default.NoOFParcels; j++)
                {
                    ch1LU[j] = pop[par1].Landuses[j];
                    ch2LU[j] = pop[par2].Landuses[j];
                }
                SolutionH Sol_ch1 = new SolutionH(ch1LU);
                SolutionH Sol_ch2 = new SolutionH(ch2LU);

                CalculateFitness(Sol_ch1);
                //Sol_ch1.ConstraintViolation = CalculateConstraintViolation(ch1LU);
                CalculateFitness(Sol_ch2);
                //Sol_ch2.ConstraintViolation = CalculateConstraintViolation(ch2LU);

                Cross_pop.Add(Sol_ch1);
                Cross_pop.Add(Sol_ch2);
            }
            return Cross_pop;
        }
        public double[] CalculateFitness(int OID, SolutionH SolH, short pLU, short obj)
        {
            double CMPLU1LU2;
            double DepLU1LU2;
            Parcel parcel = parcels.Find(p => p.OID == OID);
            SortedList<short, short> LUs = SolH.Landuses;
            int effectRadius = Convert.ToInt32(EffectRadiuses.val[pLU, 0]);
            double FeatureCompability = 0;
            double FeatureDependancy = 0;
            double FeatureCompactness = 0;
            int NumOfNeighbors = 0;
            IList<short> neighs = parcel.NeigberHood[pLU];
            foreach (short neighOID in neighs)
            {
                double min_distOfPN = parcel.minDistOfneighber[neighOID];

                double Alfa = Math.Abs(effectRadius - min_distOfPN) / effectRadius;

                int neighfeature_LUCode = LUs[neighOID];
                CMPLU1LU2 = Compatibilities.val[pLU, neighfeature_LUCode];
                DepLU1LU2 = Dependancies.val[pLU, neighfeature_LUCode];
                FeatureCompability = FeatureCompability + Alfa * CMPLU1LU2;
                FeatureDependancy = FeatureDependancy + Alfa * DepLU1LU2;

                if (pLU == neighfeature_LUCode)
                {
                    FeatureCompactness++;
                }
                NumOfNeighbors++;
            }
            double[] Objectives = new double[Settings.Default.NoOFObj];
            Objectives[0] = -FeatureCompability / NumOfNeighbors;
            Objectives[1] = -FeatureDependancy / NumOfNeighbors;
            Objectives[2] = -parcel.suitability[pLU];
            Objectives[3] = -FeatureCompactness / NumOfNeighbors;
            SortedList<short, short> nLUs = new SortedList<short, short>(LUs);
            nLUs[Convert.ToInt16(OID)] = pLU;
            if (obj == 4)
            {
                Objectives[4] = CalculateCV(Convert.ToInt16(OID), SolH, pLU);
            }
            else
            {
                Objectives[4] = double.MaxValue;
            }
            return Objectives;
        }

        private List<SolutionH> EliteMutation(List<SolutionH> pop)
        {
            List<SolutionH> EliteMutpop = new List<SolutionH>();

            List<SolutionH> Elites = pop.FindAll(p => p.isElite == true);
            int NoOfPar = Settings.Default.NoOFParcels;
            short NoOfSelectedparcels = Convert.ToInt16(Settings.Default.NoOFParcels * 0.1);
            foreach (SolutionH Elite in Elites)
            {
                foreach (short obj in Elite.EliteObjectives)
                {
                    SortedList<short, short> EliteMuLU = new SortedList<short, short>(Elite.Landuses);
                    //Selecting 10 percent of parcels randomly--------------------------------
                    List<short> SelectedParcels = new List<short>(NoOfSelectedparcels);
                    for (short i = 0; i < NoOfSelectedparcels; i++)
                    {
                        short R = Convert.ToInt16(rand.Next(0, NoOfPar-1));
                        if (!SelectedParcels.Contains(R))
                        {
                            SelectedParcels.Add(R);
                        }
                    }
                    //-------------------------------------------------------------------------
                    foreach (short p in SelectedParcels)
                    {
                        short bestLU = EliteMuLU[p];
                        double minFit = Elite.Fitness[obj];
                        for (short LU = 0; LU < Settings.Default.NoOfLUs; LU++)
                        {
                            double[] Fits = CalculateFitness(p, Elite, LU, obj);

                            if (Fits[obj] < minFit)
                            {
                                minFit = Fits[obj];
                                bestLU = LU;
                            }
                        }
                        EliteMuLU[p] = bestLU;
                    }
                    SolutionH EliteMu_Sol = new SolutionH(EliteMuLU);
                    CalculateFitness(EliteMu_Sol);
                    //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                    EliteMutpop.Add(EliteMu_Sol);

                }
            }

            return EliteMutpop;
        }

        private SortedList<short, List<SolutionH>> Top_Solutions(List<SolutionH> pop, double percent)
        {
            int psize = Settings.Default.InitialPopulation;
            int TopsizeperObj = Convert.ToInt32(percent * psize);
            SortedList<short, List<SolutionH>> Top_sols = new SortedList<short, List<SolutionH>>(Settings.Default.NoOFObj);
            for (short obj = 0; obj < Settings.Default.NoOFObj; obj++)
            {
                List<SolutionH> TopSolsPerObj = new List<SolutionH>(TopsizeperObj * Settings.Default.NoOFObj);
                List<SolutionH> sortedpop = pop.OrderBy(s => s.Fitness[obj]).ToList<SolutionH>();
                for (int i = 0; i < TopsizeperObj; i++)
                {
                    TopSolsPerObj.Add(sortedpop[i]);
                }
                Top_sols.Add(obj, TopSolsPerObj);
            }
            return Top_sols;
        }
        private List<SolutionH> TopSolutionMutationConstraitBased(List<SolutionH> pop)
        {
            List<SolutionH> Mutpop = new List<SolutionH>();

            SortedList<short, List<SolutionH>> TopSols = Top_Solutions(pop, 0.1);
            int NoOfPar = Settings.Default.NoOFParcels;
            short NoOfSelectedparcels = Convert.ToInt16(Settings.Default.NoOFParcels * 0.1);
            foreach (KeyValuePair<short, List<SolutionH>> ObjTopSolH in TopSols)
            {
                short obj = ObjTopSolH.Key;
                foreach (SolutionH TopSolH in ObjTopSolH.Value)
                {
                    SortedList<short, short> EliteMuLU = new SortedList<short, short>(TopSolH.Landuses);
                    //Selecting 10 percent of parcels randomly--------------------------------
                    List<short> SelectedParcels = new List<short>(NoOfSelectedparcels);
                    for (short i = 0; i < NoOfSelectedparcels; i++)
                    {
                        short R = Convert.ToInt16(rand.Next(0, NoOfPar-1));
                        if (!SelectedParcels.Contains(R))
                        {
                            SelectedParcels.Add(R);
                        }
                    }
                    //-------------------------------------------------------------------------
                    foreach (short par in SelectedParcels)
                    {
                        short bestLU = EliteMuLU[par];
                        double minFit = double.MaxValue;
                        Parcel p = parcels.Find(pa => pa.OID == par);
                        List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                        LandUse oldLU = LUClassList.Find(l => l.LUNo == EliteMuLU[par]);
                        foreach (LandUse LU in AcceptableLUs)
                        {
                            //if (PercapitaAreaCheck(TopSolH, p, oldLU, LU))
                            //{
                            double[] Fits = CalculateFitness(par, TopSolH, LU.LUNo, obj);

                            if (Fits[obj] < minFit)
                            {
                                minFit = Fits[obj];
                                bestLU = LU.LUNo;
                            }
                            //}
                        }
                        EliteMuLU[par] = bestLU;
                    }
                    SolutionH EliteMu_Sol = new SolutionH(EliteMuLU);
                    CalculateFitness(EliteMu_Sol);
                    //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                    Mutpop.Add(EliteMu_Sol);
                }
            }

            return Mutpop;
        }

        private List<SolutionH> EliteMutationConstraitBased(List<SolutionH> pop)
        {
            List<SolutionH> EliteMutpop = new List<SolutionH>();

            List<SolutionH> Elites = pop.FindAll(p => p.isElite == true);
            int NoOfPar = Settings.Default.NoOFParcels;
            short NoOfSelectedparcels = Convert.ToInt16(Settings.Default.NoOFParcels * 0.1);
            foreach (SolutionH Elite in Elites)
            {
                foreach (short obj in Elite.EliteObjectives)
                {
                    SortedList<short, short> EliteMuLU = new SortedList<short, short>(Elite.Landuses);
                    //Selecting 10 percent of parcels randomly--------------------------------
                    List<short> SelectedParcels = new List<short>(NoOfSelectedparcels);
                    for (short i = 0; i < NoOfSelectedparcels; i++)
                    {
                        short R = Convert.ToInt16(rand.Next(0, NoOfPar-1));
                        if (!SelectedParcels.Contains(R))
                        {
                            SelectedParcels.Add(R);
                        }
                    }
                    //-------------------------------------------------------------------------
                    foreach (short par in SelectedParcels)
                    {
                        short bestLU = EliteMuLU[par];
                        double minFit = Elite.Fitness[obj];
                        Parcel p = parcels.Find(pa => pa.OID == par);
                        List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                        LandUse oldLU = LUClassList.Find(l => l.LUNo == EliteMuLU[par]);
                        foreach (LandUse LU in AcceptableLUs)
                        {
                            //if ( PercapitaAreaCheck(Elite, p, oldLU, LU))
                            //{
                            double[] Fits = CalculateFitness(par, Elite, LU.LUNo, obj);

                            if (Fits[obj] < minFit)
                            {
                                minFit = Fits[obj];
                                bestLU = LU.LUNo;
                            }
                            //}
                        }
                        EliteMuLU[par] = bestLU;
                    }
                    SolutionH EliteMu_Sol = new SolutionH(EliteMuLU);
                    CalculateFitness(EliteMu_Sol);
                    //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                    EliteMutpop.Add(EliteMu_Sol);

                }
            }

            return EliteMutpop;
        }
        private List<SolutionH> Mutation(List<SolutionH> pop, int itr)
        {
            List<SolutionH> Mutpop = new List<SolutionH>();
            int MutCount = Convert.ToInt32(Settings.Default.InitialPopulation * Settings.Default.MutationRate);
            for (int i = 0; i < MutCount; i++)
            {

                int MuPar = rand.Next(0, Settings.Default.InitialPopulation);
                SortedList<short, short> MuLU = new SortedList<short, short>(pop[MuPar].Landuses);

                int noOfparelsToMut = Convert.ToInt32(0.1 * Settings.Default.NoOFParcels);
                List<short> parcelsToMut = getRandomParcellsToMutation(noOfparelsToMut);
                foreach (short par in parcelsToMut)
                {
                    MuLU[par] = Convert.ToInt16(rand.Next(Settings.Default.NoOfLUs));
                }
                SolutionH Mu_Sol = new SolutionH(MuLU);
                CalculateFitness(Mu_Sol);
                //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                Mutpop.Add(Mu_Sol);
            }
            return Mutpop;
        }

        private double getParcelEffectiveLUArea(Parcel par, LandUse LU)
        {
            double ParEffectiveArea = par.Area;
            if (LU.LUCode1 == 1)
            {
                if (par.Area <= 300)
                {
                    ParEffectiveArea = par.Area * 1.6;
                }
                else if (par.Area > 300 & par.Area <= 450)
                {
                    ParEffectiveArea = par.Area * 1.8;
                }
                else if (par.Area > 450 & par.Area <= 550)
                {
                    ParEffectiveArea = par.Area * 2;
                }
                else
                {
                    ParEffectiveArea = par.Area * 2.2;
                }
            }
            return ParEffectiveArea;
        }

        private bool PercapitaAreaCheck(SolutionH SolH, Parcel par, LandUse oldLU, LandUse newLU)
        {
            bool result = true;
            double oldLUEffectiveArea = getParcelEffectiveLUArea(par, oldLU);
            double newLUEffectiveArea = getParcelEffectiveLUArea(par, newLU);
            if (MinMaxLUCode1Areas[oldLU.LUCode1, 0] > (SolH.LUCode1Area[oldLU.LUCode1] - oldLUEffectiveArea))
            {
                result = false;
            }
            else if (MinMaxLUCode1Areas[oldLU.LUCode1, 1] < (SolH.LUCode1Area[oldLU.LUCode1] - oldLUEffectiveArea))
            {
                result = true;
            }

            else if (MinMaxLUCode1Areas[newLU.LUCode1, 1] < (SolH.LUCode1Area[newLU.LUCode1] + newLUEffectiveArea))
            {
                result = false;
            }
            else if (MinMaxLUCode1Areas[newLU.LUCode1, 0] > (SolH.LUCode1Area[newLU.LUCode1] + newLUEffectiveArea))
            {
                result = true;
            }
            return result;
        }

        private List<SolutionH> MutationConstraintBased(List<SolutionH> pop, int itr)
        {
            List<SolutionH> Mutpop = new List<SolutionH>();
            int MutCount = Convert.ToInt32(Settings.Default.InitialPopulation * Settings.Default.MutationRate);
            for (int i = 0; i < MutCount; i++)
            {

                int SolForMuID = rand.Next(0, pop.Count - 1);
                SolutionH SolForMu = pop[SolForMuID];
                SortedList<short, short> MuLU = new SortedList<short, short>(pop[SolForMuID].Landuses);

                int noOfparelsToMut = Convert.ToInt32(0.2 * Settings.Default.NoOFParcels);
                List<short> parcelsToMut = getRandomParcellsToMutation(noOfparelsToMut);
                foreach (short par in parcelsToMut)
                {
                    Parcel p = parcels.Find(pa => pa.OID == par);
                    List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                    LandUse oldLU = LUClassList.Find(l => l.LUNo == MuLU[par]);
                    while (AcceptableLUs.Count != 0)
                    {
                        int RandLU = rand.Next(AcceptableLUs.Count - 1);
                        //if (PercapitaAreaCheck(SolForMu, p, oldLU, AcceptableLUs[RandLU]))
                        //{
                        MuLU[par] = AcceptableLUs[RandLU].LUNo;
                        break;
                        //}
                        //else
                        //{
                        //   AcceptableLUs.Remove(AcceptableLUs[RandLU]);
                        //}
                    }
                }
                SolutionH Mu_Sol = new SolutionH(MuLU);
                CalculateFitness(Mu_Sol);
                //Mu_Sol.ConstraintViolation = CalculateConstraintViolation(MuLU);
                Mutpop.Add(Mu_Sol);
            }
            return Mutpop;
        }

        private int SelectFromPopulation(List<SolutionH> pop)
        {
            Random R = new Random();
            int BestPopID;
            BestPopID = R.Next(0, pop.Count);
            if (pop[BestPopID].isElite)
            {
                return BestPopID;
            }
            for (int i = 0; i < Settings.Default.CrossTourSize; i++)
            {
                int ID = R.Next(0, pop.Count);
                if (pop[ID].isElite)
                {
                    return ID;
                }
                if (pop[ID].FrontRank == pop[BestPopID].FrontRank)
                {
                    if (pop[ID].HNSGAneighborCount < pop[BestPopID].HNSGAneighborCount)
                    {
                        BestPopID = ID;
                    }
                }
                else
                {
                    if (pop[ID].FrontRank < pop[BestPopID].FrontRank)
                    {
                        BestPopID = ID;
                    }
                }

            }
            return BestPopID;
        }

        private List<List<SolutionH>> RankDominance(List<SolutionH> pop)
        {
            int popSize = pop.Count;


            Int16[,] DominateMatix = new Int16[popSize, popSize];

            int k = 0;
            List<List<SolutionH>> F = new List<List<SolutionH>>();
            F.Add(new List<SolutionH>());
            List<List<int>> Froid = new List<List<int>>();
            Froid.Add(new List<int>());
            for (int i = 0; i < popSize; i++)
            {
                SolutionH a = pop[i];

                if (i == popSize - 1)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                    break;
                }

                for (int j = i + 1; j < popSize; j++)
                {
                    SolutionH b = pop[j];

                    if (Dominate(a, b))
                    {
                        DominateMatix[i, j] = 1;
                    }
                    else if (Dominate(b, a))
                    {
                        DominateMatix[j, i] = 1;
                    }
                }
                if (sumColumn(DominateMatix, i) == 0)
                {
                    pop[i].FrontRank = k;
                    F[k].Add(pop[i]);
                    Froid[k].Add(i);
                }
            }
            int FCount = F[k].Count;
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[Froid[k][i], j] = 0;
                }
            }
            for (int i = 0; i < FCount; i++)
            {
                for (int j = 0; j < popSize; j++)
                {
                    DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                }
            }

            //int[,] qwe=DominateMatix;
            while (true)
            {
                k = k + 1;
                F.Add(new List<SolutionH>());
                Froid.Add(new List<int>());
                for (int i = 0; i < popSize; i++)
                {
                    if (sumColumn(DominateMatix, i) == 0)
                    {
                        pop[i].FrontRank = k;
                        F[k].Add(pop[i]);
                        Froid[k].Add(i);
                    }
                }

                FCount = F[k].Count;

                if (FCount == 0)
                {
                    break;
                }

                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[Froid[k][i], j] = 0;
                    }
                }
                for (int i = 0; i < FCount; i++)
                {
                    for (int j = 0; j < popSize; j++)
                    {
                        DominateMatix[j, Froid[k][i]] = Int16.MaxValue;
                    }
                }
            }
            F.RemoveAt(F.Count - 1);
            return F;
        }

        private bool Dominate(SolutionH sol1, SolutionH sol2)
        {
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] > sol2.Fitness[i])
                {
                    return false;
                }
            }
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (sol1.Fitness[i] < sol2.Fitness[i])
                {
                    return true;
                }
            }
            return false;
        }

        private int sumColumn(Int16[,] DM, int ColIdx)
        {
            int RowCount = DM.GetLength(0);
            int sum = 0;
            for (int i = 0; i < RowCount; i++)
            {
                sum = sum + DM[i, ColIdx];
            }
            return sum;
        }

        private List<SolutionH> NeigberMemberCountInHCube(List<SolutionH> LF)
        {
            List<SolutionH> NewLF = FindHcubeOfSols(LF);
            LF = null;
            int LFCount = NewLF.Count;
            foreach (SolutionH sol2 in NewLF)
            {
                sol2.HNSGAneighborCount = 0;
            }
            for (int i = 0; i < LFCount; i++)
            {
                for (int j = i + 1; j < LFCount; j++)
                {
                    if (NewLF[i].FrontRank == NewLF[j].FrontRank && isEqual(NewLF[i].HNSGACubeIndex, NewLF[j].HNSGACubeIndex))
                    {
                        NewLF[i].HNSGAneighborCount += 1;
                        NewLF[j].HNSGAneighborCount += 1;
                    }
                }
            }
            return NewLF;
        }

        private List<SolutionH> FindHcubeOfSols(List<SolutionH> pop)
        {
            CreateHyperCube(pop);
            List<SolutionH> NewPop = new List<SolutionH>(pop);
            pop = null;
            int LFcount = NewPop.Count;
            foreach (SolutionH s2 in NewPop)
            {
                short[] hCubeidx = new short[Settings.Default.NoOFObj];
                for (int obj = 0; obj < Settings.Default.NoOFObj; obj++)
                {
                    for (short p = 0; p < Settings.Default.HyberCubeCellsCount; p++)
                    {
                        if (s2.Fitness[obj] >= (MinFits[obj] + p * HyperCellLength[obj]) &&
                            s2.Fitness[obj] <= (MinFits[obj] + (p + 1) * HyperCellLength[obj]))
                        {
                            hCubeidx[obj] = p;
                        }
                    }
                }
                s2.HNSGACubeIndex = hCubeidx;
            }
            return NewPop;
        }

        double[] MaxFits;
        double[] MinFits;
        double[] HyperCellLength;
        private void CreateHyperCube(List<SolutionH> pop)
        {
            List<double[]> Fitness = pop.Select(S => S.Fitness).ToList<double[]>();
            MaxFits = new double[Settings.Default.NoOFObj];
            MinFits = new double[Settings.Default.NoOFObj];
            HyperCellLength = new double[Settings.Default.NoOFObj];
            for (int obj = 0; obj < Settings.Default.NoOFObj; obj++)
            {
                MaxFits[obj] = Fitness.Select(F => F[obj]).Max();
                MinFits[obj] = Fitness.Select(F => F[obj]).Min();
                HyperCellLength[obj] = (MaxFits[obj] - MinFits[obj]) / Settings.Default.HyberCubeCellsCount;
            }

        }

        private bool isEqual(short[] a, short[] b)
        {
            for (int i = 0; i < Settings.Default.NoOFObj; i++)
            {
                if (a[i] != b[i])
                {
                    return false;
                }
            }
            return true;
        }
        /*
        private List<Solution> InitializePopulation(int PopSize)
        {

            List<Solution> Population = new List<Solution>(PopSize);
            Classes.OptimizationParameters OP = new Classes.OptimizationParameters(fc_Parcells, fc_PopBlocks);
            double[] LURequiredAreas = CalculateRequiredAreas();
            for (int i = 0; i < PopSize; i++)
            {
                IFeature feature = fc_Parcells.GetFeature(1);
                //int NumOfFeatures = fc_Parcells.FeatureCount(null);
                int NoOfCriteria = Settings.Default.NoOfCriteria;
                int NoOfLUs = Settings.Default.NoOfLUs;
                //IFeatureClass fc_new = CreateShapeFile(Settings.Default.PopulationLocation + i.ToString(), feature.Shape);
                //int OldLUCodeIdx = fc_Parcells.Fields.FindField("LUCode");
                int[] NewLUs = new int[Settings.Default.NoOFParcels+1];
                for (int j=0;j<NewLUs.Length; j++)
                {
                    NewLUs[j] = 100;
                }
                List<int> RandLU=getRandomLUs();
                foreach(int LU in RandLU )
                {
                    double Area = 0;
                    int Rank = 0;
                    if (LURequiredAreas[LU] < 50)
                    {
                        continue;
                    }
                    while ((Area < LURequiredAreas[LU]) & (Rank++ < Settings.Default.NoOfLUs))
                    {
                        IQueryFilter queryFilter = new QueryFilterClass();
                        queryFilter.WhereClause = "Rank" + Rank + "=" + LU;
                        IFeatureCursor Parcursor = fc_Parcells.Search(queryFilter, true);
                        IFeature parcell;
                        while (!((parcell = Parcursor.NextFeature()) == null))
                        {
                            if (NewLUs[parcell.OID]==100)
                            {
                                NewLUs[parcell.OID] = LU;
                                Area += (parcell.Shape as IArea).Area;
                                if (Area >= LURequiredAreas[LU])
                                {
                                    break;
                                }
                            }
                        }
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(Parcursor);
                        //ComReleaser cr = new ComReleaser();
                        //cr.ManageLifetime(Parcursor); 
                    }
                }
                
                Solution SolH = new Solution(NewLUs);
                Classes.BinarySerialization.WriteToBinaryFile<Solution>(Settings.Default.DataForRun + "test.bin", SolH, false);
                
                
                SolH.Fitness = OP.CalculateFitness2(parcels,NewLUs);

                Population.Add(SolH);
            }
            return Population;
        }
        */

        private List<SolutionH> InitilalizePops(int popsize)
        {
            List<SolutionH> Pop = new List<SolutionH>(popsize);
            for (int i = 0; i < popsize; i++)
            {
                SolutionH solh = InitializePopswihoutpercapitaconstraint();
                Pop.Add(solh);
            }
            return Pop;

        }
        private SolutionH InitializePopswihoutpercapitaconstraint()
        {
            List<int> AcceptableLUsCounts = new List<int>(Settings.Default.NoOFParcels);
        FirstLine:
            SortedList<short, short> newLU = new SortedList<short, short>(Settings.Default.NoOFParcels);
            double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
            //List<Parcel> newParcels = parcels.OrderByDescending(a => a.).ThenByDescending(a=>a.AccessType).ToList<Parcel>();
            List<Parcel> newParcels = parcels.OrderBy(a => Guid.NewGuid()).ToList<Parcel>();
            List<Parcel> UnassignedParcels = new List<Parcel>();
            foreach (Parcel p in newParcels)
            {
                if (p.Area <= 0)
                {
                    p.Area = -p.Area;
                }
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                //AcceptableLUsCounts.Add(AcceptableLUs.Count);
                short r = 0;
                int LUCode1=0;
                if (AcceptableLUs.Count != 0)
                {
                    r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                    LUCode1 = AcceptableLUs[r].LUCode1;
                }
                bool isParcelLUAsigned = false;
                while (!isParcelLUAsigned && AcceptableLUs.Count != 0)
                {
                    if (LUCode1 == 1)
                    {
                        if (p.Area <= 300)
                        {
                            LUCode1Area[LUCode1] += p.Area * 1.6;
                        }
                        else if (p.Area > 300 & p.Area <= 450)
                        {
                            LUCode1Area[LUCode1] += p.Area * 1.8;
                        }
                        else if (p.Area > 450 & p.Area <= 550)
                        {
                            LUCode1Area[LUCode1] += p.Area * 2;
                        }
                        else
                        {
                            LUCode1Area[LUCode1] += p.Area * 2.2;
                        }
                        newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                        isParcelLUAsigned = true;

                    }
                    else
                    {
                        LUCode1Area[LUCode1] += p.Area;
                        newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                        isParcelLUAsigned = true;
                    }
                }
                if (!isParcelLUAsigned)
                {
                    UnassignedParcels.Add(p);
                }
            }

            foreach (Parcel p in UnassignedParcels)
            {
                //Assigning reminging parcels
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                List<LandUse> SelectableLUs = new List<LandUse>();
                foreach (LandUse LU in AcceptableLUs)
                {
                    if (MinMaxLUCode1Areas[LU.LUCode1, 1] - LUCode1Area[LU.LUCode1] > p.Area)
                    {
                        SelectableLUs.Add(LU);
                    }
                }
                if (SelectableLUs.Count != 0)
                {
                    int r = rand.Next(SelectableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), SelectableLUs[r].LUNo);
                }
                else if (AcceptableLUs.Count != 0)
                {
                    int r = rand.Next(AcceptableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                }
                else
                {
                    newLU.Add(Convert.ToInt16(p.OID), Convert.ToInt16(rand.Next(36)));
                }

            }
            if (newLU.Count < Settings.Default.NoOFParcels)
            {
                //goto FirstLine;
            }
            SolutionH SolH = new SolutionH(newLU);
            CalculateFitness(SolH);
            //MessageBox.Show(AcceptableLUsCounts.Average().ToString());
            return SolH;
        }
        private SolutionH InitializePopsConstriantsBasedPriatizing()
        {
        FirstLine:
            SortedList<short, short> newLU = new SortedList<short, short>(Settings.Default.NoOFParcels);
            double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
            //List<Parcel> newParcels = parcels.OrderByDescending(a => a.).ThenByDescending(a=>a.AccessType).ToList<Parcel>();
            List<Parcel> newParcels = parcels.OrderBy(a => Guid.NewGuid()).ToList<Parcel>();
            List<Parcel> UnassignedParcels = new List<Parcel>();
            foreach (Parcel p in newParcels)
            {
                if (p.Area <= 0)
                {
                    p.Area = -p.Area;
                }
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                short r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                int LUCode1 = AcceptableLUs[r].LUCode1;
                bool isParcelLUAsigned = false;
                while (!isParcelLUAsigned && AcceptableLUs.Count != 0)
                {
                    if (MinMaxLUCode1Areas[LUCode1, 1] - LUCode1Area[LUCode1] > p.Area)
                    {
                        if (LUCode1 == 1)
                        {
                            if (p.Area <= 300)
                            {
                                LUCode1Area[LUCode1] += p.Area * 1.6;
                            }
                            else if (p.Area > 300 & p.Area <= 450)
                            {
                                LUCode1Area[LUCode1] += p.Area * 1.8;
                            }
                            else if (p.Area > 450 & p.Area <= 550)
                            {
                                LUCode1Area[LUCode1] += p.Area * 2;
                            }
                            else
                            {
                                LUCode1Area[LUCode1] += p.Area * 2.2;
                            }
                            newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                            isParcelLUAsigned = true;

                        }
                        else
                        {
                            LUCode1Area[LUCode1] += p.Area;
                            newLU.Add(Convert.ToInt16(p.OID), AcceptableLUs[r].LUNo);
                            isParcelLUAsigned = true;
                        }
                    }
                    else
                    {
                        AcceptableLUs.Remove(AcceptableLUs[r]);
                        if (AcceptableLUs.Count != 0)
                        {
                            r = Convert.ToInt16(rand.Next(AcceptableLUs.Count - 1));
                            LUCode1 = AcceptableLUs[r].LUCode1;
                        }
                    }
                }
                if (!isParcelLUAsigned)
                {
                    UnassignedParcels.Add(p);
                }
            }

            foreach (Parcel p in UnassignedParcels)
            {
                //Assigning reminging parcels
                List<LandUse> AcceptableLUs = LUClassList.FindAll(lu => lu.AcceptableStreets.Contains(p.AccessType) && lu.minAcceptableArea <= p.Area && lu.maxAcceptableArea >= p.Area);
                List<LandUse> SelectableLUs = new List<LandUse>();
                foreach (LandUse LU in AcceptableLUs)
                {
                    if (MinMaxLUCode1Areas[LU.LUCode1, 1] - LUCode1Area[LU.LUCode1] > p.Area)
                    {
                        SelectableLUs.Add(LU);
                    }
                }
                if (SelectableLUs.Count != 0)
                {
                    int r = rand.Next(SelectableLUs.Count - 1);
                    newLU.Add(Convert.ToInt16(p.OID), SelectableLUs[r].LUNo);
                }

            }
            if (newLU.Count < Settings.Default.NoOFParcels)
            {
                goto FirstLine;
            }
            SolutionH SolH = new SolutionH(newLU);
            CalculateFitness(SolH);
            return SolH;
        }

        private void SaveLandusesToNewShapefile(SortedList<short, short> LU)
        {
            DateTime dt = DateTime.Now;
            string DataFolderName = Settings.Default.DataForRun + "Results\\ShapeFiles\\For Test" + dt.Year + "," + dt.Month + "," + dt.Day + "_" + dt.Hour + ";" + dt.Minute + ";" + dt.Second + "\\";

            System.IO.Directory.CreateDirectory(DataFolderName);

            IFeature feature = fc_Parcells.GetFeature(1);
            IFeatureClass fc_new = CreateShapeFile(DataFolderName + "Map", feature.Shape);
            int LUIdx = fc_new.Fields.FindField("LUCode");
            int LU1Idx = fc_new.Fields.FindField("LUCode1");
            IFeatureCursor cursor = fc_Parcells.Search(null, true);
            IFeature parcell;
            if (StartEditing((fc_new as IDataset).Workspace))
            {

                while ((parcell = cursor.NextFeature()) != null)
                {
                    if (LU.Keys.Contains(Convert.ToInt16(parcell.OID)))
                    {
                        IFeature newFeature = fc_new.CreateFeature();
                        newFeature.Shape = parcell.Shape;
                        newFeature.set_Value(LUIdx, LU[Convert.ToInt16(parcell.OID)]);
                        newFeature.set_Value(LU1Idx, getLUCode1(LU[Convert.ToInt16(parcell.OID)]));
                        newFeature.Store();
                    }
                }

            out1:
                try
                {

                    StopEditing((fc_new as IDataset).Workspace);
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                    goto out1;

                }
            }
            else
            {
                MessageBox.Show("Error in OptimalityToshp: Editing don't start!!!");
            }
        }

        private void InitializePopsConstriantsBased(int PopSize)
        {
            SortedList<short, short> newLU = new SortedList<short, short>(Settings.Default.NoOFParcels);
            double[] LUCode1Area = new double[Settings.Default.NoOfLUCode1];
            var newParcels = parcels.OrderBy(a => a.AccessType).ThenByDescending(a => a.Area).ToList<Parcel>();
            foreach (Parcel p in newParcels)
            {
                bool isParcelLUAsigned = false;
                List<short> LUList = StTypeLUs[p.AccessType];
                while (!isParcelLUAsigned && LUList.Count != 0)
                {
                    short r = Convert.ToInt16(rand.Next(LUList.Count - 1));
                    int LUCode1 = getLUCode1(LUList[r]);
                    if (MinMaxLUCode1Areas[LUCode1 - 1, 1] - LUCode1Area[LUCode1] > p.Area)
                    {
                        if (LUCode1 == 1)
                        {
                            if (p.Area <= 650)
                            {
                                if (p.Area <= 300)
                                {
                                    LUCode1Area[LUCode1] += p.Area * 1.6;
                                }
                                else if (p.Area > 300 & p.Area <= 450)
                                {
                                    LUCode1Area[LUCode1] += p.Area * 1.8;
                                }
                                else if (p.Area > 450 & p.Area <= 550)
                                {
                                    LUCode1Area[LUCode1] += p.Area * 2;
                                }
                                else
                                {
                                    LUCode1Area[LUCode1] += p.Area * 2.2;
                                }
                                newLU.Add(Convert.ToInt16(p.OID), LUList[r]);
                                isParcelLUAsigned = true;
                            }
                            else
                            {
                                LUList.Remove(LUList[r]);
                            }
                        }
                        else if (LUCode1 == 3)
                        {
                            if (p.Area > 1000)
                            {
                                LUCode1Area[LUCode1] += p.Area;
                                newLU.Add(Convert.ToInt16(p.OID), LUList[r]);
                                isParcelLUAsigned = true;
                            }
                            else
                            {
                                LUList.Remove(LUList[r]);
                            }
                        }
                        else if (LUCode1 == 8)
                        {
                            if (p.Area > 1000)
                            {
                                LUCode1Area[LUCode1] += p.Area;
                                newLU.Add(Convert.ToInt16(p.OID), LUList[r]);
                                isParcelLUAsigned = true;
                            }
                            else
                            {
                                LUList.Remove(LUList[r]);
                            }
                        }
                        else if (LUCode1 == 11)
                        {
                            if (p.Area > 1000)
                            {
                                LUCode1Area[LUCode1] += p.Area;
                                newLU.Add(Convert.ToInt16(p.OID), LUList[r]);
                                isParcelLUAsigned = true;
                            }
                            else
                            {
                                LUList.Remove(LUList[r]);
                            }
                        }

                        else
                        {
                            LUCode1Area[LUCode1] += p.Area;
                            newLU.Add(Convert.ToInt16(p.OID), LUList[r]);
                            isParcelLUAsigned = true;
                        }
                    }
                    else
                    {
                        LUList.Remove(LUList[r]);
                    }
                }
            }

        }



        private List<SolutionH> InitializePopulationRandomly(int PopSize)
        {
            int NoOfLU = Settings.Default.NoOfLUs;
            double[] Area = new double[NoOfLU];
            double[] CV = new double[NoOfLU];

            List<int> LUs = new List<int>(NoOfLU);
            for (int Lu = 0; Lu < NoOfLU; Lu++)
            {
                LUs.Add(Lu);
            }

            int NofP = Settings.Default.NoOFParcels;
            List<SolutionH> Population = new List<SolutionH>(PopSize);
            SortedList<short, short> CurrentLUs = new SortedList<short, short>();

            for (int i = 0; i < PopSize; i++)
            {
                SortedList<short, short> newLU = new SortedList<short, short>(CurrentLUs);

                foreach (Parcel p in parcels)
                {
                    List<int> tempLUs = new List<int>(LUs);
                    int LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                    while (true)
                    {
                        if (LURequiredAreas[LU] < 10)
                        {
                            tempLUs.Remove(LU);
                            if (tempLUs.Count == 0)
                            {
                                newLU.Add(Convert.ToInt16(p.OID), Convert.ToInt16(rand.Next(NoOfLU)));
                                Area[LU] += p.Area;

                                break;
                            }
                            LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                            continue;
                        }
                        if (LURequiredAreas[LU] - Area[LU] < 0.1 * LURequiredAreas[LU])
                        {
                            tempLUs.Remove(LU);
                            LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                            continue;
                        }
                        if (LURequiredAreas[LU] - (Area[LU] + p.Area) < -0.1 * LURequiredAreas[LU])
                        {
                            LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                            continue;
                        }
                        int Rank = p.Ranks.ToList().IndexOf(Convert.ToInt16(LU));
                        double prob = (NoOfLU - Rank) / (double)NoOfLU;
                        if ((rand.NextDouble() < prob))
                        {
                            newLU.Add(Convert.ToInt16(p.OID), Convert.ToInt16(LU));
                            Area[LU] += p.Area;
                            LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                            break;
                        }
                        else
                        {
                            LU = tempLUs[rand.Next(tempLUs.Count - 1)];
                            continue;
                        }
                    }

                }
                SolutionH SolH = new SolutionH(newLU);
                CalculateFitness(SolH);
                Population.Add(SolH);
            }
            return Population;
        }

        private List<SolutionH> InitializePopulationFromCurrentLU(int PopSize)
        {
            int NofP = Settings.Default.NoOFParcels;
            int NofLU = Settings.Default.NoOfLUs;
            int RandParcelNo = Convert.ToInt32(((double)Settings.Default.NoOFParcels) * (Settings.Default.InitialPopFromCurrentPopPercent));
            List<SolutionH> Population = new List<SolutionH>(PopSize);

            SortedList<short, short> CurrentLUs = new SortedList<short, short>();

            foreach (Parcel p in parcels)
            {
                CurrentLUs.Add(Convert.ToInt16(p.OID), p.CurrentLandUse);
            }
            //Solution CurSolH = new Solution(CurrentLUs);
            //CalculateLUCode1Areas(CurSolH);
            for (int i = 0; i < PopSize; i++)
            {
                SortedList<short, short> newLU = new SortedList<short, short>(CurrentLUs);

                for (int j = 0; j < RandParcelNo; j++)
                {
                    short ROID = Convert.ToInt16(rand.Next(0, NofP-1));
                    newLU[ROID] = Convert.ToInt16(rand.Next(NofLU));
                }
                SolutionH SolH = new SolutionH(newLU);
                CalculateFitness(SolH);
                Population.Add(SolH);
            }
            return Population;
        }

        private List<SolutionH> InitializePopulationBasedOnRanks(int PopSize)
        {

            List<SolutionH> Population = new List<SolutionH>(PopSize);

            for (int i = 0; i < PopSize; i++)
            {
                SortedList<short, short> newLU = new SortedList<short, short>();
                List<short> RandLU = getRandomLUs();
                foreach (short LU in RandLU)
                {
                    double Area = 0;
                    int Rank = 0;
                    if (LURequiredAreas[LU] < 10)
                    {
                        continue;
                    }
                    while ((Area < LURequiredAreas[LU]) & (Rank++ < Settings.Default.NoOfLUs))
                    {
                        List<Parcel> par = parcels.FindAll(p => p.Ranks[Rank - 1] == LU);
                        foreach (Parcel parcell in par)
                        {
                            if (!newLU.ContainsKey(Convert.ToInt16(parcell.OID)))
                            {
                                if (Area + parcell.Area - LURequiredAreas[LU] > 0.1 * LURequiredAreas[LU])
                                {
                                    continue;
                                }
                                newLU.Add(Convert.ToInt16(parcell.OID), LU);
                                Area += parcell.Area;
                                if (Area >= LURequiredAreas[LU])
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                foreach (Parcel p in parcels)
                {
                    if (!newLU.ContainsKey(Convert.ToInt16(p.OID)))
                    {
                        newLU.Add(Convert.ToInt16(p.OID), Convert.ToInt16(rand.Next(Settings.Default.NoOfLUs)));
                    }
                }

                SolutionH SolH = new SolutionH(newLU);
                CalculateFitness(SolH);
                Population.Add(SolH);
            }
            return Population;
        }


        private List<short> getRandomLUs()
        {
            List<short> RandLU = new List<short>(Settings.Default.NoOfLUs);
            Random r = new Random();
            short Rand = Convert.ToInt16(r.Next(Settings.Default.NoOfLUs));
            RandLU.Add(Rand);
            Rand = Convert.ToInt16(r.Next(Settings.Default.NoOfLUs));
            while (RandLU.Count != Settings.Default.NoOfLUs)
            {
                Rand = Convert.ToInt16(r.Next(Settings.Default.NoOfLUs));
                if (!RandLU.Contains(Rand))
                {
                    RandLU.Add(Rand);
                    continue;
                }
            }
            return RandLU;
        }

        private List<short> getRandomParcellsToMutation(int noOfpar)
        {
            List<short> RandPar = new List<short>(noOfpar);
            Random r = new Random();
            short Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1) );
            RandPar.Add(Rand);
            Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1));
            while (RandPar.Count != noOfpar)
            {
                Rand = Convert.ToInt16(r.Next(Settings.Default.NoOFParcels - 1) );
                if (!RandPar.Contains(Rand))
                {
                    RandPar.Add(Rand);
                    continue;
                }
            }
            return RandPar;
        }

        private double[] CalArea()
        {
            double[] Area = new double[Settings.Default.NoOfLUs];
            for (short i = 0; i < Settings.Default.NoOfLUs; i++)
            {
                List<Parcel> LUPars = parcels.FindAll(p => p.CurrentLandUse == i);
                if (i < 3) // Residential land uses
                {
                    Area[i] += LUPars.FindAll(p => p.Area <= 300).Select(p => p.Area).Sum() * 1.6; //Residential density = 160% 
                    Area[i] += LUPars.FindAll(p => p.Area > 300 & p.Area <= 450).Select(p => p.Area).Sum() * 1.8; //Residential density = 180% 
                    Area[i] += LUPars.FindAll(p => p.Area > 450 & p.Area <= 550).Select(p => p.Area).Sum() * 2; //Residential density = 200%
                    Area[i] += LUPars.FindAll(p => p.Area > 550).Select(p => p.Area).Sum() * 2.2; //Residential density = 220%
                }
                else
                {
                    Area[i] = LUPars.Select(p => p.Area).Sum();
                }
            }
            return Area;
        }

        private double[] CalculateRequiredAreas_WithoutPopBlocks(double pops)
        {

            //////////////////////////////////////////////////////////////////////////////
            double DemandTotalArea = 0;
            double Area_Sum = 0;
            double population = 0;
            population = pops;
            double sumPercap = 0;
            for (int i = 0; i < Settings.Default.NoOfLUs; i++)
            {
                sumPercap = sumPercap + PerCap[i, 0];
            }
            DemandTotalArea = sumPercap * population;
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.SubFields = "Area";
            queryFilter.WhereClause = "OBJECTID<100000";
            ICursor Parcursor = (ICursor)fc_Parcells.Search(queryFilter, true);
            IDataStatistics PardataStatistics = new DataStatisticsClass();
            PardataStatistics.Field = "Area";
            PardataStatistics.Cursor = Parcursor;
            Area_Sum = PardataStatistics.Statistics.Sum;
            //////////////////////////////////////////////////////////

            double[] Areas = new double[Settings.Default.NoOfLUs];
            for (int i = 0; i < Settings.Default.NoOfLUs; i++)
            {
                Areas[i] = (Area_Sum / DemandTotalArea) * PerCap[i, 0] * population;
            }
            return Areas;

        }


        private double[] CalculateRequiredAreas()
        {

            //////////////////////////////////////////////////////////////////////////////
            double DemandTotalArea = 0;
            double Area_Sum = 0;
            double population = 0;

            ICursor cursor = (ICursor)fc_PopBlocks.Search(null, false);
            IDataStatistics dataStatistics = new DataStatisticsClass();
            dataStatistics.Field = "Pop";
            dataStatistics.Cursor = cursor;
            //MessageBox.Show(dataStatistics.Statistics.Sum.ToString());
            population = dataStatistics.Statistics.Sum;
            double sumPercap = 0;
            for (int i = 0; i < Settings.Default.NoOfLUs; i++)
            {
                sumPercap = sumPercap + PerCap[i, 0];
            }
            DemandTotalArea = sumPercap * population;
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter.SubFields = "Area";
            queryFilter.WhereClause = "OBJECTID<2710";
            ICursor Parcursor = (ICursor)fc_Parcells.Search(queryFilter, true);
            IDataStatistics PardataStatistics = new DataStatisticsClass();
            PardataStatistics.Field = "Area";
            PardataStatistics.Cursor = Parcursor;
            Area_Sum = PardataStatistics.Statistics.Sum;
            //////////////////////////////////////////////////////////

            double[] Areas = new double[Settings.Default.NoOfLUs];
            for (int i = 0; i < Settings.Default.NoOfLUs; i++)
            {
                Areas[i] = (Area_Sum / DemandTotalArea) * PerCap[i, 0] * population;
            }
            return Areas;

        }

        private double[] CalculateLUCode1Areas(SolutionH solH)
        {

            SortedList<short, short> LUCode1 = solH.LUCode1;
            double CV = 0;
            int NoOfLUCode1 = Settings.Default.NoOfLUCode1;
            double[] LUCode1Area = new double[NoOfLUCode1];
            for (int LUC1 = 0; LUC1 < NoOfLUCode1; LUC1++)
            {

                var LUparcels = LUCode1.Where(pLU => pLU.Value == LUC1);
                if (LUC1 == 1)
                {
                    foreach (KeyValuePair<short, short> par in LUparcels)
                    {
                        Parcel par2 = parcels.Find(p => p.OID == par.Key);
                        if (par2.Area < 300)
                        {
                            LUCode1Area[LUC1] += par2.Area * 1.6;
                        }
                        else if (par2.Area > 300 & par2.Area <= 450)
                        {
                            LUCode1Area[LUC1] += par2.Area * 1.8;
                        }
                        else if (par2.Area > 450 & par2.Area <= 550)
                        {
                            LUCode1Area[LUC1] += par2.Area * 2;
                        }
                        else if (par2.Area > 550)
                        {
                            LUCode1Area[LUC1] += par2.Area * 2.2;
                        }
                    }
                }
                else
                {
                    foreach (KeyValuePair<short, short> par in LUparcels)
                    {
                        Parcel par2 = parcels.Find(p => p.OID == par.Key);
                        LUCode1Area[LUC1] += par2.Area;
                    }
                }
            }
            return LUCode1Area;
        }


        private IFeatureClass CreateShapeFile(string shpFilepath, IGeometry geom)
        {
        out2:
            try
            {
                System.IO.FileInfo fi = new FileInfo(shpFilepath);
                var wsf = Activator.CreateInstance(Type.GetTypeFromProgID("esriDataSourcesFile.ShapefileWorkspaceFactory")) as IWorkspaceFactory;
                var fws = wsf.OpenFromFile(fi.DirectoryName, 0) as IFeatureWorkspace;
                IFieldsEdit flds = new FieldsClass();
                flds.AddField(MakeField("ObjectID", esriFieldType.esriFieldTypeOID, 0));
                IGeometryDefEdit geomDef = new GeometryDefClass();
                geomDef.GeometryType_2 = geom.GeometryType;
                geomDef.SpatialReference_2 = geom.SpatialReference;
                var shpField = MakeField("Shape", esriFieldType.esriFieldTypeGeometry, 0) as IFieldEdit;
                shpField.GeometryDef_2 = geomDef;
                flds.AddField(shpField);
                flds.AddField(MakeField("LUCode", esriFieldType.esriFieldTypeString, 16));
                flds.AddField(MakeField("LUCode1", esriFieldType.esriFieldTypeInteger, 16));
                string fcName = fi.Name;
                if (fcName.ToUpper().EndsWith(".SHP"))
                    fcName = fcName.Substring(0, fcName.LastIndexOf("."));

                var fc = fws.CreateFeatureClass(fcName, flds, null, null, esriFeatureType.esriFTSimple, "Shape", "");

                return fc;
            }
            catch (Exception x)
            {
                //MessageBox.Show("Error CreateShapeFile Method: " + x.Message);
                //return null;
                goto out2;
            }
        }

        private IField MakeField(string name, esriFieldType fType, int length)
        {
            IFieldEdit fld = new FieldClass();
            fld.Name_2 = name;
            fld.Type_2 = fType;
            if (length > 0 && fType == esriFieldType.esriFieldTypeString)
                fld.Length_2 = length;
            return fld;
        }

        static Random rand = new Random(Guid.NewGuid().GetHashCode());
        private double[] Calculate_Random_Weights(int count)
        {
            double[] V = new double[count];
            for (int j = 0; j < count; j++)
            {
                V[j] = rand.NextDouble();
            }
            double t = 1 / V.Sum();

            double[] W = new double[count];
            for (int k = 0; k < count; k++)
            {
                W[k] = V[k] * t;
            }

            return W;
        }
        private List<List<double>> Normalize(List<List<double>> Params)
        {
            var compability = Params.Select(p => p[0]).ToList();
            var dependancy = Params.Select(p => p[1]).ToList();
            var compactness = Params.Select(p => p[2]).ToList();
            var Suitability = Params.Select(p => p[3]).ToList();

            int Count = compability.Count;
            List<List<double>> Normal_Parameters = new List<List<double>>(Count);

            double max_compablility = compability.Max();
            double min_compability = compability.Min();
            double Range_compability = max_compablility - min_compability;
            if (Range_compability < 0.001)
            {
                Range_compability = double.MaxValue;
            }
            double max_dependancy = dependancy.Max();
            double min_dependancy = dependancy.Min();
            double Range_dependancy = max_dependancy - min_dependancy;
            if (Range_dependancy < 0.001)
            {
                Range_dependancy = double.MaxValue;
            }
            double max_compactness = compactness.Max();
            double min_compactness = compactness.Min();
            double Range_compactness = max_compactness - min_compactness;
            if (Range_compactness < 0.001)
            {
                Range_compactness = double.MaxValue;
            }
            double max_suitability = Suitability.Max();
            double min_suitability = Suitability.Min();
            double Range_suitability = max_suitability - min_suitability;
            if (Range_compactness < 0.001)
            {
                Range_compactness = double.MaxValue;
            }

            for (int i = 0; i < Count; i++)
            {
                List<double> ps = new List<double>(4);
                ps.Add((compability[i] - min_compability) / (Range_compability));
                ps.Add((dependancy[i] - min_dependancy) / (Range_dependancy));
                ps.Add((compactness[i] - min_compactness) / (Range_compactness));
                ps.Add((Suitability[i] - min_suitability) / (Range_suitability));
                Normal_Parameters.Add(ps);
            }
            return Normal_Parameters;
        }
        private static bool StartEditing(IWorkspace workspace)
        {
            try
            {
                if (workspace == null)
                    MessageBox.Show("error in workspace");

                IWorkspaceEdit pWorkSpcEdit = (IWorkspaceEdit)workspace;

                if (!pWorkSpcEdit.IsBeingEdited())
                {
                    pWorkSpcEdit.StartEditing(false);
                    pWorkSpcEdit.StartEditOperation();
                }
                else
                {
                    pWorkSpcEdit.StartEditOperation();
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("startEditing: " + ex.Message);
                return false;
            }
        }
        private static bool StopEditing(IWorkspace workspace)
        {
            try
            {
                if (workspace == null)
                    MessageBox.Show("error in workspace");

                IWorkspaceEdit pWorkSpcEdit = (IWorkspaceEdit)workspace;
                if (pWorkSpcEdit.IsBeingEdited())
                {
                    pWorkSpcEdit.StopEditOperation();
                    pWorkSpcEdit.StopEditing(true);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("startEditing: " + ex.Message);
                return false;
            }
        }
        private double[,] GetDataFromTXT(string txtPath)
        {
            String input = File.ReadAllText(txtPath);
            int i = 0, j = 0;
            var Rows = input.Split('\n');
            var Cols = Rows[1].Trim().Split('	');
            double[,] result = new double[Rows.Length, Cols.Length];
            foreach (string row in Rows)
            {
                j = 0;
                string[] cols = row.Trim().Split('	');
                foreach (string val in cols)
                {
                    result[i, j] = double.Parse(val.Trim());
                    j++;
                }
                i++;
            }
            return result;
        }
        /*
        private IFeatureCursor getNeighbourParcelsOf(Optimization.Solution SolH, IPolygon polygon, double distance)
        {

            IFeatureClass fc = SolH.GetFeatureClass();
            IPoint CenterPoint = new PointClass();
            //CenterPoint = (polygon as IArea).Centroid;

            IGeometry cir = (polygon as ITopologicalOperator).Buffer(distance);
            //IBufferConstruction bf=new BufferConstructionClass();
            //IGeometry cir = bf.Buffer((polygon as IGeometry), distance);

            IFeatureCursor featurecursor = PerformSpatialQuery(fc, cir, esriSpatialRelEnum.esriSpatialRelIntersects, "");

            return featurecursor;
        }
        */
        #region "Perform Spatial Query"

        ///<summary>Creates a spatial query which performs a spatial search for features in the supplied feature class and has the option to also apply an attribute query via a where clause.</summary>
        ///  
        ///<param name="featureClass">An ESRI.ArcGIS.Geodatabase.IFeatureClass</param>
        ///<param name="searchGeometry">An ESRI.ArcGIS.Geometry.IGeometry (Only high-level geometries can be used)</param>
        ///<param name="spatialRelation">An ESRI.ArcGIS.Geodatabase.esriSpatialRelEnum (e.g., esriSpatialRelIntersects)</param>
        ///<param name="whereClause">A System.String, (e.g., "city_name = 'Redlands'").</param>
        ///   
        ///<returns>An IFeatureCursor holding the results of the query will be returned.</returns>
        ///   
        ///<remarks>Call the SpatialQuery method by passing in a reference to the Feature Class, a Geometry used for the search and the spatial operation to be preformed. An exmaple of a spatial opertaion would be intersects (e.g., esriSpatialRelEnum.esriSpatialRelContains). If you would like to return everything found by the spatial operation use "" for the where clause. Optionally a whereclause (e.g. "income > 1000") maybe applied if desired. The SQL syntax used to specify the where clause is the same as that of the underlying database holding the data.</remarks>
        private IFeatureCursor PerformSpatialQuery(IFeatureClass featureClass, IGeometry searchGeometry, esriSpatialRelEnum spatialRelation, System.String whereClause)
        {
            // create a spatial query filter
            ISpatialFilter spatialFilter = new SpatialFilterClass();

            // specify the geometry to query with
            spatialFilter.Geometry = searchGeometry;

            // specify what the geometry field is called on the Feature Class that we will be querying against
            System.String nameOfShapeField = featureClass.ShapeFieldName;
            spatialFilter.GeometryField = nameOfShapeField;

            // specify the type of spatial operation to use
            spatialFilter.SpatialRel = spatialRelation;

            // create the where statement
            spatialFilter.WhereClause = whereClause;

            // perform the query and use a cursor to hold the results
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter = (IQueryFilter)spatialFilter;
            IFeatureCursor featureCursor = featureClass.Search(queryFilter, false);

            return featureCursor;
        }
        #endregion


        private List<SolutionH> HypercubeSelection(List<SolutionH> LastFront, int k)
        {
            List<SolutionH> selectedMembers = new List<SolutionH>(LastFront);
            LastFront = null;
            int LFcount = selectedMembers.Count;
            int deletionCount = LFcount - k;
            for (int i = 0; i < deletionCount; i++)
            {
                SolutionH DelSol = SelectForDeletion2(selectedMembers);

                foreach (SolutionH sol2 in selectedMembers)
                {
                    if (sol2.FrontRank == DelSol.FrontRank && isEqual(sol2.HNSGACubeIndex, DelSol.HNSGACubeIndex))
                    {
                        sol2.HNSGAneighborCount -= 1;
                    }
                }
                selectedMembers.Remove(DelSol);
            }
            return selectedMembers;
        }

        private SolutionH SelectForDeletion2(List<SolutionH> LastF)
        {

            List<SolutionH> SortedLF = LastF.OrderByDescending(s => s.HNSGAneighborCount).ToList<SolutionH>();
            int a = SortedLF.Count;
            SolutionH delSolH = SortedLF[0];
            int idx = 1;
            while (delSolH.isElite)
            {
                delSolH = SortedLF[idx];
                idx++;
            }
            if (delSolH.HNSGAneighborCount == 0)
            {
                int delPopID = rand.Next(0, LastF.Count - 1);
                delSolH = LastF[delPopID];
            }
            return delSolH;
        }

        private int SelectForDeletion(List<SolutionH> LastF)
        {
            int LFcount = LastF.Count;
            int TourSize = 5;
            int delPopID;
            delPopID = rand.Next(0, LFcount);
            while (LastF[delPopID].isElite)
            {
                delPopID = rand.Next(0, LFcount);
            }
            for (int i = 0; i < TourSize; i++)
            {
                int ID = rand.Next(0, LFcount);
                if (LastF[ID].HNSGAneighborCount == 0)
                {
                    ID = rand.Next(0, LFcount);
                }
                while (LastF[ID].isElite)
                {
                    ID = rand.Next(0, LFcount);
                }
                if (LastF[ID].HNSGAneighborCount > LastF[delPopID].HNSGAneighborCount)
                {
                    delPopID = ID;
                }
            }

            return delPopID;
        }

        private void AddAccessTypeToParcels()
        {
            IFeatureCursor featureCursorGet = fc_Parcells.Search(null, true);
            IFeature feature = null;
            int TypeNameIdx = fc_Parcells.FindField("TYPENAME");
            while ((feature = featureCursorGet.NextFeature()) != null)
            {
                Parcel par = parcels.Find(p => p.OID == feature.OID);
                string TypeName = feature.get_Value(TypeNameIdx).ToString();
                if (TypeName == "محلي فرعي")
                {
                    par.AccessType = 1;
                }
                else if (TypeName == "دسترسي محلي")
                {
                    par.AccessType = 2;
                }

                else if (TypeName == "جمع کننده")
                {
                    par.AccessType = 3;
                }
                else if (TypeName == "شرياني درجه 2")
                {
                    par.AccessType = 4;
                }
                else if (TypeName == "شرياني درجه 1")
                {
                    par.AccessType = 5;
                }
                else if (TypeName == "مترو")
                {
                    par.AccessType = 6;
                }
            }
            Classes.BinarySerialization.WriteToBinaryFile<IList<Parcel>>(Settings.Default.DataForRun + "Parcells\\Parcels_new.bin", parcels, false);

        }
        SortedList<short, List<short>> StTypeLUs;
        private void SetStreetTypeLanduses()
        {
            StTypeLUs = new SortedList<short, List<short>>();
            List<short> LUs_1 = new List<short>();
            LUs_1.AddRange(new short[] { 0, 1, 2, 3, 6, 7, 12, 15, 21, 34 });

            List<short> LUs_2 = new List<short>();
            LUs_2.AddRange(new short[] { 0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 15, 21, 24, 27, 34 });

            List<short> LUs_3 = new List<short>();
            LUs_3.AddRange(new short[] { 4, 6, 7, 8, 13, 16, 19, 22, 25, 28, 35 });

            List<short> LUs_4_5 = new List<short>();
            LUs_4_5.AddRange(new short[] { 5, 9, 10, 11, 14, 17, 20, 23, 26, 29, 30, 31, 32, 36 });

            List<short> LUs_6 = new List<short>();
            LUs_6.AddRange(new short[] { 29, 3, 4, 5 });

            StTypeLUs.Add(1, LUs_1);
            StTypeLUs.Add(2, LUs_2);
            StTypeLUs.Add(3, LUs_3);
            StTypeLUs.Add(4, LUs_4_5);
            StTypeLUs.Add(5, LUs_4_5);
            StTypeLUs.Add(6, LUs_6);
        }

        private int getLUCode1(short LUCode)
        {
            int LUCode1 = 100;
            if (LUCode == 0 || LUCode == 1 || LUCode == 2)
            {
                LUCode1 = 1;
            }
            else if (LUCode == 3 || LUCode == 4 || LUCode == 5)
            {
                LUCode1 = 2;
            }
            else if (LUCode == 6 || LUCode == 7 || LUCode == 8 || LUCode == 9 || LUCode == 10 || LUCode == 11)
            {
                LUCode1 = 3;
            }
            else if (LUCode == 12 || LUCode == 13 || LUCode == 14)
            {
                LUCode1 = 4;
            }
            else if (LUCode == 15 || LUCode == 16 || LUCode == 17)
            {
                LUCode1 = 5;
            }
            else if (LUCode == 18 || LUCode == 19 || LUCode == 20)
            {
                LUCode1 = 6;
            }
            else if (LUCode == 21 || LUCode == 22 || LUCode == 23)
            {
                LUCode1 = 7;
            }
            else if (LUCode == 24 || LUCode == 25 || LUCode == 26)
            {
                LUCode1 = 8;
            }
            else if (LUCode == 27 || LUCode == 28 || LUCode == 29)
            {
                LUCode1 = 9;
            }
            else if (LUCode == 30 || LUCode == 31 || LUCode == 32 || LUCode == 33)
            {
                LUCode1 = 10;
            }
            else if (LUCode == 34 || LUCode == 35 || LUCode == 36)
            {
                LUCode1 = 11;
            }
            else if (LUCode == 37)
            {
                LUCode1 = 0;
            }
            return LUCode1;
        }
        List<LandUse> LUClassList = new List<LandUse>();
        private void setLUList()
        {
            List<LandUse> LUs = new List<LandUse>();

            List<short> AS = new List<short>(new short[] { 1, 2, 3, 4, 5, 6 });
            LandUse LU = new LandUse(37, 0, 0, double.MaxValue, AS);
            //LUs.Add(LU);
            // maskooni//////////////////////////////////////////////
            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(0, 1, 40, 650, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(1, 1, 40, 650, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(2, 1, 40, 650, AS);
            LUs.Add(LU);
            //Tejari/////////////////////////////////////////////////
            AS = new List<short>(new short[] { 1 });
            LU = new LandUse(3, 2, 0, 50, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(4, 2, 0, 1000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5, 6 });
            LU = new LandUse(5, 2, 0, 20000, AS);
            LUs.Add(LU);
            //Amouzeshi//////////////////////////////////////////////
            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(6, 3, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(7, 3, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3 });
            LU = new LandUse(8, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3, 4, 5 });
            LU = new LandUse(9, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 2, 3, 4, 5 });
            LU = new LandUse(10, 3, 1000, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(11, 3, 1000, 50000, AS);
            LUs.Add(LU);
            //Mazhabi///////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(12, 4, 100, 500, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(13, 4, 200, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(14, 4, 200, 5000, AS);
            LUs.Add(LU);
            //Behdashti////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(15, 5, 100, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(16, 5, 100, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(17, 5, 500, 50000, AS);
            LUs.Add(LU);
            //Edari////////////////////////////////////////////////////
            AS = new List<short>(new short[] { });
            LU = new LandUse(18, 6, 0, 5000, AS);
            //LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(19, 6, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(20, 6, 0, 5000, AS);
            LUs.Add(LU);
            //Farhangi//////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(21, 7, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(22, 7, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(23, 7, 0, 5000, AS);
            LUs.Add(LU);
            //Varzeshi/////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(24, 8, 500, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(25, 8, 500, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(26, 8, 500, 50000, AS);
            LUs.Add(LU);
            //Tasisat Shahri////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(27, 9, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(28, 9, 0, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5, 6 });
            LU = new LandUse(29, 9, 0, 5000, AS);
            LUs.Add(LU);
            //Sanati//////////////////////////////////////////////////
            AS = new List<short>(new short[] { 2 });
            LU = new LandUse(30, 10, 500, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3 });
            LU = new LandUse(31, 10, 500, 5000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(32, 10, 1000, 5000, AS);
            LUs.Add(LU);
            //Park//////////////////////////////////////////////////////
            AS = new List<short>(new short[] { 1, 2 });
            LU = new LandUse(34, 11, 400, 10000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 3, 4 });
            LU = new LandUse(35, 11, 400, 50000, AS);
            LUs.Add(LU);

            AS = new List<short>(new short[] { 4, 5 });
            LU = new LandUse(36, 11, 500, 50000, AS);
            LUs.Add(LU);

            LUClassList = LUs;
        }




        ////////////////////////////////////////////////////////////////////////////////////////////////

   
        private double getSuitabilityFromSHPByLUCode(IFeature feature, int LUCode)
        {
            double Quantitative_Suitability = 0;
            string S = "S" + LUCode.ToString();
            int SId = feature.Fields.FindField(S);
            if (SId == -1)
            {
                return 0;
            }
            string Qualitative_Suitability = feature.get_Value(SId).ToString();
            Quantitative_Suitability = Convert.ToDouble(Qualitative_Suitability);
            return Quantitative_Suitability;
        }
        private double getSuitabilityFromSHP(IFeature feature, int LUId)
        {
            double Quantitative_Suitability = 0;
            string S = "S" + LUId.ToString();
            if (S == "S11")
            {
                S = "S10";
            }
            if (S == "S33")
            {
                Quantitative_Suitability = getValueOfSuitability("NS");
                return Quantitative_Suitability;
            }
            if (S == "S37")
            {
                Quantitative_Suitability = getValueOfSuitability("NS");
                return Quantitative_Suitability;
            }
            int SId = feature.Fields.FindField(S);
            string Qualitative_Suitability = feature.get_Value(SId).ToString();

            Quantitative_Suitability = getValueOfSuitability(Qualitative_Suitability);

            return Quantitative_Suitability;
        }
        private double getValueOfSuitability(string Qualitative_Value)
        {
            double Quantitative_Value = 0;
            if (Qualitative_Value == "NS")
            { Quantitative_Value = 0; }
            else if (Qualitative_Value == "LS")
            { Quantitative_Value = 0.3; }
            else if (Qualitative_Value == "MS")
            { Quantitative_Value = 0.7; }
            else if (Qualitative_Value == "HS")
            { Quantitative_Value = 1.0; }
            else if (Qualitative_Value == "" || Qualitative_Value == " ")
            {
                Quantitative_Value = 0;
                //MessageBox.Show("Qualitive Value of pacel suitability in shape file is empty.");
            }
            else
            { MessageBox.Show("Qualitive Value of pacel suitability in shape file is not recognized."); }
            return Quantitative_Value;

        }
        private IFeatureCursor getNeighbourParcelsOf(IFeatureClass fc, IPolygon polygon, int distance)
        {
        a:

            try
            {
                
                IPoint CenterPoint = new PointClass();
                //CenterPoint = (polygon as IArea).Centroid;

                IGeometry cir = (polygon as ITopologicalOperator).Buffer(distance);
                //IBufferConstruction bf=new BufferConstructionClass();
                //IGeometry cir = bf.Buffer((polygon as IGeometry), distance);

                IFeatureCursor featurecursor = PerformSpatialQuery2(fc, cir, esriSpatialRelEnum.esriSpatialRelIntersects, "");

                return featurecursor;
            }
            catch
            {
                distance -= 10;
                goto a;

            }

        }

        #region "Perform Spatial Query"

        ///<summary>Creates a spatial query which performs a spatial search for features in the supplied feature class and has the option to also apply an attribute query via a where clause.</summary>
        ///  
        ///<param name="featureClass">An ESRI.ArcGIS.Geodatabase.IFeatureClass</param>
        ///<param name="searchGeometry">An ESRI.ArcGIS.Geometry.IGeometry (Only high-level geometries can be used)</param>
        ///<param name="spatialRelation">An ESRI.ArcGIS.Geodatabase.esriSpatialRelEnum (e.g., esriSpatialRelIntersects)</param>
        ///<param name="whereClause">A System.String, (e.g., "city_name = 'Redlands'").</param>
        ///   
        ///<returns>An IFeatureCursor holding the results of the query will be returned.</returns>
        ///   
        ///<remarks>Call the SpatialQuery method by passing in a reference to the Feature Class, a Geometry used for the search and the spatial operation to be preformed. An exmaple of a spatial opertaion would be intersects (e.g., esriSpatialRelEnum.esriSpatialRelContains). If you would like to return everything found by the spatial operation use "" for the where clause. Optionally a whereclause (e.g. "income > 1000") maybe applied if desired. The SQL syntax used to specify the where clause is the same as that of the underlying database holding the data.</remarks>
        private IFeatureCursor PerformSpatialQuery2(IFeatureClass featureClass, IGeometry searchGeometry, esriSpatialRelEnum spatialRelation, System.String whereClause)
        {
            // create a spatial query filter
            ISpatialFilter spatialFilter = new SpatialFilterClass();

            // specify the geometry to query with
            spatialFilter.Geometry = searchGeometry;

            // specify what the geometry field is called on the Feature Class that we will be querying against
            System.String nameOfShapeField = featureClass.ShapeFieldName;
            spatialFilter.GeometryField = nameOfShapeField;

            // specify the type of spatial operation to use
            spatialFilter.SpatialRel = spatialRelation;

            // create the where statement
            spatialFilter.WhereClause = whereClause;

            // perform the query and use a cursor to hold the results
            IQueryFilter queryFilter = new QueryFilterClass();
            queryFilter = (IQueryFilter)spatialFilter;
            IFeatureCursor featureCursor = featureClass.Search(queryFilter, false);

            return featureCursor;
        }
        #endregion

        private double Min_DistanceOfTwoPolygon(IGeometry p1, IGeometry p2)
        {
            return (p1 as IProximityOperator).ReturnDistance(p2);
            /*
            IPointCollection PointsOfPolygon1 = (p1 as IPointCollection);
            IPointCollection PointsOfPolygon2 = (p2 as IPointCollection);
            int p1Count = PointsOfPolygon1.PointCount;
            int p2Count = PointsOfPolygon2.PointCount;

            double x1 = PointsOfPolygon1.get_Point(0).X;
            double y1 = PointsOfPolygon1.get_Point(0).Y;
            double x2 = PointsOfPolygon2.get_Point(0).X;
            double y2 = PointsOfPolygon2.get_Point(0).Y;
            double min_dist = Math.Sqrt(Math.Pow((x1 - x2), 2) + Math.Pow((y1 - y2), 2));
            double dist=0;
            for (int i = 1; i < p1Count;i++ )
            {
                for (int j = 1; j < p2Count; j++)
                {
                    x1 = PointsOfPolygon1.get_Point(i).X;
                    y1 = PointsOfPolygon1.get_Point(i).Y;
                    x2 = PointsOfPolygon2.get_Point(j).X;
                    y2 = PointsOfPolygon2.get_Point(j).Y;
                    dist = Math.Sqrt(Math.Pow((x1 - x2), 2) + Math.Pow((y1 - y2), 2));
                    if (dist<min_dist)
                    {
                        min_dist = dist;
                    }
 
                }
            }
            
            return min_dist;
             */
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////

    }
}
