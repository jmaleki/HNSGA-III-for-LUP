﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LandUsePlanning.NSGAOptimization;
using System.IO;
using System.Windows.Forms;

namespace LandUsePlanning.Classes
{
    public static class DataLoader
    {
        public static void ExtractPopOfAllIterations(string FolderPath,string GAParetoPath,int itr, int PopSize)
        {

            DateTime dt = DateTime.Now;
            string DataFolderName = FolderPath + "Extracted Parameters" +
                                "," + dt.Year.ToString() +
                                "," + dt.Month.ToString() +
                                "," + dt.Day.ToString() +
                                "," + dt.Hour.ToString() +
                                "," + dt.Minute.ToString();
            System.IO.Directory.CreateDirectory(DataFolderName);

            List<List<double>> minObjs = new List<List<double>>(itr + 1);
            List<List<double>> avrObjs = new List<List<double>>(itr + 1);
            List<List<double>> maxObjs = new List<List<double>>(itr + 1);
            List<double> spread = new List<double>(itr + 1);
            List<double> gamma = new List<double>(itr + 1);
            List<double> igd = new List<double>(itr + 1);
            List<SolutionH> TruePF = BinarySerialization.ReadFromBinaryFile<List<SolutionH>>(GAParetoPath);
            for (int i = 0; i < itr+1; i++)
            {
                List<SolutionH> Pop = BinarySerialization.ReadFromBinaryFile<List<SolutionH>>(FolderPath + "Iteration_" + i + "_Population.bin");

                int FirstFrontsCount = Pop.Count;
                List<double> minObjsOfEachIteration = new List<double>(Settings.Default.NoOFObj);
                List<double> avrObjsOfEachIteration = new List<double>(Settings.Default.NoOFObj);
                List<double> maxObjsOfEachIteration = new List<double>(Settings.Default.NoOFObj);
                for (int obj = 0; obj < Settings.Default.NoOFObj; obj++)
                {
                    minObjsOfEachIteration.Add(Pop.Select(s => s.Fitness[obj]).Min());
                    avrObjsOfEachIteration.Add(Pop.Select(s => s.Fitness[obj]).Average());
                    maxObjsOfEachIteration.Add(Pop.Select(s => s.Fitness[obj]).Max());

                }
                minObjs.Add(minObjsOfEachIteration);
                avrObjs.Add(avrObjsOfEachIteration);
                maxObjs.Add(maxObjsOfEachIteration);
                //Evaluation metrics
                spread.Add(ComputeSpread(Pop,TruePF));
                gamma.Add(ComputeGama(Pop, TruePF));
                igd.Add(ComputeIGD(Pop, TruePF));
            }
            for (int obj = 0; obj < Settings.Default.NoOFObj; obj++)
            {
                SaveListToTXT(DataFolderName + "\\", "min_Objective_" + (obj + 1) + ".txt", minObjs.Select(m => m[obj]).ToList<double>());
                SaveListToTXT(DataFolderName + "\\", "avr_Objective_" + (obj + 1) + ".txt", avrObjs.Select(m => m[obj]).ToList<double>());
                SaveListToTXT(DataFolderName + "\\", "max_Objective_" + (obj + 1) + ".txt", maxObjs.Select(m => m[obj]).ToList<double>());
            }
            SaveListToTXT(DataFolderName + "\\", "Spread.txt", spread);
            SaveListToTXT(DataFolderName + "\\", "Gamma.txt", gamma);
            SaveListToTXT(DataFolderName + "\\", "IGD.txt", igd);

            List<SolutionH> LastPop = BinarySerialization.ReadFromBinaryFile<List<SolutionH>>(FolderPath + "Iteration_" + itr + "_Population.bin");

            List<SolutionH> Front = LastPop.FindAll(p => p.FrontRank == 0);
            TextWriter tw = new StreamWriter(DataFolderName + "\\Front1_OfLastItration.txt");
            foreach (SolutionH solH in Front)
            {
                foreach (double d in solH.Fitness)
                {
                    tw.Write(d + ",");
                }
                tw.WriteLine();
            }
            tw.Close();
            int fr = 1;
            Front = LastPop.FindAll(p => p.FrontRank == fr);
            while (Front.Count != 0)
            {
                tw = new StreamWriter(DataFolderName + "\\Front" + (fr + 1) + "_OfLastItration.txt");
                foreach (SolutionH solH in Front)
                {
                    foreach (double d in solH.Fitness)
                    {
                        tw.Write(d + ",");
                    }
                    tw.WriteLine();
                }
                tw.Close();
                fr++;
                Front = LastPop.FindAll(p => p.FrontRank == fr);
            }

        }

        public static void ExtractGAFitsOFAllIterations()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Binarry File|*.bin";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                List<double[]> Fits = BinarySerialization.ReadFromBinaryFile<List<double[]>>(ofd.FileName);
                string path = ofd.FileName.Replace(".bin", "\\");

                List<double> MaxFits= Fits.Select(s => s.Max()).ToList<double>();
                List<double> AvrFits = Fits.Select(s => s.Average()).ToList<double>();
                List<double> MinFits = Fits.Select(s => s.Min()).ToList<double>();
                SaveListToTXT(path, "MaxFitsOfAllItr.txt", MaxFits);
                SaveListToTXT(path, "AvrFitsOfAllItr.txt", AvrFits);
                SaveListToTXT(path, "MinFitsOfAllItr.txt", MinFits);
                MessageBox.Show("Extracted in Selected path.", "Succesful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public static void ExtractParetoOfIterationsParameters(string DataPath,string ExtractToPath)
        {
            List<List<SolutionH>> FirstFronts = BinarySerialization.ReadFromBinaryFile<List<List<SolutionH>>>(DataPath);
            int FirstFrontsCount = FirstFronts.Count;
            List<List<double>> minObjs = new List<List<double>>(FirstFrontsCount);
            for (int i = 0; i < FirstFrontsCount; i++)
            {
                List<double> minObjsOfEachIteration = new List<double>(Settings.Default.NoOFObj);
                for(int obj=0; obj<Settings.Default.NoOFObj;obj++)
                {
                    minObjsOfEachIteration.Add(FirstFronts[i].Select(s=>s.Fitness[obj]).Min());
                }
                minObjs.Add(minObjsOfEachIteration);
            }
            for (int obj = 0; obj < Settings.Default.NoOFObj; obj++)
            {
                //SaveListToTXT(ExtractToPath, "Objective_" + (obj + 1)+".txt", minObjs.Select(m => m[obj]).ToList<double>());
            }

        }

        public static void SaveListToTXT(string path, string name, List<double> List)
        {
            if (!Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
            TextWriter tw = new StreamWriter(path + name);
            int ListCount = List.Count;

            for (int i = 0; i < ListCount; i++)
            {
                tw.WriteLine((i) + "," + List[i]);
            }
            tw.Close();
        }

        public static void ExtractMinMeanMax(string path)
        {
            string resultpath = path.Replace(".bin", "\\");
            System.IO.Directory.CreateDirectory(resultpath);
            
        }

        public static double ComputeSpread(List<SolutionH> Fr1, List<SolutionH> trueParetoFront)
        {
            int NoOFObj = Settings.Default.NoOFObj;
            double sp = 0;
            ////////////////////////////////////////////////////////////////////////
            double Sum_d_Extreme = 0;
            for (int i = 0; i < NoOFObj; i++)
            {
                List<SolutionH> P = trueParetoFront.OrderBy(s => s.Fitness[i]).ToList<SolutionH>();
                List<SolutionH> Q = Fr1.OrderBy(s => s.Fitness[i]).ToList<SolutionH>();
                double d_Extreme = 0;
                for (int j = 0; j < NoOFObj; j++)
                {
                    d_Extreme += Math.Pow((P[0].Fitness[j] - Q[0].Fitness[j]), 2);
                }
                d_Extreme = Math.Sqrt(d_Extreme);
                Sum_d_Extreme += d_Extreme;
            }
            //////////////////////////////////////////////////////////////////
            int Iterations = Fr1.Count;
            double[] d = new double[Iterations];
            for (int idx = 0; idx < Iterations; idx++)
            {
                double mindist = double.MaxValue;
                foreach (SolutionH s in Fr1)
                {
                    if (s == Fr1[idx])
                    {
                        continue;
                    }
                    double dist = 0;
                    for (int i = 0; i < NoOFObj; i++)
                    {
                        dist += Math.Pow((Fr1[idx].Fitness[i] - s.Fitness[i]), 2);
                    }
                    dist = Math.Sqrt(dist);
                    if (dist < mindist)
                    {
                        mindist = dist;
                    }
                    if (mindist == 0)
                    {
                        break;
                    }
                }
                d[idx] = mindist;
            }
            /////////////////////////////////////////////////////////////////
            double sum_diff = 0;
            double Avr_d = d.Average();
            foreach (double dist in d)
            {
                sum_diff += Math.Abs(dist - Avr_d);
            }
            //////////////////////////////////////////////////////////////////
            sp = (Sum_d_Extreme + sum_diff) / (Sum_d_Extreme + Iterations * Avr_d);
            return sp;
        }

        public static double ComputeGama(List<SolutionH> Fr1, List<SolutionH> trueParetoFront)
        {
            int NoOFObj = Settings.Default.NoOFObj;
            double gama = 0;
            foreach (SolutionH s in Fr1)
            {
                double mindist = double.MaxValue;
                foreach (SolutionH Z in trueParetoFront)
                {
                    double dist = 0;
                    for (int i = 0; i < NoOFObj; i++)
                    {
                        dist += Math.Pow((Z.Fitness[i] - s.Fitness[i]), 2);
                    }
                    dist = Math.Sqrt(dist);
                    if (dist < mindist)
                    {
                        mindist = dist;
                    }
                }
                gama += mindist;
            }
            gama = gama / (Fr1.Count);
            return gama;
        }

        public static double ComputeIGD(List<SolutionH> Fr1, List<SolutionH> trueParetoFront)
        {
            double igd = 0;
            int NoOFObj = Settings.Default.NoOFObj;
            foreach (SolutionH Z in trueParetoFront)
            {
                double mindist = double.MaxValue;
                foreach (SolutionH s in Fr1)
                {
                    double dist = 0;
                    for (int i = 0; i < NoOFObj; i++)
                    {
                        dist += Math.Pow((Z.Fitness[i] - s.Fitness[i]), 2);
                    }
                    dist = Math.Sqrt(dist);
                    if (dist < mindist)
                    {
                        mindist = dist;
                    }
                }
                igd += mindist;
            }
            igd = igd / (trueParetoFront.Count);
            return igd;
        }
        public static void SaveListToTXT(string path, int name, List<double[]> List)
        {
            TextWriter tw = new StreamWriter(path +"\\"+ name +".txt");
            foreach (double[] v in List)
            {
                foreach (double dci in v)
                {
                    tw.Write(dci + ",");
                }
                tw.WriteLine();
            }
            tw.Close();
        }
        public static void SaveListToTXT(string path, string name, List<double[]> List)
        {
            TextWriter tw = new StreamWriter(path + "\\" + name + ".txt");
            foreach (double[] v in List)
            {
                foreach (double dci in v)
                {
                    tw.Write(dci + ",");
                }
                tw.WriteLine();
            }
            tw.Close();
        }
    }
}
