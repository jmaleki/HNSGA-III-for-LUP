﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LandUsePlanning.Classes
{
    class LandUse
    {
        public readonly short LUNo;
        public readonly short LUCode1;
        public readonly double minAcceptableArea;
        public readonly double maxAcceptableArea;
        public readonly List<short> AcceptableStreets;
        public LandUse(short LUNumber, short LUCode1Num, double MinArea,double MaxArea, List<short>AS)
        {
            LUNo = LUNumber;
            LUCode1 = LUCode1Num;
            minAcceptableArea = MinArea;
            maxAcceptableArea = MaxArea;
            AcceptableStreets = AS;
        }
    }
}
