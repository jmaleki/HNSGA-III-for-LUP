﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LandUsePlanning.Classes
{
    [Serializable]
    class Parcel
    {
        public int OID;
        public double Area;
        // Neiberhood -> SortedList<Land uses(0 - 36) , IList< Neigbors OID >>
        public SortedList<int, IList<short>> NeigberHood;
        // minDistOfneighber -> SortedList< neigber OID, Neighber Min Distance >
        public SortedList<short, short> minDistOfneighber;
        public double[] suitability;
        public short[] Ranks;
        public short CurrentLandUse;
        public short AccessType;
        public SortedList<short, double[]> CurrentLUObjectivesOfStakeholders = null;
        public Parcel(int pOID, short CLU, double pArea, double[] pSuitability, short[] pRanks)
        {
            OID = pOID;
            CurrentLandUse = CLU;
            Area = pArea;
            suitability = pSuitability;
            Ranks = pRanks;
        }

        public double getCompactness()
        {
            return 0;
        }
    }
}